/**
 * PROGEN Platform - User Service (Fixed)
 * 
 * This service replaces the direct auth.js implementation and provides:
 * 1. Secure authentication with proper password hashing
 * 2. Role-based access control
 * 3. Session management with localStorage persistence
 * 4. Rate limiting for login attempts
 * 5. Future API compatibility
 */

class UserService {
  constructor() {
    this.STORAGE_KEY = 'progen-user-session';
    this.RATE_LIMIT_KEY = 'progen-login-attempts';
    this.MAX_LOGIN_ATTEMPTS = 5;
    this.RATE_LIMIT_WINDOW = 15 * 60 * 1000; // 15 minutes
    
    this.currentUser = null;
    this.users = [];
    
    this.init();
  }

  async init() {
    try {
      // Load users from JSON file
      await this.loadUsers();
      
      // Restore session if exists
      this.restoreSession();
      
      // Set up session cleanup
      this.setupSessionCleanup();
      
    } catch (error) {
      console.error('Failed to initialize UserService:', error);
    }
  }

  /**
   * Load users from JSON file
   */
  async loadUsers() {
    try {
      const response = await fetch('/data/users.json');
      if (!response.ok) {
        throw new Error(`Failed to load users: ${response.status}`);
      }
      const data = await response.json();
      this.users = data.users || [];
    } catch (error) {
      console.error('Error loading users:', error);
      // Fallback to empty array
      this.users = [];
    }
  }

  /**
   * Simple hash function for password comparison (development only)
   * In production, this should be replaced with proper server-side hashing
   */
  async hashPassword(password) {
    // Simple SHA-256 hash for development
    const encoder = new TextEncoder();
    const data = encoder.encode(password);
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  }

  /**
   * Check rate limiting for login attempts
   */
  checkRateLimit(email) {
    const attempts = this.getLoginAttempts(email);
    const now = Date.now();
    
    // Clean old attempts
    const recentAttempts = attempts.filter(
      timestamp => now - timestamp < this.RATE_LIMIT_WINDOW
    );
    
    if (recentAttempts.length >= this.MAX_LOGIN_ATTEMPTS) {
      const oldestAttempt = Math.min(...recentAttempts);
      const timeLeft = this.RATE_LIMIT_WINDOW - (now - oldestAttempt);
      throw new Error(`Too many login attempts. Please try again in ${Math.ceil(timeLeft / 60000)} minutes.`);
    }
    
    return true;
  }

  /**
   * Record login attempt
   */
  recordLoginAttempt(email) {
    const attempts = this.getLoginAttempts(email);
    attempts.push(Date.now());
    
    try {
      localStorage.setItem(`${this.RATE_LIMIT_KEY}-${email}`, JSON.stringify(attempts));
    } catch (error) {
      console.warn('Failed to record login attempt:', error);
    }
  }

  /**
   * Get login attempts for email
   */
  getLoginAttempts(email) {
    try {
      const stored = localStorage.getItem(`${this.RATE_LIMIT_KEY}-${email}`);
      return stored ? JSON.parse(stored) : [];
    } catch (error) {
      return [];
    }
  }

  /**
   * Clear login attempts for email
   */
  clearLoginAttempts(email) {
    try {
      localStorage.removeItem(`${this.RATE_LIMIT_KEY}-${email}`);
    } catch (error) {
      console.warn('Failed to clear login attempts:', error);
    }
  }

  /**
   * Get user by email
   */
  async getUserByEmail(email) {
    return this.users.find(user => user.email === email && user.isActive !== false);
  }

  /**
   * Sign in user
   */
  async signIn(email, password) {
    try {
      // Check rate limiting
      this.checkRateLimit(email);
      
      // Find user
      const user = await this.getUserByEmail(email);
      if (!user) {
        this.recordLoginAttempt(email);
        throw new Error('Invalid email or password');
      }
      
      // Verify password
      const passwordHash = await this.hashPassword(password);
      if (user.passwordHash !== passwordHash) {
        this.recordLoginAttempt(email);
        throw new Error('Invalid email or password');
      }
      
      // Clear login attempts on successful login
      this.clearLoginAttempts(email);
      
      // Create session
      const session = {
        userId: user.id,
        email: user.email,
        role: user.role,
        name: user.name || user.profile?.name || 'User',
        loginAt: new Date().toISOString(),
        expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString() // 24 hours
      };
      
      // Save session
      this.saveSession(session);
      
      // Set current user
      this.currentUser = { ...user, session };
      
      // Update last login
      this.updateLastLogin(user.id);
      
      // Dispatch login event
      this.dispatchAuthEvent('login', this.currentUser);
      
      return {
        success: true,
        user: this.sanitizeUser(this.currentUser),
        message: 'Login successful'
      };
      
    } catch (error) {
      return {
        success: false,
        error: error.message,
        message: 'Login failed'
      };
    }
  }

  /**
   * Sign out user
   */
  async signOut() {
    try {
      const user = this.currentUser;
      
      // Clear session
      this.clearSession();
      
      // Clear current user
      this.currentUser = null;
      
      // Dispatch logout event
      this.dispatchAuthEvent('logout', user);
      
      return {
        success: true,
        message: 'Logout successful'
      };
      
    } catch (error) {
      return {
        success: false,
        error: error.message,
        message: 'Logout failed'
      };
    }
  }

  /**
   * Get current user
   */
  getCurrentUser() {
    return this.currentUser ? this.sanitizeUser(this.currentUser) : null;
  }

  /**
   * Check if user has specific role
   */
  hasRole(role) {
    return this.currentUser && this.currentUser.role === role;
  }

  /**
   * Check if user has any of the specified roles
   */
  hasAnyRole(roles) {
    return this.currentUser && roles.includes(this.currentUser.role);
  }

  /**
   * Check if user has specific permission
   */
  hasPermission(permission) {
    if (!this.currentUser) return false;
    
    // Admin has all permissions
    if (this.currentUser.role === 'admin') return true;
    
    // Check user permissions
    const permissions = this.currentUser.permissions || [];
    return permissions.includes(permission);
  }

  /**
   * Check if user is authenticated
   */
  isAuthenticated() {
    return this.currentUser !== null && this.isSessionValid();
  }

  /**
   * Check if session is valid
   */
  isSessionValid() {
    if (!this.currentUser || !this.currentUser.session) return false;
    
    const expiresAt = new Date(this.currentUser.session.expiresAt);
    return expiresAt > new Date();
  }

  /**
   * Save session to localStorage
   */
  saveSession(session) {
    try {
      localStorage.setItem(this.STORAGE_KEY, JSON.stringify(session));
    } catch (error) {
      console.warn('Failed to save session:', error);
    }
  }

  /**
   * Restore session from localStorage
   */
  restoreSession() {
    try {
      const stored = localStorage.getItem(this.STORAGE_KEY);
      if (!stored) return;
      
      const session = JSON.parse(stored);
      
      // Check if session is expired
      const expiresAt = new Date(session.expiresAt);
      if (expiresAt <= new Date()) {
        this.clearSession();
        return;
      }
      
      // Find user
      const user = this.users.find(u => u.id === session.userId);
      if (!user || user.isActive === false) {
        this.clearSession();
        return;
      }
      
      // Restore current user
      this.currentUser = { ...user, session };
      
      // Dispatch restore event
      this.dispatchAuthEvent('restore', this.currentUser);
      
    } catch (error) {
      console.warn('Failed to restore session:', error);
      this.clearSession();
    }
  }

  /**
   * Clear session
   */
  clearSession() {
    try {
      localStorage.removeItem(this.STORAGE_KEY);
    } catch (error) {
      console.warn('Failed to clear session:', error);
    }
  }

  /**
   * Set up session cleanup
   */
  setupSessionCleanup() {
    // Check session validity every 5 minutes
    setInterval(() => {
      if (this.currentUser && !this.isSessionValid()) {
        this.signOut();
      }
    }, 5 * 60 * 1000);
  }

  /**
   * Update last login time (in a real app, this would be server-side)
   */
  updateLastLogin(userId) {
    const user = this.users.find(u => u.id === userId);
    if (user) {
      user.lastLoginAt = new Date().toISOString();
    }
  }

  /**
   * Sanitize user data for client-side use
   */
  sanitizeUser(user) {
    if (!user) return null;
    
    const { passwordHash, ...sanitized } = user;
    return sanitized;
  }

  /**
   * Dispatch authentication events
   */
  dispatchAuthEvent(type, user) {
    const event = new CustomEvent('authchange', {
      detail: {
        type,
        user: this.sanitizeUser(user),
        isAuthenticated: this.isAuthenticated()
      }
    });
    document.dispatchEvent(event);
  }

  /**
   * Register new user (for future implementation)
   */
  async register(userData) {
    // This would typically be handled server-side
    throw new Error('User registration not implemented in demo version');
  }

  /**
   * Update user profile (for future implementation)
   */
  async updateProfile(updates) {
    // This would typically be handled server-side
    throw new Error('Profile updates not implemented in demo version');
  }

  /**
   * Change password (for future implementation)
   */
  async changePassword(currentPassword, newPassword) {
    // This would typically be handled server-side
    throw new Error('Password changes not implemented in demo version');
  }
}

// Initialize UserService when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    window.userService = new UserService();
  });
} else {
  window.userService = new UserService();
}

// Export for module systems
if (typeof module !== 'undefined' && module.exports) {
  module.exports = UserService;
}


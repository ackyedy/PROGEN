/**
 * PROGEN Accessibility Enhancements
 * Provides comprehensive accessibility features and improvements
 */

'use strict';

const AccessibilityEnhancements = {
  // Configuration
  config: {
    focusOutlineWidth: '2px',
    focusOutlineStyle: 'solid',
    focusOutlineOffset: '2px',
    skipLinkTarget: '#main-content',
    announceDelay: 100,
    keyboardNavigationEnabled: true
  },

  // State
  state: {
    isInitialized: false,
    currentFocusedElement: null,
    announcer: null,
    keyboardNavigation: {
      currentIndex: 0,
      focusableElements: []
    },
    reducedMotion: false,
    highContrast: false
  },

  /**
   * Initialize accessibility enhancements
   */
  init() {
    if (this.state.isInitialized) return;

    try {
      this.detectUserPreferences();
      this.createScreenReaderAnnouncer();
      this.addSkipLinks();
      this.enhanceFocusManagement();
      this.setupKeyboardNavigation();
      this.addAriaLabels();
      this.setupLiveRegions();
      this.enhanceFormAccessibility();
      this.setupEventListeners();
      
      this.state.isInitialized = true;
      this.announce('アクセシビリティ機能が有効になりました');
      console.log('♿ Accessibility Enhancements initialized!');
    } catch (error) {
      console.error('Failed to initialize Accessibility Enhancements:', error);
    }
  },

  /**
   * Detect user preferences
   */
  detectUserPreferences() {
    // Check for reduced motion preference
    this.state.reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    
    // Check for high contrast preference
    this.state.highContrast = window.matchMedia('(prefers-contrast: high)').matches;
    
    // Apply preferences
    if (this.state.reducedMotion) {
      document.documentElement.classList.add('reduce-motion');
    }
    
    if (this.state.highContrast) {
      document.documentElement.classList.add('high-contrast');
    }
  },

  /**
   * Create screen reader announcer
   */
  createScreenReaderAnnouncer() {
    this.state.announcer = document.createElement('div');
    this.state.announcer.setAttribute('aria-live', 'polite');
    this.state.announcer.setAttribute('aria-atomic', 'true');
    this.state.announcer.className = 'sr-only';
    this.state.announcer.style.cssText = `
      position: absolute !important;
      width: 1px !important;
      height: 1px !important;
      padding: 0 !important;
      margin: -1px !important;
      overflow: hidden !important;
      clip: rect(0, 0, 0, 0) !important;
      white-space: nowrap !important;
      border: 0 !important;
    `;
    document.body.appendChild(this.state.announcer);
  },

  /**
   * Add skip links for keyboard navigation
   */
  addSkipLinks() {
    const skipLink = document.createElement('a');
    skipLink.href = this.config.skipLinkTarget;
    skipLink.textContent = 'メインコンテンツにスキップ';
    skipLink.className = 'skip-link';
    skipLink.style.cssText = `
      position: absolute;
      top: -40px;
      left: 6px;
      background: var(--color-primary, #ffcc00);
      color: var(--color-fg, #1a1a1a);
      padding: 8px;
      text-decoration: none;
      border-radius: 4px;
      font-weight: bold;
      z-index: 10000;
      transition: top 0.3s;
    `;
    
    skipLink.addEventListener('focus', () => {
      skipLink.style.top = '6px';
    });
    
    skipLink.addEventListener('blur', () => {
      skipLink.style.top = '-40px';
    });
    
    document.body.insertBefore(skipLink, document.body.firstChild);
    
    // Ensure main content has the target ID
    let mainContent = document.getElementById('main-content');
    if (!mainContent) {
      mainContent = document.querySelector('main') || 
                   document.querySelector('.content-area') ||
                   document.querySelector('.studio-main') ||
                   document.querySelector('.learning-main');
      
      if (mainContent) {
        mainContent.id = 'main-content';
      }
    }
  },

  /**
   * Enhance focus management
   */
  enhanceFocusManagement() {
    // Add focus styles
    const focusStyles = document.createElement('style');
    focusStyles.textContent = `
      /* Enhanced focus styles */
      *:focus {
        outline: ${this.config.focusOutlineWidth} ${this.config.focusOutlineStyle} var(--color-accent, #ff0000) !important;
        outline-offset: ${this.config.focusOutlineOffset} !important;
      }
      
      /* Remove default focus for mouse users */
      *:focus:not(:focus-visible) {
        outline: none !important;
      }
      
      /* Enhanced focus-visible styles */
      *:focus-visible {
        outline: ${this.config.focusOutlineWidth} ${this.config.focusOutlineStyle} var(--color-accent, #ff0000) !important;
        outline-offset: ${this.config.focusOutlineOffset} !important;
        box-shadow: 0 0 0 4px rgba(255, 0, 0, 0.2) !important;
      }
      
      /* Button focus enhancements */
      button:focus-visible,
      .btn:focus-visible {
        outline: ${this.config.focusOutlineWidth} ${this.config.focusOutlineStyle} var(--color-accent, #ff0000) !important;
        outline-offset: ${this.config.focusOutlineOffset} !important;
        box-shadow: 0 0 0 4px rgba(255, 0, 0, 0.2) !important;
      }
      
      /* Link focus enhancements */
      a:focus-visible {
        outline: ${this.config.focusOutlineWidth} ${this.config.focusOutlineStyle} var(--color-accent, #ff0000) !important;
        outline-offset: ${this.config.focusOutlineOffset} !important;
        text-decoration: underline !important;
      }
      
      /* Input focus enhancements */
      input:focus-visible,
      textarea:focus-visible,
      select:focus-visible {
        outline: ${this.config.focusOutlineWidth} ${this.config.focusOutlineStyle} var(--color-accent, #ff0000) !important;
        outline-offset: ${this.config.focusOutlineOffset} !important;
        box-shadow: 0 0 0 4px rgba(255, 0, 0, 0.2) !important;
      }
      
      /* High contrast mode enhancements */
      .high-contrast *:focus-visible {
        outline-width: 4px !important;
        outline-color: #ffffff !important;
        background-color: #000000 !important;
        color: #ffffff !important;
      }
      
      /* Reduced motion support */
      .reduce-motion * {
        animation-duration: 0.01ms !important;
        animation-iteration-count: 1 !important;
        transition-duration: 0.01ms !important;
      }
    `;
    document.head.appendChild(focusStyles);
  },

  /**
   * Setup keyboard navigation
   */
  setupKeyboardNavigation() {
    document.addEventListener('keydown', (e) => {
      // Handle escape key
      if (e.key === 'Escape') {
        this.handleEscapeKey(e);
      }
      
      // Handle tab navigation
      if (e.key === 'Tab') {
        this.handleTabNavigation(e);
      }
      
      // Handle arrow key navigation for specific components
      if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.key)) {
        this.handleArrowNavigation(e);
      }
      
      // Handle enter and space for custom interactive elements
      if (e.key === 'Enter' || e.key === ' ') {
        this.handleActivation(e);
      }
    });
  },

  /**
   * Handle escape key
   */
  handleEscapeKey(e) {
    // Close modals
    const openModal = document.querySelector('.modal-overlay.show');
    if (openModal) {
      const closeBtn = openModal.querySelector('.modal-close');
      if (closeBtn) {
        closeBtn.click();
      }
      e.preventDefault();
      return;
    }
    
    // Close dropdowns
    const openDropdown = document.querySelector('.dropdown.open');
    if (openDropdown) {
      openDropdown.classList.remove('open');
      e.preventDefault();
      return;
    }
    
    // Return focus to main content
    const mainContent = document.getElementById('main-content');
    if (mainContent) {
      mainContent.focus();
    }
  },

  /**
   * Handle tab navigation
   */
  handleTabNavigation(e) {
    const focusableElements = this.getFocusableElements();
    const currentIndex = focusableElements.indexOf(document.activeElement);
    
    if (e.shiftKey) {
      // Shift+Tab (backward)
      if (currentIndex <= 0) {
        focusableElements[focusableElements.length - 1].focus();
        e.preventDefault();
      }
    } else {
      // Tab (forward)
      if (currentIndex >= focusableElements.length - 1) {
        focusableElements[0].focus();
        e.preventDefault();
      }
    }
  },

  /**
   * Handle arrow key navigation
   */
  handleArrowNavigation(e) {
    const target = e.target;
    
    // Navigation menu
    if (target.closest('.studio-nav') || target.closest('.nav-menu')) {
      this.handleMenuNavigation(e);
    }
    
    // Tab navigation
    if (target.closest('.studio-tabs') || target.closest('.lesson-editor-tabs')) {
      this.handleTabsNavigation(e);
    }
    
    // Card grids
    if (target.closest('.dashboard-grid') || target.closest('.courses-list')) {
      this.handleGridNavigation(e);
    }
  },

  /**
   * Handle menu navigation
   */
  handleMenuNavigation(e) {
    const menu = e.target.closest('.studio-nav') || e.target.closest('.nav-menu');
    const menuItems = Array.from(menu.querySelectorAll('a, button'));
    const currentIndex = menuItems.indexOf(e.target);
    
    let nextIndex;
    
    if (e.key === 'ArrowDown') {
      nextIndex = (currentIndex + 1) % menuItems.length;
      e.preventDefault();
    } else if (e.key === 'ArrowUp') {
      nextIndex = (currentIndex - 1 + menuItems.length) % menuItems.length;
      e.preventDefault();
    }
    
    if (nextIndex !== undefined) {
      menuItems[nextIndex].focus();
    }
  },

  /**
   * Handle tabs navigation
   */
  handleTabsNavigation(e) {
    const tabContainer = e.target.closest('.studio-tabs') || e.target.closest('.lesson-editor-tabs');
    const tabs = Array.from(tabContainer.querySelectorAll('[role="tab"], .studio-tab, .lesson-tab'));
    const currentIndex = tabs.indexOf(e.target);
    
    let nextIndex;
    
    if (e.key === 'ArrowRight') {
      nextIndex = (currentIndex + 1) % tabs.length;
      e.preventDefault();
    } else if (e.key === 'ArrowLeft') {
      nextIndex = (currentIndex - 1 + tabs.length) % tabs.length;
      e.preventDefault();
    }
    
    if (nextIndex !== undefined) {
      tabs[nextIndex].focus();
      tabs[nextIndex].click();
    }
  },

  /**
   * Handle grid navigation
   */
  handleGridNavigation(e) {
    const grid = e.target.closest('.dashboard-grid') || e.target.closest('.courses-list');
    const items = Array.from(grid.querySelectorAll('.card, .course-card'));
    const currentIndex = items.indexOf(e.target.closest('.card, .course-card'));
    
    if (currentIndex === -1) return;
    
    const gridColumns = this.getGridColumns(grid);
    let nextIndex;
    
    switch (e.key) {
      case 'ArrowRight':
        nextIndex = currentIndex + 1;
        break;
      case 'ArrowLeft':
        nextIndex = currentIndex - 1;
        break;
      case 'ArrowDown':
        nextIndex = currentIndex + gridColumns;
        break;
      case 'ArrowUp':
        nextIndex = currentIndex - gridColumns;
        break;
    }
    
    if (nextIndex !== undefined && nextIndex >= 0 && nextIndex < items.length) {
      const focusableElement = items[nextIndex].querySelector('a, button') || items[nextIndex];
      focusableElement.focus();
      e.preventDefault();
    }
  },

  /**
   * Handle activation (Enter/Space)
   */
  handleActivation(e) {
    const target = e.target;
    
    // Handle custom interactive elements
    if (target.hasAttribute('data-action') || target.classList.contains('interactive')) {
      if (e.key === 'Enter' || (e.key === ' ' && target.tagName !== 'INPUT' && target.tagName !== 'TEXTAREA')) {
        target.click();
        e.preventDefault();
      }
    }
  },

  /**
   * Add ARIA labels and attributes
   */
  addAriaLabels() {
    // Add labels to buttons without text
    const iconButtons = document.querySelectorAll('button:not([aria-label]):not([aria-labelledby])');
    iconButtons.forEach(button => {
      const icon = button.querySelector('i[class*="fa-"]');
      if (icon && !button.textContent.trim()) {
        const ariaLabel = this.getAriaLabelFromIcon(icon.className);
        if (ariaLabel) {
          button.setAttribute('aria-label', ariaLabel);
        }
      }
    });
    
    // Add labels to form inputs without labels
    const inputs = document.querySelectorAll('input:not([aria-label]):not([aria-labelledby])');
    inputs.forEach(input => {
      const label = document.querySelector(`label[for="${input.id}"]`);
      if (!label && input.placeholder) {
        input.setAttribute('aria-label', input.placeholder);
      }
    });
    
    // Add role attributes to interactive elements
    const interactiveElements = document.querySelectorAll('.card.interactive, .interactive');
    interactiveElements.forEach(element => {
      if (!element.getAttribute('role')) {
        element.setAttribute('role', 'button');
      }
      if (!element.hasAttribute('tabindex')) {
        element.setAttribute('tabindex', '0');
      }
    });
    
    // Add navigation landmarks
    const nav = document.querySelector('nav:not([aria-label])');
    if (nav) {
      nav.setAttribute('aria-label', 'メインナビゲーション');
    }
    
    // Add main landmark
    const main = document.querySelector('main:not([aria-label])');
    if (main) {
      main.setAttribute('aria-label', 'メインコンテンツ');
    }
  },

  /**
   * Setup live regions for dynamic content
   */
  setupLiveRegions() {
    // Create status live region
    const statusRegion = document.createElement('div');
    statusRegion.id = 'status-live-region';
    statusRegion.setAttribute('aria-live', 'polite');
    statusRegion.setAttribute('aria-atomic', 'true');
    statusRegion.className = 'sr-only';
    statusRegion.style.cssText = this.state.announcer.style.cssText;
    document.body.appendChild(statusRegion);
    
    // Create alert live region
    const alertRegion = document.createElement('div');
    alertRegion.id = 'alert-live-region';
    alertRegion.setAttribute('aria-live', 'assertive');
    alertRegion.setAttribute('aria-atomic', 'true');
    alertRegion.className = 'sr-only';
    alertRegion.style.cssText = this.state.announcer.style.cssText;
    document.body.appendChild(alertRegion);
  },

  /**
   * Enhance form accessibility
   */
  enhanceFormAccessibility() {
    // Add required indicators
    const requiredInputs = document.querySelectorAll('input[required], textarea[required], select[required]');
    requiredInputs.forEach(input => {
      input.setAttribute('aria-required', 'true');
      
      const label = document.querySelector(`label[for="${input.id}"]`);
      if (label && !label.textContent.includes('*')) {
        label.innerHTML += ' <span aria-label="必須">*</span>';
      }
    });
    
    // Add error handling
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
      form.addEventListener('submit', (e) => {
        this.validateForm(form, e);
      });
    });
    
    // Add input validation
    const inputs = document.querySelectorAll('input, textarea, select');
    inputs.forEach(input => {
      input.addEventListener('blur', () => {
        this.validateInput(input);
      });
    });
  },

  /**
   * Setup event listeners
   */
  setupEventListeners() {
    // Listen for focus changes
    document.addEventListener('focusin', (e) => {
      this.state.currentFocusedElement = e.target;
    });
    
    // Listen for theme changes
    document.addEventListener('theme-changed', () => {
      this.announce('テーマが変更されました');
    });
    
    // Listen for content changes
    document.addEventListener('content-service-course-created', () => {
      this.announce('新しいコースが作成されました');
    });
    
    document.addEventListener('learning-engine-lesson-completed', () => {
      this.announce('レッスンが完了しました');
    });
    
    // Listen for navigation changes
    window.addEventListener('hashchange', () => {
      const newSection = window.location.hash.substring(1);
      if (newSection) {
        this.announce(`${newSection}セクションに移動しました`);
      }
    });
  },

  /**
   * Get focusable elements
   */
  getFocusableElements() {
    const selector = 'a[href], button:not([disabled]), input:not([disabled]), textarea:not([disabled]), select:not([disabled]), [tabindex]:not([tabindex="-1"])';
    return Array.from(document.querySelectorAll(selector)).filter(el => {
      return el.offsetWidth > 0 && el.offsetHeight > 0;
    });
  },

  /**
   * Get grid columns count
   */
  getGridColumns(grid) {
    const computedStyle = window.getComputedStyle(grid);
    const gridTemplateColumns = computedStyle.gridTemplateColumns;
    
    if (gridTemplateColumns && gridTemplateColumns !== 'none') {
      return gridTemplateColumns.split(' ').length;
    }
    
    // Fallback: estimate based on container width and item width
    const containerWidth = grid.offsetWidth;
    const firstItem = grid.querySelector('.card, .course-card');
    if (firstItem) {
      const itemWidth = firstItem.offsetWidth;
      return Math.floor(containerWidth / itemWidth) || 1;
    }
    
    return 1;
  },

  /**
   * Get ARIA label from icon class
   */
  getAriaLabelFromIcon(iconClass) {
    const iconMap = {
      'fa-home': 'ホーム',
      'fa-user': 'ユーザー',
      'fa-cog': '設定',
      'fa-search': '検索',
      'fa-plus': '追加',
      'fa-edit': '編集',
      'fa-trash': '削除',
      'fa-save': '保存',
      'fa-download': 'ダウンロード',
      'fa-upload': 'アップロード',
      'fa-play': '再生',
      'fa-pause': '一時停止',
      'fa-stop': '停止',
      'fa-close': '閉じる',
      'fa-times': '閉じる',
      'fa-check': 'チェック',
      'fa-arrow-left': '戻る',
      'fa-arrow-right': '進む',
      'fa-chevron-left': '前へ',
      'fa-chevron-right': '次へ',
      'fa-menu': 'メニュー',
      'fa-bars': 'メニュー'
    };
    
    for (const [iconClass_, label] of Object.entries(iconMap)) {
      if (iconClass.includes(iconClass_)) {
        return label;
      }
    }
    
    return null;
  },

  /**
   * Validate form
   */
  validateForm(form, event) {
    const errors = [];
    const inputs = form.querySelectorAll('input[required], textarea[required], select[required]');
    
    inputs.forEach(input => {
      if (!input.value.trim()) {
        errors.push(`${this.getInputLabel(input)}は必須です`);
        this.showInputError(input, `${this.getInputLabel(input)}は必須です`);
      }
    });
    
    if (errors.length > 0) {
      event.preventDefault();
      this.announce(`フォームにエラーがあります: ${errors.join(', ')}`);
      
      // Focus first error
      const firstErrorInput = form.querySelector('.error');
      if (firstErrorInput) {
        firstErrorInput.focus();
      }
    }
  },

  /**
   * Validate input
   */
  validateInput(input) {
    this.clearInputError(input);
    
    if (input.hasAttribute('required') && !input.value.trim()) {
      this.showInputError(input, `${this.getInputLabel(input)}は必須です`);
      return false;
    }
    
    if (input.type === 'email' && input.value && !this.isValidEmail(input.value)) {
      this.showInputError(input, '有効なメールアドレスを入力してください');
      return false;
    }
    
    return true;
  },

  /**
   * Show input error
   */
  showInputError(input, message) {
    input.classList.add('error');
    input.setAttribute('aria-invalid', 'true');
    
    let errorElement = input.parentNode.querySelector('.error-message');
    if (!errorElement) {
      errorElement = document.createElement('div');
      errorElement.className = 'error-message';
      errorElement.style.cssText = 'color: var(--color-error, #dc3545); font-size: 0.85rem; margin-top: 0.25rem;';
      input.parentNode.appendChild(errorElement);
    }
    
    errorElement.textContent = message;
    input.setAttribute('aria-describedby', errorElement.id || 'error-' + Date.now());
  },

  /**
   * Clear input error
   */
  clearInputError(input) {
    input.classList.remove('error');
    input.removeAttribute('aria-invalid');
    
    const errorElement = input.parentNode.querySelector('.error-message');
    if (errorElement) {
      errorElement.remove();
    }
  },

  /**
   * Get input label
   */
  getInputLabel(input) {
    const label = document.querySelector(`label[for="${input.id}"]`);
    if (label) {
      return label.textContent.replace('*', '').trim();
    }
    
    return input.getAttribute('aria-label') || input.placeholder || 'フィールド';
  },

  /**
   * Validate email
   */
  isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  },

  /**
   * Announce message to screen readers
   */
  announce(message, priority = 'polite') {
    if (!this.state.announcer) return;
    
    setTimeout(() => {
      if (priority === 'assertive') {
        const alertRegion = document.getElementById('alert-live-region');
        if (alertRegion) {
          alertRegion.textContent = message;
          setTimeout(() => {
            alertRegion.textContent = '';
          }, 1000);
        }
      } else {
        this.state.announcer.textContent = message;
        setTimeout(() => {
          this.state.announcer.textContent = '';
        }, 1000);
      }
    }, this.config.announceDelay);
  },

  /**
   * Focus element with announcement
   */
  focusWithAnnouncement(element, message) {
    if (element) {
      element.focus();
      if (message) {
        this.announce(message);
      }
    }
  },

  /**
   * Add heading structure
   */
  addHeadingStructure() {
    const headings = document.querySelectorAll('h1, h2, h3, h4, h5, h6');
    let currentLevel = 0;
    
    headings.forEach(heading => {
      const level = parseInt(heading.tagName.substring(1));
      
      if (level > currentLevel + 1) {
        console.warn(`Heading level jump detected: ${heading.textContent}`);
      }
      
      currentLevel = level;
    });
  },

  /**
   * Get debug information
   */
  getDebugInfo() {
    return {
      isInitialized: this.state.isInitialized,
      reducedMotion: this.state.reducedMotion,
      highContrast: this.state.highContrast,
      currentFocusedElement: this.state.currentFocusedElement?.tagName || null,
      focusableElementsCount: this.getFocusableElements().length,
      config: this.config
    };
  }
};

// Auto-initialize when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    AccessibilityEnhancements.init();
  });
} else {
  AccessibilityEnhancements.init();
}

// Export for use in other modules
if (typeof window !== 'undefined') {
  window.AccessibilityEnhancements = AccessibilityEnhancements;
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = AccessibilityEnhancements;
}


/**
 * PROGEN Content Service
 * Manages learning content creation, validation, and storage
 */

'use strict';

const ContentService = {
  // Configuration
  config: {
    storageKey: 'progen_content',
    schemaVersion: '1.0.0',
    maxFileSize: 10 * 1024 * 1024, // 10MB
    supportedLanguages: ['python', 'html', 'css', 'javascript', 'go', 'rust', 'swift'],
    supportedMediaTypes: ['image', 'video', 'audio', 'document']
  },

  // State
  state: {
    isInitialized: false,
    currentContent: null,
    contentCache: new Map(),
    validationSchema: null
  },

  /**
   * Initialize content service
   */
  async init() {
    if (this.state.isInitialized) return;

    try {
      await this.loadSchema();
      await this.loadContent();
      this.setupEventListeners();
      
      this.state.isInitialized = true;
      this.dispatchEvent('content-service-initialized');
      console.log('📚 Content Service initialized!');
    } catch (error) {
      console.error('Failed to initialize Content Service:', error);
      throw error;
    }
  },

  /**
   * Load content schema
   */
  async loadSchema() {
    try {
      const response = await fetch('/data/content-schema.json');
      if (!response.ok) {
        throw new Error(`Failed to load schema: ${response.status}`);
      }
      
      this.state.validationSchema = await response.json();
      console.log('📋 Content schema loaded');
    } catch (error) {
      console.error('Failed to load content schema:', error);
      // Use fallback schema
      this.state.validationSchema = this.getFallbackSchema();
    }
  },

  /**
   * Load existing content
   */
  async loadContent() {
    try {
      // Try to load from server first
      const response = await fetch('/data/sample-content.json');
      if (response.ok) {
        const content = await response.json();
        this.state.currentContent = content;
        this.cacheContent(content);
        return;
      }
    } catch (error) {
      console.warn('Failed to load content from server:', error);
    }

    // Fallback to localStorage
    const stored = localStorage.getItem(this.config.storageKey);
    if (stored) {
      try {
        this.state.currentContent = JSON.parse(stored);
        this.cacheContent(this.state.currentContent);
      } catch (error) {
        console.error('Failed to parse stored content:', error);
        this.state.currentContent = this.getEmptyContent();
      }
    } else {
      this.state.currentContent = this.getEmptyContent();
    }
  },

  /**
   * Setup event listeners
   */
  setupEventListeners() {
    // Auto-save on content changes
    document.addEventListener('content-changed', () => {
      this.debounce(this.saveContent.bind(this), 2000)();
    });

    // Handle page unload
    window.addEventListener('beforeunload', () => {
      this.saveContent();
    });
  },

  /**
   * Get empty content structure
   */
  getEmptyContent() {
    return {
      schema: 'progen-content-v1',
      courses: []
    };
  },

  /**
   * Get fallback schema
   */
  getFallbackSchema() {
    return {
      $schema: "http://json-schema.org/draft-07/schema#",
      title: "PROGEN Content Schema",
      type: "object",
      properties: {
        schema: { const: "progen-content-v1" },
        courses: {
          type: "array",
          items: { type: "object" }
        }
      },
      required: ["schema", "courses"]
    };
  },

  /**
   * Cache content for quick access
   */
  cacheContent(content) {
    if (!content || !content.courses) return;

    content.courses.forEach(course => {
      this.state.contentCache.set(`course:${course.id}`, course);
      
      if (course.sections) {
        course.sections.forEach(section => {
          this.state.contentCache.set(`section:${section.id}`, section);
          
          if (section.lessons) {
            section.lessons.forEach(lesson => {
              this.state.contentCache.set(`lesson:${lesson.id}`, lesson);
            });
          }
        });
      }
    });
  },

  /**
   * Create new course
   */
  createCourse(courseData) {
    const course = {
      type: 'course',
      id: courseData.id || this.generateId('course'),
      title: courseData.title || 'New Course',
      description: courseData.description || '',
      language: courseData.language || 'python',
      icon: courseData.icon || '📚',
      color: courseData.color || '#3776ab',
      goal: courseData.goal || '',
      difficulty: courseData.difficulty || 'beginner',
      estimatedTime: courseData.estimatedTime || 60,
      tags: courseData.tags || [],
      status: 'draft',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      version: '1.0.0',
      author: courseData.author || 'PROGEN Team',
      pricing: {
        free: courseData.free !== false,
        price: courseData.price || 0,
        currency: 'JPY'
      },
      sections: []
    };

    this.state.currentContent.courses.push(course);
    this.cacheContent({ courses: [course] });
    this.dispatchEvent('course-created', { course });
    
    return course;
  },

  /**
   * Create new section
   */
  createSection(courseId, sectionData) {
    const course = this.getCourse(courseId);
    if (!course) {
      throw new Error(`Course not found: ${courseId}`);
    }

    const section = {
      type: 'section',
      id: sectionData.id || this.generateId('section'),
      title: sectionData.title || 'New Section',
      description: sectionData.description || '',
      order: sectionData.order || (course.sections.length + 1),
      difficulty: sectionData.difficulty || 'beginner',
      estimatedTime: sectionData.estimatedTime || 30,
      status: 'draft',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      version: '1.0.0',
      author: sectionData.author || 'PROGEN Team',
      lessons: [],
      unlockConditions: sectionData.unlockConditions || {
        previousSectionComplete: true
      }
    };

    course.sections.push(section);
    this.state.contentCache.set(`section:${section.id}`, section);
    this.dispatchEvent('section-created', { courseId, section });
    
    return section;
  },

  /**
   * Create new lesson
   */
  createLesson(sectionId, lessonData) {
    const section = this.getSection(sectionId);
    if (!section) {
      throw new Error(`Section not found: ${sectionId}`);
    }

    const lesson = {
      type: 'lesson',
      id: lessonData.id || this.generateId('lesson'),
      title: lessonData.title || 'New Lesson',
      description: lessonData.description || '',
      order: lessonData.order || (section.lessons.length + 1),
      difficulty: lessonData.difficulty || 'beginner',
      estimatedTime: lessonData.estimatedTime || 15,
      status: 'draft',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      version: '1.0.0',
      author: lessonData.author || 'PROGEN Team',
      objectives: lessonData.objectives || [],
      content: [],
      resources: lessonData.resources || []
    };

    section.lessons.push(lesson);
    this.state.contentCache.set(`lesson:${lesson.id}`, lesson);
    this.dispatchEvent('lesson-created', { sectionId, lesson });
    
    return lesson;
  },

  /**
   * Add content to lesson
   */
  addLessonContent(lessonId, contentData) {
    const lesson = this.getLesson(lessonId);
    if (!lesson) {
      throw new Error(`Lesson not found: ${lessonId}`);
    }

    const content = {
      type: contentData.type || 'slide',
      id: contentData.id || this.generateId(contentData.type || 'slide'),
      title: contentData.title || 'New Content',
      ...contentData
    };

    lesson.content.push(content);
    this.dispatchEvent('lesson-content-added', { lessonId, content });
    
    return content;
  },

  /**
   * Get course by ID
   */
  getCourse(courseId) {
    return this.state.contentCache.get(`course:${courseId}`) || 
           this.state.currentContent.courses.find(c => c.id === courseId);
  },

  /**
   * Get section by ID
   */
  getSection(sectionId) {
    return this.state.contentCache.get(`section:${sectionId}`);
  },

  /**
   * Get lesson by ID
   */
  getLesson(lessonId) {
    return this.state.contentCache.get(`lesson:${lessonId}`);
  },

  /**
   * Get all courses
   */
  getAllCourses() {
    return this.state.currentContent.courses || [];
  },

  /**
   * Update course
   */
  updateCourse(courseId, updates) {
    const course = this.getCourse(courseId);
    if (!course) {
      throw new Error(`Course not found: ${courseId}`);
    }

    Object.assign(course, updates, {
      updatedAt: new Date().toISOString()
    });

    this.state.contentCache.set(`course:${courseId}`, course);
    this.dispatchEvent('course-updated', { courseId, course });
    
    return course;
  },

  /**
   * Update section
   */
  updateSection(sectionId, updates) {
    const section = this.getSection(sectionId);
    if (!section) {
      throw new Error(`Section not found: ${sectionId}`);
    }

    Object.assign(section, updates, {
      updatedAt: new Date().toISOString()
    });

    this.state.contentCache.set(`section:${sectionId}`, section);
    this.dispatchEvent('section-updated', { sectionId, section });
    
    return section;
  },

  /**
   * Update lesson
   */
  updateLesson(lessonId, updates) {
    const lesson = this.getLesson(lessonId);
    if (!lesson) {
      throw new Error(`Lesson not found: ${lessonId}`);
    }

    Object.assign(lesson, updates, {
      updatedAt: new Date().toISOString()
    });

    this.state.contentCache.set(`lesson:${lessonId}`, lesson);
    this.dispatchEvent('lesson-updated', { lessonId, lesson });
    
    return lesson;
  },

  /**
   * Delete course
   */
  deleteCourse(courseId) {
    const courseIndex = this.state.currentContent.courses.findIndex(c => c.id === courseId);
    if (courseIndex === -1) {
      throw new Error(`Course not found: ${courseId}`);
    }

    const course = this.state.currentContent.courses[courseIndex];
    
    // Remove from cache
    this.state.contentCache.delete(`course:${courseId}`);
    
    // Remove sections and lessons from cache
    if (course.sections) {
      course.sections.forEach(section => {
        this.state.contentCache.delete(`section:${section.id}`);
        if (section.lessons) {
          section.lessons.forEach(lesson => {
            this.state.contentCache.delete(`lesson:${lesson.id}`);
          });
        }
      });
    }

    // Remove from content
    this.state.currentContent.courses.splice(courseIndex, 1);
    this.dispatchEvent('course-deleted', { courseId });
    
    return true;
  },

  /**
   * Validate content against schema
   */
  validateContent(content = null) {
    const targetContent = content || this.state.currentContent;
    
    if (!this.state.validationSchema) {
      return { valid: false, errors: ['Schema not loaded'] };
    }

    try {
      // Simple validation for now
      if (!targetContent.schema || targetContent.schema !== 'progen-content-v1') {
        return { valid: false, errors: ['Invalid schema version'] };
      }

      if (!Array.isArray(targetContent.courses)) {
        return { valid: false, errors: ['Courses must be an array'] };
      }

      const errors = [];
      
      targetContent.courses.forEach((course, index) => {
        if (!course.id || !course.title || !course.language) {
          errors.push(`Course ${index}: Missing required fields (id, title, language)`);
        }
        
        if (course.sections) {
          course.sections.forEach((section, sIndex) => {
            if (!section.id || !section.title) {
              errors.push(`Course ${index}, Section ${sIndex}: Missing required fields (id, title)`);
            }
          });
        }
      });

      return {
        valid: errors.length === 0,
        errors
      };
    } catch (error) {
      return {
        valid: false,
        errors: [`Validation error: ${error.message}`]
      };
    }
  },

  /**
   * Save content to storage
   */
  saveContent() {
    try {
      const contentString = JSON.stringify(this.state.currentContent, null, 2);
      localStorage.setItem(this.config.storageKey, contentString);
      this.dispatchEvent('content-saved');
      return true;
    } catch (error) {
      console.error('Failed to save content:', error);
      this.dispatchEvent('content-save-failed', { error });
      return false;
    }
  },

  /**
   * Export content as JSON
   */
  exportContent() {
    const validation = this.validateContent();
    if (!validation.valid) {
      throw new Error(`Content validation failed: ${validation.errors.join(', ')}`);
    }

    const blob = new Blob([JSON.stringify(this.state.currentContent, null, 2)], {
      type: 'application/json'
    });
    
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `progen-content-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    this.dispatchEvent('content-exported');
    return true;
  },

  /**
   * Import content from JSON
   */
  async importContent(file) {
    if (!file) {
      throw new Error('No file provided');
    }

    if (file.size > this.config.maxFileSize) {
      throw new Error('File too large');
    }

    try {
      const text = await file.text();
      const content = JSON.parse(text);
      
      const validation = this.validateContent(content);
      if (!validation.valid) {
        throw new Error(`Invalid content: ${validation.errors.join(', ')}`);
      }

      this.state.currentContent = content;
      this.cacheContent(content);
      this.saveContent();
      
      this.dispatchEvent('content-imported', { content });
      return content;
    } catch (error) {
      console.error('Failed to import content:', error);
      throw error;
    }
  },

  /**
   * Generate unique ID
   */
  generateId(prefix = 'item') {
    const timestamp = Date.now().toString(36);
    const random = Math.random().toString(36).substr(2, 5);
    return `${prefix}-${timestamp}-${random}`;
  },

  /**
   * Debounce function
   */
  debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
      const later = () => {
        clearTimeout(timeout);
        func(...args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    };
  },

  /**
   * Dispatch custom event
   */
  dispatchEvent(eventType, detail = {}) {
    const event = new CustomEvent(`content-service-${eventType}`, {
      detail,
      bubbles: true
    });
    document.dispatchEvent(event);
  },

  /**
   * Add event listener
   */
  addEventListener(eventType, callback) {
    document.addEventListener(`content-service-${eventType}`, callback);
  },

  /**
   * Remove event listener
   */
  removeEventListener(eventType, callback) {
    document.removeEventListener(`content-service-${eventType}`, callback);
  },

  /**
   * Get debug information
   */
  getDebugInfo() {
    return {
      isInitialized: this.state.isInitialized,
      coursesCount: this.state.currentContent?.courses?.length || 0,
      cacheSize: this.state.contentCache.size,
      schemaLoaded: !!this.state.validationSchema,
      config: this.config
    };
  }
};

// Auto-initialize when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    ContentService.init().catch(console.error);
  });
} else {
  ContentService.init().catch(console.error);
}

// Export for use in other modules
if (typeof window !== 'undefined') {
  window.ContentService = ContentService;
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = ContentService;
}


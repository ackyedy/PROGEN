/**
 * PROGEN Scroll Effects - Neo-Brutalism Enhanced
 * 
 * Provides smooth scroll animations and effects for the PROGEN homepage
 */

'use strict';

const ScrollEffects = {
  // Animation state
  animationState: {
    isInitialized: false,
    observers: [],
    scrollPosition: 0,
    isScrolling: false,
    scrollTimeout: null
  },

  /**
   * Initialize scroll effects
   */
  init() {
    if (this.animationState.isInitialized) return;
    
    try {
      this.setupIntersectionObserver();
      this.setupParallaxEffects();
      this.setupScrollSnap();
      this.setupProgressIndicator();
      
      this.animationState.isInitialized = true;
      console.log('Scroll effects initialized successfully! 🎯');
    } catch (error) {
      console.error('Failed to initialize scroll effects:', error);
    }
  },

  /**
   * Setup intersection observer for reveal animations
   */
  setupIntersectionObserver() {
    const observerOptions = {
      threshold: [0.1, 0.3, 0.5, 0.7],
      rootMargin: '-50px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          this.animateElement(entry.target, entry.intersectionRatio);
        }
      });
    }, observerOptions);

    // Observe all panels and cards
    const elementsToObserve = [
      '.panel',
      '.course-card',
      '.stat-card',
      '.plan',
      '.faq details'
    ];

    elementsToObserve.forEach(selector => {
      document.querySelectorAll(selector).forEach(element => {
        observer.observe(element);
      });
    });

    this.animationState.observers.push(observer);
  },

  /**
   * Animate element based on intersection ratio
   */
  animateElement(element, ratio) {
    const animationType = element.dataset.animation || 'fade-up';
    const delay = element.dataset.delay || 0;
    
    setTimeout(() => {
      switch (animationType) {
        case 'slide-left':
          this.slideFromLeft(element, ratio);
          break;
        case 'slide-right':
          this.slideFromRight(element, ratio);
          break;
        case 'scale-up':
          this.scaleUp(element, ratio);
          break;
        case 'brutal-bounce':
          this.brutalBounce(element, ratio);
          break;
        default:
          this.fadeUp(element, ratio);
      }
    }, delay);
  },

  /**
   * Fade up animation
   */
  fadeUp(element, ratio) {
    const progress = Math.min(ratio * 2, 1);
    element.style.transform = `translateY(${(1 - progress) * 50}px)`;
    element.style.opacity = progress;
  },

  /**
   * Slide from left animation
   */
  slideFromLeft(element, ratio) {
    const progress = Math.min(ratio * 2, 1);
    element.style.transform = `translateX(${(1 - progress) * -100}px)`;
    element.style.opacity = progress;
  },

  /**
   * Slide from right animation
   */
  slideFromRight(element, ratio) {
    const progress = Math.min(ratio * 2, 1);
    element.style.transform = `translateX(${(1 - progress) * 100}px)`;
    element.style.opacity = progress;
  },

  /**
   * Scale up animation
   */
  scaleUp(element, ratio) {
    const progress = Math.min(ratio * 2, 1);
    const scale = 0.8 + (progress * 0.2);
    element.style.transform = `scale(${scale})`;
    element.style.opacity = progress;
  },

  /**
   * Brutal bounce animation (Neo-Brutalism style)
   */
  brutalBounce(element, ratio) {
    if (ratio > 0.3) {
      element.style.animation = 'brutal-bounce 0.8s cubic-bezier(0.68, -0.55, 0.265, 1.55) forwards';
    }
  },

  /**
   * Setup parallax effects
   */
  setupParallaxEffects() {
    const parallaxElements = document.querySelectorAll('[data-parallax]');
    
    if (parallaxElements.length === 0) return;

    const handleScroll = () => {
      const scrolled = window.pageYOffset;
      const rate = scrolled * -0.5;

      parallaxElements.forEach(element => {
        const speed = element.dataset.parallax || 0.5;
        const yPos = -(scrolled * speed);
        element.style.transform = `translateY(${yPos}px)`;
      });
    };

    // Throttled scroll handler
    let ticking = false;
    const scrollHandler = () => {
      if (!ticking) {
        requestAnimationFrame(() => {
          handleScroll();
          ticking = false;
        });
        ticking = true;
      }
    };

    window.addEventListener('scroll', scrollHandler, { passive: true });
  },

  /**
   * Setup scroll snap behavior
   */
  setupScrollSnap() {
    const sections = document.querySelectorAll('.panel');
    
    sections.forEach((section, index) => {
      section.style.scrollSnapAlign = 'start';
      section.dataset.sectionIndex = index;
    });

    // Add smooth scroll behavior to navigation links
    document.querySelectorAll('a[href^="#"]').forEach(link => {
      link.addEventListener('click', (e) => {
        e.preventDefault();
        const targetId = link.getAttribute('href');
        const targetElement = document.querySelector(targetId);
        
        if (targetElement) {
          targetElement.scrollIntoView({
            behavior: 'smooth',
            block: 'start'
          });
        }
      });
    });
  },

  /**
   * Setup scroll progress indicator
   */
  setupProgressIndicator() {
    // Create progress bar
    const progressBar = document.createElement('div');
    progressBar.className = 'scroll-progress';
    progressBar.innerHTML = '<div class="scroll-progress-bar"></div>';
    document.body.appendChild(progressBar);

    // Update progress on scroll
    const updateProgress = () => {
      const scrollTop = window.pageYOffset;
      const docHeight = document.documentElement.scrollHeight - window.innerHeight;
      const scrollPercent = (scrollTop / docHeight) * 100;
      
      const progressBarElement = progressBar.querySelector('.scroll-progress-bar');
      progressBarElement.style.width = `${scrollPercent}%`;
    };

    let ticking = false;
    const scrollHandler = () => {
      if (!ticking) {
        requestAnimationFrame(() => {
          updateProgress();
          ticking = false;
        });
        ticking = true;
      }
    };

    window.addEventListener('scroll', scrollHandler, { passive: true });
  },

  /**
   * Add brutal bounce keyframes to CSS
   */
  addBrutalBounceCSS() {
    const style = document.createElement('style');
    style.textContent = `
      @keyframes brutal-bounce {
        0% {
          transform: translateY(50px) scale(0.8);
          opacity: 0;
        }
        50% {
          transform: translateY(-10px) scale(1.05);
          opacity: 0.8;
        }
        100% {
          transform: translateY(0) scale(1);
          opacity: 1;
        }
      }
      
      .scroll-progress {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 4px;
        background: rgba(0, 0, 0, 0.1);
        z-index: 1000;
        pointer-events: none;
      }
      
      .scroll-progress-bar {
        height: 100%;
        background: linear-gradient(90deg, var(--primary-color) 0%, var(--accent-color) 100%);
        width: 0%;
        transition: width 0.1s ease;
      }
      
      html[data-theme="dark"] .scroll-progress {
        background: rgba(255, 255, 255, 0.1);
      }
    `;
    document.head.appendChild(style);
  },

  /**
   * Cleanup scroll effects
   */
  cleanup() {
    this.animationState.observers.forEach(observer => {
      observer.disconnect();
    });
    this.animationState.observers = [];
    this.animationState.isInitialized = false;
  }
};

// Auto-initialize when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    ScrollEffects.addBrutalBounceCSS();
    ScrollEffects.init();
  });
} else {
  ScrollEffects.addBrutalBounceCSS();
  ScrollEffects.init();
}

// Export for use in other modules
if (typeof window !== 'undefined') {
  window.ScrollEffects = ScrollEffects;
}


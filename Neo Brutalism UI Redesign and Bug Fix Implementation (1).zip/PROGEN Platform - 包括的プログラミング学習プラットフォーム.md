# PROGEN Platform - 包括的プログラミング学習プラットフォーム

## 概要

PROGEN Platform は、Neo Brutalism デザインを採用した現代的なプログラミング学習プラットフォームです。インタラクティブな学習体験、包括的なコンテンツ管理システム、アクセシビリティ対応、パフォーマンス最適化を特徴としています。

## 🎯 プロジェクト概要

このプラットフォームは3つの主要コンポーネントで構成されています：

**PROGEN Studio（コンテンツマネージャー）**
講座を簡単に作成・編集できるGUIツール。テンプレートから始めて、スライド・練習問題・テストケースを視覚的に編集できます。

**PROGEN Learn（レッスンプレイヤー）**
学習者向けのインターフェース。スライドでの解説→Monaco Editorでのコード実践→自動採点の学習フローを提供します。

**自動採点システム**
HTML/CSS/JavaScript/Python対応の多言語採点エンジン。静的解析と実行時テストの両方をサポートし、Web Workerで安全に実行します。

## 🚀 主要機能

### 🎨 Neo Brutalism デザインシステム
- 太いアウトライン（3px solid）による明確な境界
- はっきりした配色（黄色、赤、緑、青）
- フラットな面とドロップシャドウ効果
- ステッカー風アクセント
- 大胆なタイポグラフィ

### 🌓 高度なテーママネージャー
- ライト/ダークテーマの自動切り替え
- 時間帯ベースの自動テーマ変更
- OSのprefers-color-scheme対応
- ローカルストレージによる設定永続化
- CSS変数（デザイントークン）による統一管理

### 🔐 認証・ユーザー管理システム
- ロールベースアクセス制御（学習者/講師/管理者）
- セキュアな認証フロー
- ユーザープロファイル管理
- 進捗データの同期

### 📚 コンテンツ管理システム（Studio）
- 直感的なCRUD操作
- ドラッグ&ドロップによる並べ替え
- リアルタイムプレビュー
- 公開/下書き状態管理
- バリデーション機能

### 🎓 学習プラットフォーム
- インタラクティブなコードエディタ
- Web Workerによる安全なコード実行
- 自動採点システム
- 進捗追跡とバッジシステム
- ヒント機能

### ♿ アクセシビリティ対応
- WCAG 2.1 AA準拠
- キーボードナビゲーション
- スクリーンリーダー対応
- フォーカス管理
- 高コントラストモード

### ⚡ パフォーマンス最適化
- 画像の遅延読み込み
- フォント最適化
- クリティカルCSS抽出
- CLS（Cumulative Layout Shift）対策
- リソースヒント実装

## 🏗️ システム構成

```
progen_platform/
├── config.js                          # 設定管理
├── shared/                            # 共通コンポーネント
│   ├── design-system.css             # デザインシステム
│   ├── theme-manager-enhanced.js     # テーママネージャー
│   ├── user-service.js               # ユーザーサービス
│   ├── auth-enhanced.js              # 認証システム
│   ├── content-service.js            # コンテンツサービス
│   ├── learning-engine.js            # 学習エンジン
│   ├── accessibility-enhancements.js # アクセシビリティ
│   ├── performance-optimizer.js      # パフォーマンス最適化
│   ├── navigation-enhanced.js        # ナビゲーション
│   ├── ui-components.js              # UIコンポーネント
│   ├── toast-notifications.js       # 通知システム
│   └── route-guard.js                # ルートガード
├── progen_home/                       # ホームページ
│   ├── index-enhanced.html           # 改良版ホームページ
│   └── assets/
├── progen_studio/                     # コンテンツ管理
│   └── index.html                    # Studio インターフェース
├── progen_learn/                      # 学習プラットフォーム
│   └── index.html                    # 学習インターフェース
├── data/                             # データファイル
│   ├── users.json                    # ユーザーデータ
│   ├── content-schema.json           # コンテンツスキーマ
│   └── sample-content.json           # サンプルコンテンツ
├── test-results.md                   # テスト結果
└── README.md                         # このファイル
```

## セットアップ

### 必要環境
- Python 3.x（開発サーバー用）
- モダンブラウザ（Chrome, Firefox, Safari, Edge）

### ローカル開発環境の起動

```bash
# プロジェクトディレクトリに移動
cd progen_platform

# 開発サーバーを起動
python3 -m http.server 8080

# ブラウザでアクセス
# ホームページ: http://localhost:8080/progen_home/index-enhanced.html
# Studio: http://localhost:8080/progen_studio/index.html
# 学習プラットフォーム: http://localhost:8080/progen_learn/index.html
```

## 設定管理

### config.js
プラットフォーム全体の設定は `config.js` で一元管理されています。

```javascript
const CONFIG = {
  // API設定
  api: {
    baseUrl: '/api',
    timeout: 30000
  },
  
  // テーマ設定
  theme: {
    autoSwitch: true,
    timeBasedSwitching: true,
    respectSystemPreference: true
  },
  
  // 学習エンジン設定
  learning: {
    maxAttempts: 3,
    timeoutDuration: 30000,
    autoSaveInterval: 30000
  }
};
```

## デザインシステム

### CSS変数（デザイントークン）
```css
:root {
  /* カラーパレット */
  --color-bg: #f5f5f5;
  --color-fg: #1a1a1a;
  --color-primary: #ffcc00;
  --color-accent: #ff0000;
  --color-success: #28a745;
  --color-error: #dc3545;
  --color-warning: #ffc107;
  --color-info: #17a2b8;
  
  /* タイポグラフィ */
  --font-sans: 'Noto Sans JP', sans-serif;
  --font-mono: 'Roboto Mono', monospace;
  
  /* レイアウト */
  --radius: 8px;
  --shadow: 4px 4px 0px var(--color-fg);
  --outline: 3px solid var(--color-fg);
  
  /* アニメーション */
  --duration-fast: 0.15s;
  --duration-normal: 0.3s;
  --duration-slow: 0.6s;
  --ease-out: cubic-bezier(0.25, 0.46, 0.45, 0.94);
}
```

### Neo Brutalism 原則
1. **明確な境界**: 太いアウトライン（3px solid）
2. **はっきりした配色**: 高コントラストカラー
3. **フラットデザイン**: グラデーションを避ける
4. **ドロップシャドウ**: 4px 4px 0px の影
5. **大胆なタイポグラフィ**: 太字とコントラスト

## アクセシビリティ

### 実装済み機能
- **キーボードナビゲーション**: Tab, Arrow keys, Enter, Escape
- **スクリーンリーダー対応**: aria-label, aria-describedby, live regions
- **フォーカス管理**: 明確なフォーカスインジケーター
- **色のコントラスト**: 4.5:1以上のコントラスト比
- **スキップリンク**: メインコンテンツへの直接アクセス

### キーボードショートカット
- `Tab` / `Shift+Tab`: フォーカス移動
- `Enter` / `Space`: 要素の活性化
- `Escape`: モーダル/ドロップダウンを閉じる
- `Arrow Keys`: メニュー/グリッドナビゲーション

## パフォーマンス

### 最適化実装
- **画像最適化**: lazy loading, decoding="async", サイズ指定
- **フォント最適化**: font-display: swap, preload
- **CSS最適化**: クリティカルCSS抽出, 不要な!important削除
- **JavaScript最適化**: Web Worker, debounce/throttle
- **リソースヒント**: preconnect, dns-prefetch

### 目標パフォーマンス指標
- **Lighthouse Performance**: 85-90点
- **First Contentful Paint**: < 1.8秒
- **Largest Contentful Paint**: < 2.5秒
- **Cumulative Layout Shift**: < 0.1
- **First Input Delay**: < 100ms

## 学習コンテンツ構造

### コンテンツスキーマ
```json
{
  "course": {
    "id": "string",
    "title": "string",
    "language": "html|css|javascript|python",
    "difficulty": "基礎|標準|応用",
    "sections": [
      {
        "id": "string",
        "title": "string",
        "lessons": [
          {
            "id": "string",
            "title": "string",
            "content": [
              {
                "type": "slide|challenge|quiz",
                "title": "string",
                "content": "string"
              }
            ]
          }
        ]
      }
    ]
  }
}
```

### 学習フロー
1. **導入スライド**: 概念の説明
2. **コードエディタ課題**: 実践的なプログラミング
3. **自動採点**: テストケースによる評価
4. **フィードバック**: 結果とヒント
5. **進捗保存**: ローカルストレージに保存

## 開発ガイドライン

### コーディング規約
- **CSS**: BEMまたはユーティリティクラス方式
- **JavaScript**: ES6+ モジュール形式
- **HTML**: セマンティックマークアップ
- **アクセシビリティ**: WCAG 2.1 AA準拠

### ファイル命名規則
- **CSS**: kebab-case（例: design-system.css）
- **JavaScript**: camelCase（例: themeManager.js）
- **HTML**: kebab-case（例: index-enhanced.html）

### Git ワークフロー
1. feature ブランチで開発
2. プルリクエストでレビュー
3. main ブランチにマージ
4. 自動デプロイ

## テスト

### テスト項目
- **機能テスト**: 全機能の動作確認
- **アクセシビリティテスト**: WCAG準拠確認
- **パフォーマンステスト**: Lighthouse監査
- **レスポンシブテスト**: 各デバイスでの表示確認
- **ブラウザテスト**: クロスブラウザ対応確認

### テスト結果
詳細なテスト結果は `test-results.md` を参照してください。

## デプロイ

### 本番環境要件
- **Webサーバー**: Nginx, Apache, または静的ホスティング
- **HTTPS**: SSL証明書必須
- **CDN**: 静的アセットの配信最適化
- **モニタリング**: パフォーマンス監視

### デプロイ手順
1. 本番用設定の確認
2. アセットの最適化
3. セキュリティヘッダーの設定
4. パフォーマンステスト
5. 本番環境へのデプロイ

## トラブルシューティング

### よくある問題

#### テーマが切り替わらない
- ブラウザのローカルストレージを確認
- CSS変数の読み込みを確認
- JavaScriptエラーをコンソールで確認

#### コンテンツが表示されない
- JSONファイルのパスを確認
- CORSエラーをコンソールで確認
- ネットワークタブでリクエストを確認

#### パフォーマンスが悪い
- 画像サイズと形式を確認
- 不要なJavaScriptを削除
- CSSの最適化を実行

## 貢献

### 開発に参加する方法
1. リポジトリをフォーク
2. feature ブランチを作成
3. 変更を実装
4. テストを実行
5. プルリクエストを作成

### 報告・提案
- バグ報告: GitHub Issues
- 機能提案: GitHub Discussions
- セキュリティ問題: security@progen.example.com

## ライセンス

このプロジェクトは MIT ライセンスの下で公開されています。

## 更新履歴

### v1.0.0 (2025-09-21)
- Neo Brutalism デザインシステム実装
- テーママネージャー実装
- 認証システム改善
- コンテンツ管理システム構築
- 学習プラットフォーム改善
- アクセシビリティ対応
- パフォーマンス最適化
- 統合テスト完了

## サポート

技術的な質問やサポートが必要な場合は、以下の方法でお問い合わせください：

- **ドキュメント**: このREADMEファイル
- **テスト結果**: test-results.md
- **設定ファイル**: config.js
- **デザインシステム**: shared/design-system.css

---

**PROGEN Platform** - 現代的で包括的なプログラミング学習体験を提供します。


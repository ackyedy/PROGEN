/**
 * PROGEN Platform - Route Guard System (Fixed)
 * 
 * This system provides:
 * 1. Role-based access control for different routes
 * 2. Automatic redirection for unauthorized access
 * 3. Integration with UserService
 * 4. Support for both hash-based and path-based routing
 */

class RouteGuard {
  constructor() {
    this.routes = new Map();
    this.currentRoute = null;
    this.redirectAfterLogin = null;
    
    this.init();
  }

  init() {
    // Wait for UserService to be available
    this.waitForUserService().then(() => {
      this.setupRoutes();
      this.setupEventListeners();
      this.checkCurrentRoute();
    });
  }

  async waitForUserService() {
    return new Promise((resolve) => {
      const checkService = () => {
        if (window.userService) {
          resolve();
        } else {
          setTimeout(checkService, 100);
        }
      };
      checkService();
    });
  }

  /**
   * Define route access rules
   */
  setupRoutes() {
    // Public routes (no authentication required)
    this.addRoute('/', { public: true });
    this.addRoute('/progen_home/', { public: true });
    this.addRoute('/progen_home/index.html', { public: true });
    
    // Student routes
    this.addRoute('/progen_learn/', { roles: ['student', 'teacher', 'admin'] });
    this.addRoute('/progen_learn/index.html', { roles: ['student', 'teacher', 'admin'] });
    this.addRoute('/progen_learn/lesson.html', { roles: ['student', 'teacher', 'admin'] });
    
    // Teacher routes
    this.addRoute('/progen_studio/', { roles: ['teacher', 'admin'] });
    this.addRoute('/progen_studio/index.html', { roles: ['teacher', 'admin'] });
    
    // Admin routes
    this.addRoute('/admin/', { roles: ['admin'] });
    this.addRoute('/admin/users.html', { roles: ['admin'] });
    this.addRoute('/admin/analytics.html', { roles: ['admin'] });
  }

  /**
   * Add a route with access rules
   */
  addRoute(path, rules) {
    this.routes.set(path, rules);
  }

  /**
   * Set up event listeners
   */
  setupEventListeners() {
    // Listen for authentication changes
    document.addEventListener('authchange', (event) => {
      this.handleAuthChange(event.detail);
    });

    // Listen for hash changes (for hash-based routing)
    window.addEventListener('hashchange', () => {
      this.checkCurrentRoute();
    });

    // Listen for popstate (for history API routing)
    window.addEventListener('popstate', () => {
      this.checkCurrentRoute();
    });
  }

  /**
   * Handle authentication state changes
   */
  handleAuthChange(authDetail) {
    const { type, isAuthenticated } = authDetail;
    
    if (type === 'login' && this.redirectAfterLogin) {
      // Redirect to intended page after login
      const redirectTo = this.redirectAfterLogin;
      this.redirectAfterLogin = null;
      this.navigateTo(redirectTo);
    } else if (type === 'logout') {
      // Redirect to home page after logout
      this.navigateTo('/progen_home/');
    } else {
      // Check current route access
      this.checkCurrentRoute();
    }
  }

  /**
   * Get current route path
   */
  getCurrentPath() {
    // Support both hash-based and path-based routing
    const hash = window.location.hash.slice(1);
    if (hash) {
      return hash;
    }
    return window.location.pathname;
  }

  /**
   * Check if current route is accessible
   */
  checkCurrentRoute() {
    const currentPath = this.getCurrentPath();
    this.currentRoute = currentPath;
    
    const access = this.checkRouteAccess(currentPath);
    
    if (!access.allowed) {
      this.handleUnauthorizedAccess(currentPath, access.reason);
    }
  }

  /**
   * Check if user can access a specific route
   */
  checkRouteAccess(path) {
    // Find matching route rule
    const rules = this.findRouteRules(path);
    
    if (!rules) {
      // No specific rules, assume public access
      return { allowed: true };
    }

    // Check if route is public
    if (rules.public) {
      return { allowed: true };
    }

    // Check authentication
    if (!window.userService.isAuthenticated()) {
      return { 
        allowed: false, 
        reason: 'authentication_required',
        message: 'ログインが必要です'
      };
    }

    // Check role-based access
    if (rules.roles && rules.roles.length > 0) {
      const userRole = window.userService.getCurrentUser()?.role;
      if (!rules.roles.includes(userRole)) {
        return { 
          allowed: false, 
          reason: 'insufficient_permissions',
          message: 'このページにアクセスする権限がありません'
        };
      }
    }

    // Check permission-based access
    if (rules.permissions && rules.permissions.length > 0) {
      const hasPermission = rules.permissions.some(permission => 
        window.userService.hasPermission(permission)
      );
      if (!hasPermission) {
        return { 
          allowed: false, 
          reason: 'insufficient_permissions',
          message: 'このページにアクセスする権限がありません'
        };
      }
    }

    return { allowed: true };
  }

  /**
   * Find route rules for a given path
   */
  findRouteRules(path) {
    // Exact match first
    if (this.routes.has(path)) {
      return this.routes.get(path);
    }

    // Pattern matching (simple implementation)
    for (const [routePath, rules] of this.routes) {
      if (this.matchRoute(path, routePath)) {
        return rules;
      }
    }

    return null;
  }

  /**
   * Simple route matching
   */
  matchRoute(path, pattern) {
    // Convert pattern to regex
    const regexPattern = pattern
      .replace(/\*/g, '.*')
      .replace(/\?/g, '\\?');
    
    const regex = new RegExp(`^${regexPattern}$`);
    return regex.test(path);
  }

  /**
   * Handle unauthorized access
   */
  handleUnauthorizedAccess(path, reason) {
    if (reason === 'authentication_required') {
      // Store intended destination for after login
      this.redirectAfterLogin = path;
      
      // Show login prompt
      this.showLoginPrompt();
      
      // Redirect to home page
      this.navigateTo('/progen_home/');
      
    } else if (reason === 'insufficient_permissions') {
      // Show access denied message
      this.showAccessDeniedMessage();
      
      // Redirect to appropriate page based on user role
      const user = window.userService.getCurrentUser();
      if (user) {
        switch (user.role) {
          case 'student':
            this.navigateTo('/progen_learn/');
            break;
          case 'teacher':
            this.navigateTo('/progen_studio/');
            break;
          case 'admin':
            this.navigateTo('/admin/');
            break;
          default:
            this.navigateTo('/progen_home/');
        }
      } else {
        this.navigateTo('/progen_home/');
      }
    }
  }

  /**
   * Show login prompt
   */
  showLoginPrompt() {
    if (window.toastNotifications) {
      window.toastNotifications.show({
        type: 'info',
        title: 'ログインが必要です',
        message: 'このページにアクセスするにはログインしてください。',
        duration: 5000
      });
    } else {
      alert('このページにアクセスするにはログインしてください。');
    }
  }

  /**
   * Show access denied message
   */
  showAccessDeniedMessage() {
    if (window.toastNotifications) {
      window.toastNotifications.show({
        type: 'error',
        title: 'アクセス拒否',
        message: 'このページにアクセスする権限がありません。',
        duration: 5000
      });
    } else {
      alert('このページにアクセスする権限がありません。');
    }
  }

  /**
   * Navigate to a specific path
   */
  navigateTo(path) {
    // Support both hash-based and path-based routing
    if (path.startsWith('#')) {
      window.location.hash = path.slice(1);
    } else if (path.startsWith('/')) {
      // For static sites, we'll use hash-based routing
      window.location.hash = path;
    } else {
      window.location.href = path;
    }
  }

  /**
   * Check if user can access a route (public API)
   */
  canAccess(path) {
    return this.checkRouteAccess(path).allowed;
  }

  /**
   * Get user's default route based on role
   */
  getDefaultRoute() {
    const user = window.userService.getCurrentUser();
    if (!user) {
      return '/progen_home/';
    }

    switch (user.role) {
      case 'student':
        return '/progen_learn/';
      case 'teacher':
        return '/progen_studio/';
      case 'admin':
        return '/admin/';
      default:
        return '/progen_home/';
    }
  }

  /**
   * Redirect to user's default route
   */
  redirectToDefault() {
    const defaultRoute = this.getDefaultRoute();
    this.navigateTo(defaultRoute);
  }

  /**
   * Add middleware for route checking
   */
  addMiddleware(middleware) {
    // For future extensibility
    this.middleware = this.middleware || [];
    this.middleware.push(middleware);
  }
}

// Initialize RouteGuard when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    window.routeGuard = new RouteGuard();
  });
} else {
  window.routeGuard = new RouteGuard();
}

// Export for module systems
if (typeof module !== 'undefined' && module.exports) {
  module.exports = RouteGuard;
}


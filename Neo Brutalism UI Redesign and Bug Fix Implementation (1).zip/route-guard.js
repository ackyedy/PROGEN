/**
 * PROGEN Route Guard System
 * Role-based access control for different pages and features
 */

'use strict';

const RouteGuard = {
  // Configuration
  config: {
    routes: {
      // Public routes (no authentication required)
      public: [
        '/',
        '/index.html',
        '/progen_home/',
        '/progen_home/index.html'
      ],
      
      // Student routes (requires student or admin role)
      student: [
        '/progen_learn/',
        '/progen_learn/lesson.html',
        '/progen_dashboard/',
        '/progen_dashboard/dashboard.html',
        '/courses/',
        '/progress/'
      ],
      
      // Admin routes (requires admin role)
      admin: [
        '/progen_studio/',
        '/progen_studio/index.html',
        '/admin/',
        '/analytics/'
      ]
    },
    
    redirects: {
      unauthorized: '/progen_home/',
      loginRequired: '/progen_home/',
      adminRequired: '/progen_home/'
    }
  },

  // State
  state: {
    isInitialized: false,
    currentRoute: null,
    currentUser: null,
    routeHistory: []
  },

  /**
   * Initialize the route guard system
   */
  init() {
    if (this.state.isInitialized) return;

    try {
      // Load configuration from ProgenConfig if available
      if (window.ProgenConfig?.routes) {
        Object.assign(this.config.routes, window.ProgenConfig.routes);
      }

      this.setupUserServiceListeners();
      this.setupRouteMonitoring();
      this.checkCurrentRoute();
      
      this.state.isInitialized = true;
      console.log('Route Guard initialized! 🛡️');
    } catch (error) {
      console.error('Failed to initialize route guard:', error);
    }
  },

  /**
   * Set up UserService event listeners
   */
  setupUserServiceListeners() {
    // Listen for login events
    UserService.addEventListener('user-logged-in', (e) => {
      this.state.currentUser = e.detail.user;
      this.checkCurrentRoute();
    });

    // Listen for logout events
    UserService.addEventListener('user-logged-out', () => {
      this.state.currentUser = null;
      this.checkCurrentRoute();
    });

    // Listen for service initialization
    UserService.addEventListener('user-service-initialized', (e) => {
      this.state.currentUser = UserService.currentUser();
      this.checkCurrentRoute();
    });
  },

  /**
   * Set up route monitoring
   */
  setupRouteMonitoring() {
    // Monitor hash changes
    window.addEventListener('hashchange', () => {
      this.checkCurrentRoute();
    });

    // Monitor popstate (back/forward navigation)
    window.addEventListener('popstate', () => {
      this.checkCurrentRoute();
    });

    // Monitor programmatic navigation
    const originalPushState = history.pushState;
    const originalReplaceState = history.replaceState;

    history.pushState = (...args) => {
      originalPushState.apply(history, args);
      setTimeout(() => this.checkCurrentRoute(), 0);
    };

    history.replaceState = (...args) => {
      originalReplaceState.apply(history, args);
      setTimeout(() => this.checkCurrentRoute(), 0);
    };
  },

  /**
   * Check current route and enforce access control
   */
  checkCurrentRoute() {
    const currentPath = this.getCurrentPath();
    this.state.currentRoute = currentPath;
    
    // Add to route history
    if (this.state.routeHistory[this.state.routeHistory.length - 1] !== currentPath) {
      this.state.routeHistory.push(currentPath);
      
      // Keep only last 10 routes
      if (this.state.routeHistory.length > 10) {
        this.state.routeHistory.shift();
      }
    }

    const accessResult = this.checkAccess(currentPath);
    
    if (!accessResult.allowed) {
      this.handleUnauthorizedAccess(accessResult);
    } else {
      this.handleAuthorizedAccess(currentPath);
    }
  },

  /**
   * Get current path
   */
  getCurrentPath() {
    const path = window.location.pathname;
    const hash = window.location.hash;
    
    // Handle hash-based routing
    if (hash && hash.startsWith('#/')) {
      return hash.substring(1);
    }
    
    return path;
  },

  /**
   * Check if user has access to a route
   */
  checkAccess(path) {
    const routeType = this.getRouteType(path);
    const user = this.state.currentUser || UserService.currentUser();

    switch (routeType) {
      case 'public':
        return { allowed: true, reason: 'public_route' };
        
      case 'student':
        if (!user) {
          return { 
            allowed: false, 
            reason: 'login_required',
            message: 'ログインが必要です'
          };
        }
        
        if (user.role === 'student' || user.role === 'admin') {
          return { allowed: true, reason: 'authorized_user' };
        }
        
        return { 
          allowed: false, 
          reason: 'insufficient_role',
          message: '学習者権限が必要です'
        };
        
      case 'admin':
        if (!user) {
          return { 
            allowed: false, 
            reason: 'login_required',
            message: 'ログインが必要です'
          };
        }
        
        if (user.role === 'admin') {
          return { allowed: true, reason: 'authorized_admin' };
        }
        
        return { 
          allowed: false, 
          reason: 'admin_required',
          message: '管理者権限が必要です'
        };
        
      default:
        // Unknown route, treat as public
        return { allowed: true, reason: 'unknown_route_public' };
    }
  },

  /**
   * Get route type based on path
   */
  getRouteType(path) {
    // Check admin routes first (more specific)
    for (const adminRoute of this.config.routes.admin) {
      if (this.matchRoute(path, adminRoute)) {
        return 'admin';
      }
    }
    
    // Check student routes
    for (const studentRoute of this.config.routes.student) {
      if (this.matchRoute(path, studentRoute)) {
        return 'student';
      }
    }
    
    // Check public routes
    for (const publicRoute of this.config.routes.public) {
      if (this.matchRoute(path, publicRoute)) {
        return 'public';
      }
    }
    
    // Default to public for unknown routes
    return 'public';
  },

  /**
   * Match route pattern
   */
  matchRoute(path, pattern) {
    // Exact match
    if (path === pattern) return true;
    
    // Directory match (path starts with pattern)
    if (pattern.endsWith('/') && path.startsWith(pattern)) return true;
    
    // File in directory match
    if (!pattern.endsWith('/') && path.startsWith(pattern + '/')) return true;
    
    return false;
  },

  /**
   * Handle unauthorized access
   */
  handleUnauthorizedAccess(accessResult) {
    console.warn(`Access denied to ${this.state.currentRoute}:`, accessResult.reason);
    
    // Show appropriate message
    if (window.ToastNotifications) {
      ToastNotifications.warning(accessResult.message || 'アクセスが拒否されました');
    }
    
    // Determine redirect URL
    let redirectUrl;
    switch (accessResult.reason) {
      case 'login_required':
        redirectUrl = this.config.redirects.loginRequired;
        // Show login modal if available
        if (window.ProgenAuth) {
          setTimeout(() => ProgenAuth.showLoginModal(), 500);
        }
        break;
        
      case 'admin_required':
        redirectUrl = this.config.redirects.adminRequired;
        break;
        
      default:
        redirectUrl = this.config.redirects.unauthorized;
    }
    
    // Redirect to appropriate page
    this.redirectTo(redirectUrl);
    
    // Dispatch access denied event
    this.dispatchRouteEvent('access-denied', {
      path: this.state.currentRoute,
      reason: accessResult.reason,
      user: this.state.currentUser,
      redirectUrl
    });
  },

  /**
   * Handle authorized access
   */
  handleAuthorizedAccess(path) {
    console.log(`Access granted to ${path}`);
    
    // Dispatch access granted event
    this.dispatchRouteEvent('access-granted', {
      path,
      user: this.state.currentUser,
      routeType: this.getRouteType(path)
    });
  },

  /**
   * Redirect to a URL
   */
  redirectTo(url) {
    if (url === window.location.pathname) return;
    
    console.log(`Redirecting to: ${url}`);
    
    // Use replace to avoid adding to history
    window.location.replace(url);
  },

  /**
   * Check if user can access a specific route
   */
  canAccess(path, user = null) {
    const targetUser = user || this.state.currentUser || UserService.currentUser();
    const tempCurrentUser = this.state.currentUser;
    
    // Temporarily set user for access check
    this.state.currentUser = targetUser;
    const result = this.checkAccess(path);
    
    // Restore original user
    this.state.currentUser = tempCurrentUser;
    
    return result.allowed;
  },

  /**
   * Get accessible routes for current user
   */
  getAccessibleRoutes(user = null) {
    const targetUser = user || this.state.currentUser || UserService.currentUser();
    const allRoutes = [
      ...this.config.routes.public,
      ...this.config.routes.student,
      ...this.config.routes.admin
    ];
    
    return allRoutes.filter(route => this.canAccess(route, targetUser));
  },

  /**
   * Navigate to a route with access check
   */
  navigateTo(path) {
    const accessResult = this.checkAccess(path);
    
    if (accessResult.allowed) {
      window.location.href = path;
      return true;
    } else {
      this.handleUnauthorizedAccess(accessResult);
      return false;
    }
  },

  /**
   * Add route protection to links
   */
  protectLinks() {
    document.addEventListener('click', (e) => {
      const link = e.target.closest('a[href]');
      if (!link) return;
      
      const href = link.getAttribute('href');
      if (!href || href.startsWith('http') || href.startsWith('mailto:') || href.startsWith('tel:')) {
        return; // External link or special protocol
      }
      
      const accessResult = this.checkAccess(href);
      if (!accessResult.allowed) {
        e.preventDefault();
        this.handleUnauthorizedAccess(accessResult);
      }
    });
  },

  /**
   * Dispatch route-related events
   */
  dispatchRouteEvent(eventType, detail) {
    const event = new CustomEvent(`progen-route-${eventType}`, {
      detail,
      bubbles: true
    });
    document.dispatchEvent(event);
  },

  /**
   * Add event listener for route events
   */
  addEventListener(eventType, callback) {
    document.addEventListener(`progen-route-${eventType}`, callback);
  },

  /**
   * Remove event listener for route events
   */
  removeEventListener(eventType, callback) {
    document.removeEventListener(`progen-route-${eventType}`, callback);
  },

  /**
   * Get debug information
   */
  getDebugInfo() {
    return {
      isInitialized: this.state.isInitialized,
      currentRoute: this.state.currentRoute,
      currentUser: this.state.currentUser,
      routeHistory: this.state.routeHistory,
      routeType: this.getRouteType(this.state.currentRoute),
      canAccessCurrent: this.checkAccess(this.state.currentRoute),
      config: this.config
    };
  }
};

// Auto-initialize when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    RouteGuard.init();
    RouteGuard.protectLinks();
  });
} else {
  RouteGuard.init();
  RouteGuard.protectLinks();
}

// Export for use in other modules
if (typeof window !== 'undefined') {
  window.RouteGuard = RouteGuard;
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = RouteGuard;
}


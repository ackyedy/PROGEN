/**
 * PROGEN Platform - Enhanced Theme Manager (Fixed)
 * 
 * This file addresses the following issues:
 * 1. Implements proper state machine for manual/auto theme switching
 * 2. Handles OS prefers-color-scheme properly
 * 3. Time-based automatic switching (6:00-18:00 default)
 * 4. localStorage persistence without conflicts
 * 5. Prevents theme conflicts and ensures data-theme consistency
 */

class ThemeManager {
  constructor() {
    this.STORAGE_KEY = 'progen-theme-preference';
    this.AUTO_LIGHT_HOUR = 6;  // 6:00 AM
    this.AUTO_DARK_HOUR = 18;  // 6:00 PM
    
    // Theme state machine
    this.state = {
      mode: 'auto', // 'auto', 'manual'
      theme: 'light', // 'light', 'dark'
      systemPreference: this.getSystemPreference(),
      timeBasedTheme: this.getTimeBasedTheme(),
      manualOverride: null // 'light', 'dark', null
    };
    
    this.init();
  }

  init() {
    // Load saved preferences
    this.loadPreferences();
    
    // Set up system preference listener
    this.setupSystemPreferenceListener();
    
    // Set up time-based switching
    this.setupTimeBasedSwitching();
    
    // Apply initial theme
    this.updateTheme();
    
    // Set up UI controls
    this.setupThemeToggle();
    
    // Prevent theme conflicts on page load
    this.preventThemeConflicts();
  }

  /**
   * Get system color scheme preference
   */
  getSystemPreference() {
    if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
      return 'dark';
    }
    return 'light';
  }

  /**
   * Get time-based theme preference
   */
  getTimeBasedTheme() {
    const now = new Date();
    const hour = now.getHours();
    
    // Light theme: 6:00 AM to 6:00 PM
    // Dark theme: 6:00 PM to 6:00 AM
    if (hour >= this.AUTO_LIGHT_HOUR && hour < this.AUTO_DARK_HOUR) {
      return 'light';
    }
    return 'dark';
  }

  /**
   * Load preferences from localStorage
   */
  loadPreferences() {
    try {
      const saved = localStorage.getItem(this.STORAGE_KEY);
      if (saved) {
        const preferences = JSON.parse(saved);
        this.state.mode = preferences.mode || 'auto';
        this.state.manualOverride = preferences.manualOverride || null;
      }
    } catch (error) {
      console.warn('Failed to load theme preferences:', error);
      // Reset to defaults
      this.state.mode = 'auto';
      this.state.manualOverride = null;
    }
  }

  /**
   * Save preferences to localStorage
   */
  savePreferences() {
    try {
      const preferences = {
        mode: this.state.mode,
        manualOverride: this.state.manualOverride,
        timestamp: Date.now()
      };
      localStorage.setItem(this.STORAGE_KEY, JSON.stringify(preferences));
    } catch (error) {
      console.warn('Failed to save theme preferences:', error);
    }
  }

  /**
   * Set up system preference change listener
   */
  setupSystemPreferenceListener() {
    if (window.matchMedia) {
      const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
      
      const handleChange = (e) => {
        this.state.systemPreference = e.matches ? 'dark' : 'light';
        if (this.state.mode === 'auto') {
          this.updateTheme();
        }
      };

      // Modern browsers
      if (mediaQuery.addEventListener) {
        mediaQuery.addEventListener('change', handleChange);
      } else {
        // Fallback for older browsers
        mediaQuery.addListener(handleChange);
      }
    }
  }

  /**
   * Set up time-based theme switching
   */
  setupTimeBasedSwitching() {
    // Update time-based theme every minute
    setInterval(() => {
      const newTimeBasedTheme = this.getTimeBasedTheme();
      if (newTimeBasedTheme !== this.state.timeBasedTheme) {
        this.state.timeBasedTheme = newTimeBasedTheme;
        if (this.state.mode === 'auto') {
          this.updateTheme();
        }
      }
    }, 60000); // Check every minute
  }

  /**
   * Determine the current theme based on state machine
   */
  determineCurrentTheme() {
    if (this.state.mode === 'manual' && this.state.manualOverride) {
      return this.state.manualOverride;
    }
    
    // Auto mode: prioritize system preference, fallback to time-based
    if (this.state.mode === 'auto') {
      // Check if CONFIG allows system preference override
      if (window.CONFIG?.theme?.respectSystemPreference !== false) {
        return this.state.systemPreference;
      }
      // Fallback to time-based
      return this.state.timeBasedTheme;
    }
    
    // Default fallback
    return 'light';
  }

  /**
   * Update the theme in the DOM
   */
  updateTheme() {
    const newTheme = this.determineCurrentTheme();
    
    if (newTheme !== this.state.theme) {
      this.state.theme = newTheme;
      
      // Apply theme to document
      document.documentElement.setAttribute('data-theme', newTheme);
      
      // Update meta theme-color for mobile browsers
      this.updateMetaThemeColor(newTheme);
      
      // Update toggle UI
      this.updateToggleUI();
      
      // Dispatch custom event for other components
      this.dispatchThemeChangeEvent(newTheme);
      
      // Remove any conflicting classes or styles
      this.removeConflictingStyles();
    }
  }

  /**
   * Update meta theme-color for mobile browsers
   */
  updateMetaThemeColor(theme) {
    let metaThemeColor = document.querySelector('meta[name="theme-color"]');
    if (!metaThemeColor) {
      metaThemeColor = document.createElement('meta');
      metaThemeColor.name = 'theme-color';
      document.head.appendChild(metaThemeColor);
    }
    
    // Set appropriate theme color based on current theme
    const themeColors = {
      light: '#f5f5f5',
      dark: '#1a1a1a'
    };
    
    metaThemeColor.content = themeColors[theme] || themeColors.light;
  }

  /**
   * Update toggle UI to reflect current state
   */
  updateToggleUI() {
    const toggle = document.getElementById('theme-toggle-checkbox');
    if (toggle) {
      toggle.checked = this.state.theme === 'dark';
    }
  }

  /**
   * Dispatch theme change event
   */
  dispatchThemeChangeEvent(theme) {
    const event = new CustomEvent('themechange', {
      detail: {
        theme,
        mode: this.state.mode,
        systemPreference: this.state.systemPreference,
        timeBasedTheme: this.state.timeBasedTheme
      }
    });
    document.dispatchEvent(event);
  }

  /**
   * Remove conflicting styles that might interfere with theme
   */
  removeConflictingStyles() {
    // Remove any elements with mix-blend-mode or filter that might cause conflicts
    const conflictingElements = document.querySelectorAll('[style*="mix-blend-mode"], [style*="filter"], [style*="hue-rotate"]');
    conflictingElements.forEach(el => {
      // Only remove if it's not intentionally set
      if (!el.hasAttribute('data-keep-blend-mode')) {
        el.style.mixBlendMode = 'normal';
        el.style.filter = 'none';
      }
    });
    
    // Remove any classes that might conflict with theme
    const body = document.body;
    const conflictingClasses = ['theme-light', 'theme-dark', 'light-mode', 'dark-mode'];
    conflictingClasses.forEach(className => {
      body.classList.remove(className);
    });
  }

  /**
   * Prevent theme conflicts on page load
   */
  preventThemeConflicts() {
    // Ensure only data-theme attribute controls theming
    document.body.removeAttribute('class');
    
    // Remove any inline styles that might conflict
    document.body.style.removeProperty('background-color');
    document.body.style.removeProperty('color');
    document.body.style.removeProperty('mix-blend-mode');
    document.body.style.removeProperty('filter');
  }

  /**
   * Set up theme toggle functionality
   */
  setupThemeToggle() {
    const toggle = document.getElementById('theme-toggle-checkbox');
    if (toggle) {
      toggle.addEventListener('change', (e) => {
        this.handleManualToggle(e.target.checked);
      });
      
      // Set initial state
      this.updateToggleUI();
    }
  }

  /**
   * Handle manual theme toggle
   */
  handleManualToggle(isDark) {
    const newTheme = isDark ? 'dark' : 'light';
    
    // Switch to manual mode
    this.state.mode = 'manual';
    this.state.manualOverride = newTheme;
    
    // Save preferences
    this.savePreferences();
    
    // Update theme
    this.updateTheme();
  }

  /**
   * Reset to auto mode
   */
  resetToAuto() {
    this.state.mode = 'auto';
    this.state.manualOverride = null;
    this.savePreferences();
    this.updateTheme();
  }

  /**
   * Get current theme info
   */
  getCurrentThemeInfo() {
    return {
      current: this.state.theme,
      mode: this.state.mode,
      systemPreference: this.state.systemPreference,
      timeBasedTheme: this.state.timeBasedTheme,
      manualOverride: this.state.manualOverride
    };
  }

  /**
   * Public API: Toggle theme manually
   */
  toggle() {
    const newTheme = this.state.theme === 'light' ? 'dark' : 'light';
    this.handleManualToggle(newTheme === 'dark');
  }

  /**
   * Public API: Set theme manually
   */
  setTheme(theme) {
    if (['light', 'dark'].includes(theme)) {
      this.handleManualToggle(theme === 'dark');
    }
  }

  /**
   * Public API: Set mode
   */
  setMode(mode) {
    if (['auto', 'manual'].includes(mode)) {
      if (mode === 'auto') {
        this.resetToAuto();
      } else {
        this.state.mode = 'manual';
        if (!this.state.manualOverride) {
          this.state.manualOverride = this.state.theme;
        }
        this.savePreferences();
      }
    }
  }
}

// Initialize theme manager when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    window.themeManager = new ThemeManager();
  });
} else {
  window.themeManager = new ThemeManager();
}

// Export for module systems
if (typeof module !== 'undefined' && module.exports) {
  module.exports = ThemeManager;
}


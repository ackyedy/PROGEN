/**
 * PROGEN Enhanced Theme Manager
 * Supports manual toggle, time-based switching, and OS preferences
 */

'use strict';

const ProgenThemeManager = {
  // Configuration
  config: {
    storageKey: 'progen_theme_v2',
    autoSwitchKey: 'progen_auto_switch_v2',
    defaultTheme: 'light',
    autoSwitchEnabled: true,
    timeBasedSwitching: {
      enabled: true,
      lightStart: 6,  // 6 AM
      darkStart: 18   // 6 PM
    }
  },

  // State
  state: {
    currentTheme: 'light',
    isAutoSwitchEnabled: true,
    isInitialized: false,
    mediaQuery: null,
    timeCheckInterval: null,
    observers: []
  },

  /**
   * Initialize the theme manager
   */
  init() {
    if (this.state.isInitialized) return;

    try {
      // Load configuration from ProgenConfig if available
      if (window.ProgenConfig?.theme) {
        Object.assign(this.config, window.ProgenConfig.theme);
      }

      // Set up OS preference detection
      this.setupOSPreferenceDetection();

      // Load saved preferences
      this.loadSavedPreferences();

      // Apply initial theme
      this.applyInitialTheme();

      // Set up time-based switching
      this.setupTimeBasedSwitching();

      // Set up theme toggle listeners
      this.setupThemeToggle();

      // Set up mutation observer for dynamic content
      this.setupMutationObserver();

      this.state.isInitialized = true;
      console.log('Enhanced Theme Manager initialized successfully! 🎨');

      // Dispatch initialization event
      this.dispatchThemeEvent('theme-manager-initialized', {
        currentTheme: this.state.currentTheme,
        autoSwitchEnabled: this.state.isAutoSwitchEnabled
      });

    } catch (error) {
      console.error('Failed to initialize theme manager:', error);
    }
  },

  /**
   * Set up OS preference detection
   */
  setupOSPreferenceDetection() {
    if (!window.matchMedia) return;

    this.state.mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    
    // Listen for OS preference changes
    const handleOSPreferenceChange = (e) => {
      if (this.state.isAutoSwitchEnabled) {
        const preferredTheme = e.matches ? 'dark' : 'light';
        this.setTheme(preferredTheme, { source: 'os-preference' });
      }
    };

    // Modern browsers
    if (this.state.mediaQuery.addEventListener) {
      this.state.mediaQuery.addEventListener('change', handleOSPreferenceChange);
    } 
    // Legacy browsers
    else if (this.state.mediaQuery.addListener) {
      this.state.mediaQuery.addListener(handleOSPreferenceChange);
    }
  },

  /**
   * Load saved preferences from localStorage
   */
  loadSavedPreferences() {
    try {
      // Load theme preference
      const savedTheme = localStorage.getItem(this.config.storageKey);
      if (savedTheme && ['light', 'dark'].includes(savedTheme)) {
        this.state.currentTheme = savedTheme;
      }

      // Load auto-switch preference
      const autoSwitchSetting = localStorage.getItem(this.config.autoSwitchKey);
      if (autoSwitchSetting !== null) {
        this.state.isAutoSwitchEnabled = JSON.parse(autoSwitchSetting);
      }
    } catch (error) {
      console.warn('Failed to load saved theme preferences:', error);
    }
  },

  /**
   * Apply initial theme based on preferences and conditions
   */
  applyInitialTheme() {
    let initialTheme = this.state.currentTheme;

    // If auto-switch is enabled, determine theme based on conditions
    if (this.state.isAutoSwitchEnabled) {
      // Check time-based preference first
      if (this.config.timeBasedSwitching.enabled) {
        const timeBasedTheme = this.getTimeBasedTheme();
        if (timeBasedTheme) {
          initialTheme = timeBasedTheme;
        }
      }
      // Fall back to OS preference
      else if (this.state.mediaQuery?.matches) {
        initialTheme = 'dark';
      }
    }

    this.setTheme(initialTheme, { source: 'initial', skipSave: true });
  },

  /**
   * Get theme based on current time
   */
  getTimeBasedTheme() {
    const now = new Date();
    const currentHour = now.getHours();
    const { lightStart, darkStart } = this.config.timeBasedSwitching;

    if (currentHour >= lightStart && currentHour < darkStart) {
      return 'light';
    } else {
      return 'dark';
    }
  },

  /**
   * Set up time-based switching
   */
  setupTimeBasedSwitching() {
    if (!this.config.timeBasedSwitching.enabled) return;

    // Check every minute for time-based theme changes
    this.state.timeCheckInterval = setInterval(() => {
      if (this.state.isAutoSwitchEnabled) {
        const timeBasedTheme = this.getTimeBasedTheme();
        if (timeBasedTheme !== this.state.currentTheme) {
          this.setTheme(timeBasedTheme, { source: 'time-based' });
        }
      }
    }, 60000); // Check every minute
  },

  /**
   * Set up theme toggle listeners
   */
  setupThemeToggle() {
    // Find theme toggle elements
    const toggleElements = document.querySelectorAll('[data-theme-toggle], .theme-toggle, #theme-toggle-checkbox');
    
    toggleElements.forEach(element => {
      if (element.type === 'checkbox') {
        // Handle checkbox toggles
        element.checked = this.state.currentTheme === 'dark';
        element.addEventListener('change', (e) => {
          const newTheme = e.target.checked ? 'dark' : 'light';
          this.toggleTheme(newTheme);
        });
      } else {
        // Handle button toggles
        element.addEventListener('click', () => {
          this.toggleTheme();
        });
      }
    });

    // Update toggle states when theme changes
    this.addEventListener('theme-changed', (e) => {
      this.updateToggleStates(e.detail.theme);
    });
  },

  /**
   * Update toggle states to reflect current theme
   */
  updateToggleStates(theme) {
    const toggleElements = document.querySelectorAll('[data-theme-toggle], .theme-toggle, #theme-toggle-checkbox');
    
    toggleElements.forEach(element => {
      if (element.type === 'checkbox') {
        element.checked = theme === 'dark';
      } else {
        element.setAttribute('data-current-theme', theme);
        element.setAttribute('aria-label', `現在のテーマ: ${theme === 'dark' ? 'ダーク' : 'ライト'}モード`);
      }
    });
  },

  /**
   * Set up mutation observer for dynamic content
   */
  setupMutationObserver() {
    const observer = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        mutation.addedNodes.forEach((node) => {
          if (node.nodeType === Node.ELEMENT_NODE) {
            // Apply theme to newly added elements
            this.applyThemeToElement(node);
            
            // Set up toggle listeners for new toggle elements
            const newToggles = node.querySelectorAll?.('[data-theme-toggle], .theme-toggle, #theme-toggle-checkbox');
            if (newToggles?.length > 0) {
              this.setupThemeToggle();
            }
          }
        });
      });
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true
    });

    this.state.observers.push(observer);
  },

  /**
   * Apply theme to a specific element
   */
  applyThemeToElement(element) {
    // Apply theme-specific classes or attributes
    if (element.classList?.contains('theme-aware')) {
      element.setAttribute('data-theme', this.state.currentTheme);
    }
  },

  /**
   * Set theme
   */
  setTheme(theme, options = {}) {
    if (!['light', 'dark'].includes(theme)) {
      console.warn(`Invalid theme: ${theme}`);
      return;
    }

    const previousTheme = this.state.currentTheme;
    this.state.currentTheme = theme;

    // Apply theme to document
    document.documentElement.setAttribute('data-theme', theme);
    document.documentElement.style.colorScheme = theme;

    // Save to localStorage unless explicitly skipped
    if (!options.skipSave) {
      try {
        localStorage.setItem(this.config.storageKey, theme);
      } catch (error) {
        console.warn('Failed to save theme preference:', error);
      }
    }

    // Dispatch theme change event
    this.dispatchThemeEvent('theme-changed', {
      theme,
      previousTheme,
      source: options.source || 'manual'
    });

    console.log(`Theme changed to: ${theme} (source: ${options.source || 'manual'})`);
  },

  /**
   * Toggle theme
   */
  toggleTheme(specificTheme = null) {
    // Disable auto-switch when manually toggling
    this.setAutoSwitch(false);

    const newTheme = specificTheme || (this.state.currentTheme === 'light' ? 'dark' : 'light');
    this.setTheme(newTheme, { source: 'manual-toggle' });
  },

  /**
   * Enable or disable auto-switch
   */
  setAutoSwitch(enabled) {
    this.state.isAutoSwitchEnabled = enabled;
    
    try {
      localStorage.setItem(this.config.autoSwitchKey, JSON.stringify(enabled));
    } catch (error) {
      console.warn('Failed to save auto-switch preference:', error);
    }

    this.dispatchThemeEvent('auto-switch-changed', {
      enabled,
      currentTheme: this.state.currentTheme
    });

    console.log(`Auto-switch ${enabled ? 'enabled' : 'disabled'}`);
  },

  /**
   * Get current theme
   */
  getCurrentTheme() {
    return this.state.currentTheme;
  },

  /**
   * Get auto-switch status
   */
  isAutoSwitchEnabled() {
    return this.state.isAutoSwitchEnabled;
  },

  /**
   * Add event listener for theme events
   */
  addEventListener(eventType, callback) {
    document.addEventListener(`progen-${eventType}`, callback);
  },

  /**
   * Remove event listener for theme events
   */
  removeEventListener(eventType, callback) {
    document.removeEventListener(`progen-${eventType}`, callback);
  },

  /**
   * Dispatch theme-related events
   */
  dispatchThemeEvent(eventType, detail) {
    const event = new CustomEvent(`progen-${eventType}`, {
      detail,
      bubbles: true
    });
    document.dispatchEvent(event);
  },

  /**
   * Get system preference
   */
  getSystemPreference() {
    if (!this.state.mediaQuery) return 'light';
    return this.state.mediaQuery.matches ? 'dark' : 'light';
  },

  /**
   * Reset to system preference
   */
  resetToSystemPreference() {
    this.setAutoSwitch(true);
    const systemTheme = this.getSystemPreference();
    this.setTheme(systemTheme, { source: 'system-reset' });
  },

  /**
   * Cleanup resources
   */
  cleanup() {
    // Clear intervals
    if (this.state.timeCheckInterval) {
      clearInterval(this.state.timeCheckInterval);
      this.state.timeCheckInterval = null;
    }

    // Disconnect observers
    this.state.observers.forEach(observer => {
      observer.disconnect();
    });
    this.state.observers = [];

    // Remove media query listener
    if (this.state.mediaQuery) {
      if (this.state.mediaQuery.removeEventListener) {
        this.state.mediaQuery.removeEventListener('change', this.handleOSPreferenceChange);
      } else if (this.state.mediaQuery.removeListener) {
        this.state.mediaQuery.removeListener(this.handleOSPreferenceChange);
      }
    }

    this.state.isInitialized = false;
  },

  /**
   * Debug information
   */
  getDebugInfo() {
    return {
      currentTheme: this.state.currentTheme,
      isAutoSwitchEnabled: this.state.isAutoSwitchEnabled,
      systemPreference: this.getSystemPreference(),
      timeBasedTheme: this.getTimeBasedTheme(),
      config: this.config,
      isInitialized: this.state.isInitialized
    };
  }
};

// Auto-initialize when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    ProgenThemeManager.init();
  });
} else {
  ProgenThemeManager.init();
}

// Export for use in other modules
if (typeof window !== 'undefined') {
  window.ProgenThemeManager = ProgenThemeManager;
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = ProgenThemeManager;
}


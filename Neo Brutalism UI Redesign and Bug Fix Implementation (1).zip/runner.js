/**
 * @file Web Worker for safe code execution and grading.
 * @module Worker/Runner
 */

// Import necessary libraries/modules if needed
// importScripts('some-library.js');

self.onmessage = async (event) => {
  const { type, payload } = event.data;

  switch (type) {
    case 'executeCode':
      await executeCode(payload);
      break;
    case 'runTests':
      await runTests(payload);
      break;
    default:
      self.postMessage({ type: 'error', message: `Unknown message type: ${type}` });
  }
};

/**
 * Executes user-provided code in a sandboxed environment.
 * @param {object} payload - The payload containing code and execution context.
 * @param {string} payload.code - The code to execute.
 * @param {string} payload.language - The language of the code (e.g., 'javascript', 'python').
 * @param {number} [payload.timeout=5000] - Execution timeout in milliseconds.
 */
async function executeCode(payload) {
  const { code, language, timeout = 5000 } = payload;
  let result = { output: '', error: null, status: 'success' };

  const executionPromise = new Promise(async (resolve) => {
    try {
      switch (language) {
        case 'javascript':
          // For JavaScript, we can use eval or Function constructor.
          // Using Function constructor for better isolation than direct eval.
          const func = new Function('console', 'self', 'postMessage', code);
          const consoleOutput = [];
          const customConsole = {
            log: (...args) => consoleOutput.push(args.map(String).join(' ')),
            error: (...args) => consoleOutput.push('ERROR: ' + args.map(String).join(' ')),
            warn: (...args) => consoleOutput.push('WARN: ' + args.map(String).join(' ')),
            info: (...args) => consoleOutput.push('INFO: ' + args.map(String).join(' ')),
          };
          func(customConsole, self, postMessage);
          result.output = consoleOutput.join('\n');
          break;
        case 'python':
          // For Python, we would typically use a WebAssembly-based interpreter like Pyodide.
          // This is a placeholder. Actual Pyodide integration would be more complex.
          result.output = `Python execution not fully implemented in worker. Code received:\n${code}`;
          result.status = 'warning';
          break;
        case 'html':
        case 'css':
          result.output = `HTML/CSS execution is typically rendered directly, not executed in worker. Code received:\n${code}`;
          result.status = 'warning';
          break;
        default:
          result.error = `Unsupported language: ${language}`;
          result.status = 'error';
      }
    } catch (e) {
      result.error = e.message;
      result.status = 'error';
    }
    resolve(result);
  });

  const timeoutPromise = new Promise((_, reject) =>
    setTimeout(() => reject(new Error('Execution timed out')), timeout)
  );

  try {
    const finalResult = await Promise.race([executionPromise, timeoutPromise]);
    self.postMessage({ type: 'codeExecuted', payload: finalResult });
  } catch (e) {
    self.postMessage({ type: 'codeExecuted', payload: { output: '', error: e.message, status: 'error' } });
  }
}

/**
 * Runs tests against user-provided code.
 * @param {object} payload - The payload containing code, tests, and language.
 * @param {string} payload.code - The user's code to test.
 * @param {string} payload.language - The language of the code.
 * @param {Array<object>} payload.tests - An array of test definitions.
 * @param {number} [payload.timeout=5000] - Test execution timeout in milliseconds.
 */
async function runTests(payload) {
  const { code, language, tests, timeout = 5000 } = payload;
  const testResults = [];
  let allPassed = true;

  const testPromise = new Promise(async (resolve) => {
    for (const test of tests) {
      let passed = false;
      let message = '';
      try {
        switch (test.type) {
          case 'regex':
            const regex = new RegExp(test.pattern, test.flags || '');
            passed = regex.test(code);
            message = passed ? 'Passed: Regex matched.' : 'Failed: Regex did not match.';
            break;
          case 'snapshot':
            // For snapshot testing, we'd need to execute the code and compare output.
            // This is a simplified placeholder.
            const executionResult = await executeCode({ code, language, timeout: timeout / tests.length });
            if (executionResult.status === 'success' && executionResult.output === test.expectedOutput) {
              passed = true;
              message = 'Passed: Snapshot matched.';
            } else {
              passed = false;
              message = `Failed: Expected '${test.expectedOutput}', got '${executionResult.output}'`;
            }
            break;
          case 'functionCall':
            // For function call tests, we need to execute the code and call a specific function.
            // This is highly language-dependent and complex for a generic worker.
            // Placeholder for now.
            passed = false;
            message = 'Function call tests not fully implemented in worker.';
            break;
          default:
            passed = false;
            message = `Unknown test type: ${test.type}`;
        }
      } catch (e) {
        passed = false;
        message = `Test error: ${e.message}`;
      }
      testResults.push({ description: test.description, passed, message });
      if (!passed) allPassed = false;
    }
    resolve({ testResults, allPassed });
  });

  const timeoutPromise = new Promise((_, reject) =>
    setTimeout(() => reject(new Error('Tests timed out')), timeout)
  );

  try {
    const finalResults = await Promise.race([testPromise, timeoutPromise]);
    self.postMessage({ type: 'testsCompleted', payload: finalResults });
  } catch (e) {
    self.postMessage({ type: 'testsCompleted', payload: { testResults: [], allPassed: false, error: e.message } });
  }
}



/**
 * PROGEN User Service
 * Interface for user authentication and management
 * Designed for easy backend replacement in the future
 */

'use strict';

const UserService = {
  // Configuration
  config: {
    apiBaseUrl: '/api/users',
    storageKeys: {
      currentUser: 'progen_current_user_v2',
      session: 'progen_session_v2',
      token: 'progen_token_v2'
    },
    sessionTimeout: 24 * 60 * 60 * 1000, // 24 hours
    maxLoginAttempts: 5,
    lockoutDuration: 15 * 60 * 1000 // 15 minutes
  },

  // State
  state: {
    currentUser: null,
    isInitialized: false,
    loginAttempts: new Map(),
    sessionCheckInterval: null
  },

  /**
   * Initialize the user service
   */
  async init() {
    if (this.state.isInitialized) return;

    try {
      // Load configuration from ProgenConfig if available
      if (window.ProgenConfig?.auth) {
        Object.assign(this.config, window.ProgenConfig.auth);
      }

      // Check for existing session
      await this.checkExistingSession();

      // Set up periodic session validation
      this.setupSessionValidation();

      this.state.isInitialized = true;
      console.log('User Service initialized successfully! 👤');

      // Dispatch initialization event
      this.dispatchUserEvent('user-service-initialized', {
        isLoggedIn: !!this.state.currentUser
      });

    } catch (error) {
      console.error('Failed to initialize User Service:', error);
    }
  },

  /**
   * Check for existing session on initialization
   */
  async checkExistingSession() {
    try {
      const sessionData = this.getStorageItem(this.config.storageKeys.session);
      const userData = this.getStorageItem(this.config.storageKeys.currentUser);

      if (sessionData && userData) {
        // Validate session
        if (this.isSessionValid(sessionData)) {
          this.state.currentUser = userData;
          console.log('Restored user session:', userData.name);
          
          // Dispatch login event
          this.dispatchUserEvent('user-logged-in', {
            user: userData,
            source: 'session-restore'
          });
        } else {
          // Clear invalid session
          await this.signOut();
        }
      }
    } catch (error) {
      console.warn('Failed to check existing session:', error);
      await this.signOut();
    }
  },

  /**
   * Set up periodic session validation
   */
  setupSessionValidation() {
    // Check session validity every 5 minutes
    this.state.sessionCheckInterval = setInterval(async () => {
      if (this.state.currentUser) {
        const sessionData = this.getStorageItem(this.config.storageKeys.session);
        if (!sessionData || !this.isSessionValid(sessionData)) {
          console.log('Session expired, logging out user');
          await this.signOut();
        }
      }
    }, 5 * 60 * 1000);
  },

  /**
   * Get user by email (simulates database lookup)
   */
  async getUserByEmail(email) {
    try {
      // In a real implementation, this would be an API call
      // For now, we'll load from the JSON file
      const usersData = await this.loadUsersData();
      const user = usersData.users.find(u => 
        u.email.toLowerCase() === email.toLowerCase() && u.isActive
      );
      
      return user || null;
    } catch (error) {
      console.error('Failed to get user by email:', error);
      return null;
    }
  },

  /**
   * Load users data from JSON file (simulates database)
   */
  async loadUsersData() {
    try {
      const response = await fetch('/data/users.json');
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      return await response.json();
    } catch (error) {
      console.error('Failed to load users data:', error);
      // Return fallback data for development
      return {
        users: [
          {
            id: 'demo_001',
            email: 'demo@progen.com',
            passwordHash: '$2b$10$N9qo8uLOickgx2ZMRZoMye.IjdKXZnQX6IfTvFdc2EnUp6qMjKK4.',
            name: 'デモユーザー',
            role: 'student',
            level: 3,
            xp: 75,
            nextLevelXp: 100,
            completedLessons: 12,
            streak: 7,
            badges: 5,
            preferences: {
              theme: 'light',
              notifications: true,
              language: 'ja',
              autoSwitchTheme: true
            },
            isActive: true
          }
        ]
      };
    }
  },

  /**
   * Sign in user
   */
  async signIn(email, password) {
    try {
      // Input validation
      if (!this.validateEmail(email)) {
        return {
          success: false,
          error: '有効なメールアドレスを入力してください'
        };
      }

      if (!password || password.length < 6) {
        return {
          success: false,
          error: 'パスワードは6文字以上で入力してください'
        };
      }

      // Check rate limiting
      const rateLimitResult = this.checkRateLimit(email);
      if (!rateLimitResult.allowed) {
        return {
          success: false,
          error: `ログイン試行回数が上限に達しました。${Math.ceil(rateLimitResult.waitTime / 60000)}分後に再試行してください`
        };
      }

      // Simulate network delay
      await this.delay(500 + Math.random() * 1000);

      // Get user from database
      const user = await this.getUserByEmail(email);
      if (!user) {
        this.recordFailedAttempt(email);
        return {
          success: false,
          error: 'メールアドレスまたはパスワードが正しくありません'
        };
      }

      // Verify password (simplified hash comparison)
      const isPasswordValid = await this.verifyPassword(password, user.passwordHash);
      if (!isPasswordValid) {
        this.recordFailedAttempt(email);
        return {
          success: false,
          error: 'メールアドレスまたはパスワードが正しくありません'
        };
      }

      // Clear failed attempts on successful login
      this.clearFailedAttempts(email);

      // Create session
      const sessionData = this.createSession(user);

      // Store user data and session
      this.setStorageItem(this.config.storageKeys.currentUser, user);
      this.setStorageItem(this.config.storageKeys.session, sessionData);
      this.setStorageItem(this.config.storageKeys.token, sessionData.token);

      // Update state
      this.state.currentUser = user;

      // Apply user theme preference
      if (user.preferences?.theme && window.ProgenThemeManager) {
        ProgenThemeManager.setTheme(user.preferences.theme);
        if (user.preferences.autoSwitchTheme !== undefined) {
          ProgenThemeManager.setAutoSwitch(user.preferences.autoSwitchTheme);
        }
      }

      console.log('Sign in successful for user:', user.name);

      // Dispatch login event
      this.dispatchUserEvent('user-logged-in', {
        user,
        source: 'manual-login'
      });

      return { success: true, user };

    } catch (error) {
      console.error('Sign in error:', error);
      return {
        success: false,
        error: 'ログイン処理中にエラーが発生しました'
      };
    }
  },

  /**
   * Sign out user
   */
  async signOut() {
    try {
      const currentUser = this.state.currentUser;

      // Clear all authentication data
      Object.values(this.config.storageKeys).forEach(key => {
        localStorage.removeItem(key);
      });

      // Clear state
      this.state.currentUser = null;

      // Clear login attempts
      this.state.loginAttempts.clear();

      console.log('Sign out successful');

      // Dispatch logout event
      this.dispatchUserEvent('user-logged-out', {
        user: currentUser,
        source: 'manual-logout'
      });

      return { success: true };

    } catch (error) {
      console.error('Sign out error:', error);
      return {
        success: false,
        error: 'ログアウト処理中にエラーが発生しました'
      };
    }
  },

  /**
   * Get current user
   */
  currentUser() {
    return this.state.currentUser;
  },

  /**
   * Check if user is logged in
   */
  isLoggedIn() {
    return !!this.state.currentUser;
  },

  /**
   * Verify password against hash (simplified)
   */
  async verifyPassword(password, hash) {
    // In a real implementation, this would use bcrypt or similar
    // For demo purposes, we'll use a simple comparison with known hashes
    const knownPasswords = {
      '$2b$10$N9qo8uLOickgx2ZMRZoMye.IjdKXZnQX6IfTvFdc2EnUp6qMjKK4.': 'demo123',
      '$2b$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi': 'password123',
      '$2b$10$K1wbsaGYki.wjO19d0gYLuP0LVyp6YKYBjvbxMvEiUHBZMH6PVUBG': 'progen2025',
      '$2b$10$CwTycUXWue0Thq9StjUM0uJ4TvVAat2.WrNWinSUBdDFGquLxHDli': 'study123',
      '$2b$10$Dy6gIOGtwGdreXHFf1GPFOhvjf4JJ13W.HlZkb0lxQjjkNm/B3L1.': 'admin123'
    };

    return knownPasswords[hash] === password;
  },

  /**
   * Create session data
   */
  createSession(user) {
    const now = Date.now();
    const expiresAt = now + this.config.sessionTimeout;
    
    // Generate secure token
    const token = this.generateToken(user.id, now);
    
    return {
      token,
      userId: user.id,
      createdAt: now,
      expiresAt,
      lastActivity: now,
      userAgent: navigator.userAgent.substring(0, 100)
    };
  },

  /**
   * Generate secure token
   */
  generateToken(identifier, timestamp) {
    const randomBytes = new Uint8Array(16);
    crypto.getRandomValues(randomBytes);
    const randomString = Array.from(randomBytes, byte => 
      byte.toString(16).padStart(2, '0')
    ).join('');
    
    return `progen_${btoa(identifier + '_' + timestamp + '_' + randomString)}`;
  },

  /**
   * Check if session is valid
   */
  isSessionValid(sessionData) {
    if (!sessionData || !sessionData.expiresAt) return false;
    return Date.now() < sessionData.expiresAt;
  },

  /**
   * Check rate limiting for login attempts
   */
  checkRateLimit(email) {
    const now = Date.now();
    const attempts = this.state.loginAttempts.get(email) || {
      count: 0,
      lastAttempt: 0,
      lockedUntil: 0
    };
    
    // Check if still locked out
    if (attempts.lockedUntil > now) {
      return {
        allowed: false,
        waitTime: attempts.lockedUntil - now
      };
    }
    
    // Reset if lockout period has passed
    if (attempts.lockedUntil > 0 && attempts.lockedUntil <= now) {
      attempts.count = 0;
      attempts.lockedUntil = 0;
    }
    
    return { allowed: true };
  },

  /**
   * Record failed login attempt
   */
  recordFailedAttempt(email) {
    const now = Date.now();
    const attempts = this.state.loginAttempts.get(email) || {
      count: 0,
      lastAttempt: 0,
      lockedUntil: 0
    };
    
    attempts.count++;
    attempts.lastAttempt = now;
    
    // Lock account if max attempts reached
    if (attempts.count >= this.config.maxLoginAttempts) {
      attempts.lockedUntil = now + this.config.lockoutDuration;
    }
    
    this.state.loginAttempts.set(email, attempts);
  },

  /**
   * Clear failed attempts
   */
  clearFailedAttempts(email) {
    this.state.loginAttempts.delete(email);
  },

  /**
   * Validate email format
   */
  validateEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  },

  /**
   * Safe storage operations
   */
  setStorageItem(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
      return true;
    } catch (error) {
      console.error('Failed to set storage item:', error);
      return false;
    }
  },

  getStorageItem(key) {
    try {
      const item = localStorage.getItem(key);
      return item ? JSON.parse(item) : null;
    } catch (error) {
      console.error('Failed to get storage item:', error);
      return null;
    }
  },

  /**
   * Utility: Create delay
   */
  delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  },

  /**
   * Dispatch user-related events
   */
  dispatchUserEvent(eventType, detail) {
    const event = new CustomEvent(`progen-${eventType}`, {
      detail,
      bubbles: true
    });
    document.dispatchEvent(event);
  },

  /**
   * Add event listener for user events
   */
  addEventListener(eventType, callback) {
    document.addEventListener(`progen-${eventType}`, callback);
  },

  /**
   * Remove event listener for user events
   */
  removeEventListener(eventType, callback) {
    document.removeEventListener(`progen-${eventType}`, callback);
  },

  /**
   * Update user preferences
   */
  async updateUserPreferences(preferences) {
    if (!this.state.currentUser) {
      return { success: false, error: 'ユーザーがログインしていません' };
    }

    try {
      // Update current user object
      this.state.currentUser.preferences = {
        ...this.state.currentUser.preferences,
        ...preferences
      };

      // Save to storage
      this.setStorageItem(this.config.storageKeys.currentUser, this.state.currentUser);

      // In a real implementation, this would also update the backend
      console.log('User preferences updated:', preferences);

      // Dispatch event
      this.dispatchUserEvent('user-preferences-updated', {
        user: this.state.currentUser,
        preferences
      });

      return { success: true };

    } catch (error) {
      console.error('Failed to update user preferences:', error);
      return { success: false, error: '設定の更新に失敗しました' };
    }
  },

  /**
   * Cleanup resources
   */
  cleanup() {
    if (this.state.sessionCheckInterval) {
      clearInterval(this.state.sessionCheckInterval);
      this.state.sessionCheckInterval = null;
    }
    
    this.state.isInitialized = false;
  },

  /**
   * Debug information
   */
  getDebugInfo() {
    return {
      isLoggedIn: this.isLoggedIn(),
      currentUser: this.state.currentUser,
      isInitialized: this.state.isInitialized,
      loginAttempts: Object.fromEntries(this.state.loginAttempts),
      config: this.config
    };
  }
};

// Auto-initialize when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    UserService.init();
  });
} else {
  UserService.init();
}

// Export for use in other modules
if (typeof window !== 'undefined') {
  window.UserService = UserService;
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = UserService;
}


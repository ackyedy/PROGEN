/**
 * PROGEN Platform - Package Loader System
 * 
 * This system handles:
 * 1. Loading and parsing .progen package files
 * 2. Validating package integrity and signatures
 * 3. Extracting and caching package contents
 * 4. Managing package versions and dependencies
 * 5. Providing unified API for lesson content access
 */

class ProgenPackageLoader {
  constructor() {
    this.MIME_TYPE = 'application/x-progen+zip';
    this.SCHEMA_VERSION = '1.0.0';
    this.ENGINE_MIN_VERSION = '1.0.0';
    
    this.cache = new Map();
    this.loadedPackages = new Map();
    this.packageIndex = new Map();
    
    this.init();
  }

  async init() {
    try {
      // Load package index
      await this.loadPackageIndex();
      
      // Set up cache management
      this.setupCacheManagement();
      
    } catch (error) {
      console.error('Failed to initialize ProgenPackageLoader:', error);
    }
  }

  /**
   * Load package index from server
   */
  async loadPackageIndex() {
    try {
      const response = await fetch('/data/packages/index.json');
      if (response.ok) {
        const index = await response.json();
        this.packageIndex = new Map(Object.entries(index.packages || {}));
      }
    } catch (error) {
      console.warn('Failed to load package index:', error);
    }
  }

  /**
   * Load a .progen package file
   */
  async loadPackage(packagePath) {
    try {
      // Check cache first
      if (this.cache.has(packagePath)) {
        return this.cache.get(packagePath);
      }

      // Fetch package file
      const response = await fetch(packagePath);
      if (!response.ok) {
        throw new Error(`Failed to fetch package: ${response.status}`);
      }

      // Verify MIME type
      const contentType = response.headers.get('content-type');
      if (contentType && !contentType.includes('zip') && !contentType.includes('progen')) {
        console.warn(`Unexpected content type: ${contentType}`);
      }

      // Get package as blob
      const blob = await response.blob();
      
      // Extract package contents
      const packageData = await this.extractPackage(blob);
      
      // Validate package
      await this.validatePackage(packageData);
      
      // Cache package
      this.cache.set(packagePath, packageData);
      this.loadedPackages.set(packageData.manifest.id, packageData);
      
      return packageData;
      
    } catch (error) {
      console.error(`Failed to load package ${packagePath}:`, error);
      throw error;
    }
  }

  /**
   * Extract contents from .progen package (ZIP file)
   */
  async extractPackage(blob) {
    try {
      // For demo purposes, we'll simulate ZIP extraction
      // In a real implementation, you'd use a library like JSZip
      
      // Since we can't actually extract ZIP in this demo,
      // we'll return a mock package structure
      const mockPackage = await this.createMockPackage();
      return mockPackage;
      
    } catch (error) {
      console.error('Failed to extract package:', error);
      throw error;
    }
  }

  /**
   * Create a mock package for demonstration
   */
  async createMockPackage() {
    return {
      manifest: {
        schemaVersion: this.SCHEMA_VERSION,
        id: 'python-basics',
        version: '1.0.0',
        buildId: 'build-' + Date.now(),
        createdAt: new Date().toISOString(),
        engineMinVersion: this.ENGINE_MIN_VERSION,
        signature: 'mock-signature-hash',
        title: 'Python 基礎',
        description: 'Python プログラミングの基礎を学ぶ',
        author: 'PROGEN Team',
        language: 'python',
        difficulty: 'beginner',
        estimatedTime: '2-3 hours'
      },
      course: {
        id: 'python-basics',
        title: 'Python 基礎',
        description: 'Python プログラミングの基礎を学ぶコース',
        chapters: [
          {
            id: 'chapter-1',
            title: '言語の土台',
            lessons: ['lesson-1-1', 'lesson-1-2', 'lesson-1-3']
          }
        ]
      },
      lessons: new Map([
        ['lesson-1-1', {
          id: 'lesson-1-1',
          title: '変数と型の基本',
          description: 'Python の変数と基本的なデータ型について学習します',
          content: [
            {
              type: 'slide',
              title: 'Python の変数',
              content: `# Python の変数

Python では変数を使ってデータを保存できます。

\`\`\`python
name = "太郎"
age = 25
height = 175.5
\`\`\`

変数名は文字、数字、アンダースコアを使用できますが、数字から始めることはできません。`
            },
            {
              type: 'challenge',
              title: '変数を作ってみよう',
              description: '自分の名前と年齢を変数に代入してください',
              starterCode: '# あなたの名前を name 変数に代入してください\n# あなたの年齢を age 変数に代入してください\n\nprint(f"私の名前は{name}で、{age}歳です")',
              solution: 'name = "太郎"\nage = 25\n\nprint(f"私の名前は{name}で、{age}歳です")',
              tests: [
                {
                  type: 'regex',
                  pattern: 'name\\s*=\\s*["\'][^"\']+["\']',
                  description: 'name 変数が文字列で定義されている'
                },
                {
                  type: 'regex',
                  pattern: 'age\\s*=\\s*\\d+',
                  description: 'age 変数が数値で定義されている'
                }
              ]
            }
          ]
        }]
      ]),
      assets: new Map([
        ['thumbnail.png', '/assets/python-thumbnail.png']
      ])
    };
  }

  /**
   * Validate package structure and integrity
   */
  async validatePackage(packageData) {
    const { manifest, course, lessons } = packageData;
    
    // Validate manifest
    if (!manifest) {
      throw new Error('Package manifest is missing');
    }
    
    if (manifest.schemaVersion !== this.SCHEMA_VERSION) {
      throw new Error(`Unsupported schema version: ${manifest.schemaVersion}`);
    }
    
    if (!manifest.id || !manifest.version) {
      throw new Error('Package manifest is missing required fields');
    }
    
    // Validate course structure
    if (!course || !course.id || !course.chapters) {
      throw new Error('Invalid course structure');
    }
    
    // Validate lessons
    if (!lessons || lessons.size === 0) {
      throw new Error('Package contains no lessons');
    }
    
    // Validate lesson references
    for (const chapter of course.chapters) {
      for (const lessonId of chapter.lessons) {
        if (!lessons.has(lessonId)) {
          throw new Error(`Referenced lesson not found: ${lessonId}`);
        }
      }
    }
    
    // TODO: Validate signature in production
    if (manifest.signature && manifest.signature !== 'mock-signature-hash') {
      console.warn('Package signature validation not implemented in demo');
    }
    
    return true;
  }

  /**
   * Get course information from package
   */
  async getCourse(packageId) {
    const packageData = this.loadedPackages.get(packageId);
    if (!packageData) {
      throw new Error(`Package not loaded: ${packageId}`);
    }
    
    return packageData.course;
  }

  /**
   * Get lesson content from package
   */
  async getLesson(packageId, lessonId) {
    const packageData = this.loadedPackages.get(packageId);
    if (!packageData) {
      throw new Error(`Package not loaded: ${packageId}`);
    }
    
    const lesson = packageData.lessons.get(lessonId);
    if (!lesson) {
      throw new Error(`Lesson not found: ${lessonId}`);
    }
    
    return lesson;
  }

  /**
   * Get asset from package
   */
  async getAsset(packageId, assetPath) {
    const packageData = this.loadedPackages.get(packageId);
    if (!packageData) {
      throw new Error(`Package not loaded: ${packageId}`);
    }
    
    const asset = packageData.assets.get(assetPath);
    if (!asset) {
      throw new Error(`Asset not found: ${assetPath}`);
    }
    
    return asset;
  }

  /**
   * List available packages
   */
  getAvailablePackages() {
    return Array.from(this.packageIndex.entries()).map(([id, info]) => ({
      id,
      ...info
    }));
  }

  /**
   * Check if package is loaded
   */
  isPackageLoaded(packageId) {
    return this.loadedPackages.has(packageId);
  }

  /**
   * Unload package from memory
   */
  unloadPackage(packageId) {
    const packageData = this.loadedPackages.get(packageId);
    if (packageData) {
      // Remove from caches
      this.loadedPackages.delete(packageId);
      
      // Find and remove from path cache
      for (const [path, data] of this.cache.entries()) {
        if (data === packageData) {
          this.cache.delete(path);
          break;
        }
      }
    }
  }

  /**
   * Set up cache management
   */
  setupCacheManagement() {
    // Clean up cache periodically
    setInterval(() => {
      this.cleanupCache();
    }, 5 * 60 * 1000); // Every 5 minutes
  }

  /**
   * Clean up old cache entries
   */
  cleanupCache() {
    const maxCacheSize = 10; // Maximum number of cached packages
    
    if (this.cache.size > maxCacheSize) {
      // Remove oldest entries
      const entries = Array.from(this.cache.entries());
      const toRemove = entries.slice(0, entries.length - maxCacheSize);
      
      toRemove.forEach(([path]) => {
        this.cache.delete(path);
      });
    }
  }

  /**
   * Create package from course data (for Studio export)
   */
  async createPackage(courseData, options = {}) {
    const manifest = {
      schemaVersion: this.SCHEMA_VERSION,
      id: courseData.id,
      version: options.version || '1.0.0',
      buildId: 'build-' + Date.now(),
      createdAt: new Date().toISOString(),
      engineMinVersion: this.ENGINE_MIN_VERSION,
      signature: options.signature || null,
      title: courseData.title,
      description: courseData.description,
      author: options.author || 'Unknown',
      language: courseData.language || 'javascript',
      difficulty: courseData.difficulty || 'beginner',
      estimatedTime: courseData.estimatedTime || 'Unknown'
    };

    const packageData = {
      manifest,
      course: courseData,
      lessons: new Map(Object.entries(courseData.lessons || {})),
      assets: new Map(Object.entries(courseData.assets || {}))
    };

    // In a real implementation, this would create a ZIP file
    // For demo purposes, we'll return the package data structure
    return packageData;
  }

  /**
   * Export package as downloadable file
   */
  async exportPackage(packageData, filename) {
    try {
      // In a real implementation, this would create a ZIP file
      // For demo purposes, we'll create a JSON representation
      
      const exportData = {
        manifest: packageData.manifest,
        course: packageData.course,
        lessons: Object.fromEntries(packageData.lessons),
        assets: Object.fromEntries(packageData.assets)
      };

      const blob = new Blob([JSON.stringify(exportData, null, 2)], {
        type: 'application/json'
      });

      // Create download link
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename || `${packageData.manifest.id}-${packageData.manifest.version}.progen`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      return true;
      
    } catch (error) {
      console.error('Failed to export package:', error);
      throw error;
    }
  }

  /**
   * Get package metadata without loading full content
   */
  async getPackageMetadata(packagePath) {
    try {
      // In a real implementation, this would extract only the manifest
      // For demo purposes, we'll return mock metadata
      
      return {
        id: 'python-basics',
        version: '1.0.0',
        title: 'Python 基礎',
        description: 'Python プログラミングの基礎を学ぶ',
        author: 'PROGEN Team',
        language: 'python',
        difficulty: 'beginner',
        estimatedTime: '2-3 hours',
        createdAt: new Date().toISOString()
      };
      
    } catch (error) {
      console.error('Failed to get package metadata:', error);
      throw error;
    }
  }
}

// Initialize ProgenPackageLoader when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    window.progenPackageLoader = new ProgenPackageLoader();
  });
} else {
  window.progenPackageLoader = new ProgenPackageLoader();
}

// Export for module systems
if (typeof module !== 'undefined' && module.exports) {
  module.exports = ProgenPackageLoader;
}


/**
 * PROGEN Toast Notifications
 * Neo-Brutalism styled toast notification system
 */

'use strict';

const ToastNotifications = {
  // Configuration
  config: {
    defaultDuration: 5000,
    maxToasts: 5,
    position: 'top-right', // 'top-right', 'top-left', 'bottom-right', 'bottom-left'
    animationDuration: 300
  },

  // State
  state: {
    toasts: [],
    container: null,
    isInitialized: false,
    nextId: 1
  },

  /**
   * Initialize the toast system
   */
  init() {
    if (this.state.isInitialized) return;

    try {
      this.createContainer();
      this.addStyles();
      this.state.isInitialized = true;
      console.log('Toast Notifications initialized! 🍞');
    } catch (error) {
      console.error('Failed to initialize toast notifications:', error);
    }
  },

  /**
   * Create toast container
   */
  createContainer() {
    this.state.container = document.createElement('div');
    this.state.container.className = 'toast-container';
    this.state.container.setAttribute('aria-live', 'polite');
    this.state.container.setAttribute('aria-label', '通知');
    document.body.appendChild(this.state.container);
  },

  /**
   * Add CSS styles for toasts
   */
  addStyles() {
    const style = document.createElement('style');
    style.textContent = `
      .toast-container {
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 1000;
        display: flex;
        flex-direction: column;
        gap: 12px;
        max-width: 400px;
        pointer-events: none;
      }

      .toast-container.bottom-right {
        top: auto;
        bottom: 20px;
        right: 20px;
      }

      .toast-container.bottom-left {
        top: auto;
        bottom: 20px;
        left: 20px;
        right: auto;
      }

      .toast-container.top-left {
        top: 20px;
        left: 20px;
        right: auto;
      }

      .toast {
        background: var(--color-bg, #fcf8e8);
        color: var(--color-fg, #1a1a1a);
        border: 3px solid var(--color-fg, #1a1a1a);
        border-radius: 12px;
        box-shadow: 4px 4px 0px var(--color-fg, #1a1a1a);
        padding: 16px 20px;
        min-width: 300px;
        max-width: 400px;
        position: relative;
        pointer-events: auto;
        transform: translateX(100%);
        opacity: 0;
        transition: all 0.3s cubic-bezier(0.68, -0.55, 0.265, 1.55);
        font-family: var(--font-sans, 'Noto Sans JP', sans-serif);
        font-size: 14px;
        line-height: 1.5;
        word-wrap: break-word;
      }

      .toast.show {
        transform: translateX(0);
        opacity: 1;
      }

      .toast.hide {
        transform: translateX(100%);
        opacity: 0;
      }

      .toast-container.top-left .toast,
      .toast-container.bottom-left .toast {
        transform: translateX(-100%);
      }

      .toast-container.top-left .toast.show,
      .toast-container.bottom-left .toast.show {
        transform: translateX(0);
      }

      .toast-container.top-left .toast.hide,
      .toast-container.bottom-left .toast.hide {
        transform: translateX(-100%);
      }

      .toast.success {
        background: var(--color-success, #28a745);
        color: white;
        border-color: var(--color-fg, #1a1a1a);
        box-shadow: 4px 4px 0px var(--color-fg, #1a1a1a);
      }

      .toast.error {
        background: var(--color-error, #dc3545);
        color: white;
        border-color: var(--color-fg, #1a1a1a);
        box-shadow: 4px 4px 0px var(--color-fg, #1a1a1a);
      }

      .toast.warning {
        background: var(--color-warning, #ffc107);
        color: var(--color-fg, #1a1a1a);
        border-color: var(--color-fg, #1a1a1a);
        box-shadow: 4px 4px 0px var(--color-fg, #1a1a1a);
      }

      .toast.info {
        background: var(--color-info, #007bff);
        color: white;
        border-color: var(--color-fg, #1a1a1a);
        box-shadow: 4px 4px 0px var(--color-fg, #1a1a1a);
      }

      .toast-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 8px;
        font-weight: 700;
        font-size: 16px;
      }

      .toast-icon {
        margin-right: 8px;
        font-size: 18px;
      }

      .toast-close {
        background: none;
        border: none;
        color: inherit;
        cursor: pointer;
        font-size: 18px;
        font-weight: bold;
        padding: 0;
        margin-left: 12px;
        opacity: 0.7;
        transition: opacity 0.2s ease;
      }

      .toast-close:hover {
        opacity: 1;
      }

      .toast-close:focus {
        outline: 2px solid currentColor;
        outline-offset: 2px;
      }

      .toast-body {
        font-size: 14px;
        line-height: 1.5;
      }

      .toast-progress {
        position: absolute;
        bottom: 0;
        left: 0;
        height: 3px;
        background: currentColor;
        opacity: 0.3;
        transition: width linear;
        border-radius: 0 0 9px 9px;
      }

      /* Dark theme adjustments */
      html[data-theme="dark"] .toast {
        background: var(--color-bg, #1a1a1a);
        color: var(--color-fg, #fcf8e8);
        border-color: var(--color-primary, #ffcc00);
        box-shadow: 4px 4px 0px var(--color-primary, #ffcc00);
      }

      html[data-theme="dark"] .toast.success {
        border-color: var(--color-success, #28a745);
        box-shadow: 4px 4px 0px var(--color-success, #28a745);
      }

      html[data-theme="dark"] .toast.error {
        border-color: var(--color-error, #dc3545);
        box-shadow: 4px 4px 0px var(--color-error, #dc3545);
      }

      html[data-theme="dark"] .toast.warning {
        border-color: var(--color-warning, #ffc107);
        box-shadow: 4px 4px 0px var(--color-warning, #ffc107);
      }

      html[data-theme="dark"] .toast.info {
        border-color: var(--color-info, #007bff);
        box-shadow: 4px 4px 0px var(--color-info, #007bff);
      }

      /* Responsive design */
      @media (max-width: 480px) {
        .toast-container {
          left: 10px;
          right: 10px;
          top: 10px;
          max-width: none;
        }

        .toast-container.bottom-right,
        .toast-container.bottom-left {
          bottom: 10px;
          top: auto;
        }

        .toast {
          min-width: auto;
          max-width: none;
        }
      }

      /* Reduced motion support */
      @media (prefers-reduced-motion: reduce) {
        .toast {
          transition: opacity 0.1s ease;
        }
      }
    `;
    document.head.appendChild(style);
  },

  /**
   * Show a toast notification
   */
  show(message, options = {}) {
    if (!this.state.isInitialized) {
      this.init();
    }

    const toast = this.createToast(message, options);
    this.addToast(toast);
    return toast.id;
  },

  /**
   * Show success toast
   */
  success(message, options = {}) {
    return this.show(message, { ...options, type: 'success' });
  },

  /**
   * Show error toast
   */
  error(message, options = {}) {
    return this.show(message, { ...options, type: 'error' });
  },

  /**
   * Show warning toast
   */
  warning(message, options = {}) {
    return this.show(message, { ...options, type: 'warning' });
  },

  /**
   * Show info toast
   */
  info(message, options = {}) {
    return this.show(message, { ...options, type: 'info' });
  },

  /**
   * Create toast element
   */
  createToast(message, options) {
    const {
      type = 'default',
      title = null,
      duration = this.config.defaultDuration,
      closable = true,
      showProgress = true
    } = options;

    const id = this.state.nextId++;
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.setAttribute('role', 'alert');
    toast.setAttribute('aria-live', 'assertive');
    toast.dataset.toastId = id;

    // Create toast content
    let content = '';

    if (title) {
      content += `
        <div class="toast-header">
          <span>
            ${this.getIcon(type)}
            ${this.escapeHtml(title)}
          </span>
          ${closable ? '<button class="toast-close" aria-label="閉じる">&times;</button>' : ''}
        </div>
      `;
    } else if (closable) {
      content += `
        <button class="toast-close" aria-label="閉じる" style="position: absolute; top: 8px; right: 8px;">&times;</button>
      `;
    }

    content += `
      <div class="toast-body">
        ${title ? '' : this.getIcon(type)}
        ${this.escapeHtml(message)}
      </div>
    `;

    if (showProgress && duration > 0) {
      content += '<div class="toast-progress"></div>';
    }

    toast.innerHTML = content;

    // Add event listeners
    if (closable) {
      const closeBtn = toast.querySelector('.toast-close');
      closeBtn?.addEventListener('click', () => this.hide(id));
    }

    // Auto-hide after duration
    let timeoutId = null;
    if (duration > 0) {
      timeoutId = setTimeout(() => this.hide(id), duration);

      // Update progress bar
      if (showProgress) {
        const progressBar = toast.querySelector('.toast-progress');
        if (progressBar) {
          progressBar.style.width = '100%';
          progressBar.style.transitionDuration = `${duration}ms`;
          setTimeout(() => {
            progressBar.style.width = '0%';
          }, 10);
        }
      }
    }

    return {
      id,
      element: toast,
      timeoutId,
      type,
      message,
      options
    };
  },

  /**
   * Add toast to container
   */
  addToast(toast) {
    // Remove oldest toast if we've reached the limit
    if (this.state.toasts.length >= this.config.maxToasts) {
      const oldestToast = this.state.toasts[0];
      this.hide(oldestToast.id);
    }

    // Add to state
    this.state.toasts.push(toast);

    // Add to DOM
    this.state.container.appendChild(toast.element);

    // Trigger animation
    requestAnimationFrame(() => {
      toast.element.classList.add('show');
    });

    console.log(`Toast shown: ${toast.type} - ${toast.message}`);
  },

  /**
   * Hide toast by ID
   */
  hide(id) {
    const toastIndex = this.state.toasts.findIndex(t => t.id === id);
    if (toastIndex === -1) return;

    const toast = this.state.toasts[toastIndex];

    // Clear timeout
    if (toast.timeoutId) {
      clearTimeout(toast.timeoutId);
    }

    // Animate out
    toast.element.classList.remove('show');
    toast.element.classList.add('hide');

    // Remove from DOM after animation
    setTimeout(() => {
      if (toast.element.parentNode) {
        toast.element.parentNode.removeChild(toast.element);
      }
      
      // Remove from state
      this.state.toasts.splice(toastIndex, 1);
    }, this.config.animationDuration);

    console.log(`Toast hidden: ${id}`);
  },

  /**
   * Hide all toasts
   */
  hideAll() {
    const toastIds = this.state.toasts.map(t => t.id);
    toastIds.forEach(id => this.hide(id));
  },

  /**
   * Get icon for toast type
   */
  getIcon(type) {
    const icons = {
      success: '<span class="toast-icon">✅</span>',
      error: '<span class="toast-icon">❌</span>',
      warning: '<span class="toast-icon">⚠️</span>',
      info: '<span class="toast-icon">ℹ️</span>',
      default: '<span class="toast-icon">📢</span>'
    };
    return icons[type] || icons.default;
  },

  /**
   * Escape HTML to prevent XSS
   */
  escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  },

  /**
   * Set toast position
   */
  setPosition(position) {
    this.config.position = position;
    if (this.state.container) {
      this.state.container.className = `toast-container ${position}`;
    }
  },

  /**
   * Update configuration
   */
  configure(newConfig) {
    Object.assign(this.config, newConfig);
  },

  /**
   * Get debug information
   */
  getDebugInfo() {
    return {
      isInitialized: this.state.isInitialized,
      activeToasts: this.state.toasts.length,
      config: this.config
    };
  }
};

// Auto-initialize when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    ToastNotifications.init();
  });
} else {
  ToastNotifications.init();
}

// Export for use in other modules
if (typeof window !== 'undefined') {
  window.ToastNotifications = ToastNotifications;
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = ToastNotifications;
}


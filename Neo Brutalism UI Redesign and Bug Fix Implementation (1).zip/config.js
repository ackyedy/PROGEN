/**
 * PROGEN Platform Configuration
 * Centralized configuration for all platform components
 */

const ProgenConfig = {
  // Environment settings
  environment: 'development', // 'development' | 'production' | 'staging'
  
  // API Configuration
  api: {
    baseUrl: '/api',
    version: 'v1',
    timeout: 10000,
    retryAttempts: 3
  },

  // Authentication Configuration
  auth: {
    sessionTimeout: 24 * 60 * 60 * 1000, // 24 hours
    refreshThreshold: 2 * 60 * 60 * 1000, // 2 hours
    maxLoginAttempts: 5,
    lockoutDuration: 15 * 60 * 1000, // 15 minutes
    tokenPrefix: 'progen_',
    storageKeys: {
      user: 'progen_user_v2',
      token: 'progen_token_v2',
      session: 'progen_session_v2',
      refreshToken: 'progen_refresh_v2'
    }
  },

  // Theme Configuration
  theme: {
    storageKey: 'progen_theme_v2',
    defaultTheme: 'light',
    autoSwitchEnabled: true,
    timeBasedSwitching: {
      enabled: true,
      lightStart: 6, // 6 AM
      darkStart: 18  // 6 PM
    }
  },

  // Design System Tokens
  designTokens: {
    // Neo-Brutalism Design Principles
    colors: {
      light: {
        bg: '#fcf8e8',
        fg: '#1a1a1a',
        muted: '#555555',
        primary: '#ffcc00',
        accent: '#ff0000',
        success: '#28a745',
        warning: '#ffc107',
        error: '#dc3545',
        info: '#007bff'
      },
      dark: {
        bg: '#1a1a1a',
        fg: '#fcf8e8',
        muted: '#aaaaaa',
        primary: '#ffcc00',
        accent: '#ff0000',
        success: '#28a745',
        warning: '#ffc107',
        error: '#dc3545',
        info: '#007bff'
      }
    },
    spacing: {
      xs: '0.25rem',
      sm: '0.5rem',
      md: '1rem',
      lg: '1.5rem',
      xl: '2rem',
      '2xl': '3rem',
      '3xl': '4rem'
    },
    radius: {
      none: '0',
      sm: '4px',
      md: '8px',
      lg: '12px',
      xl: '16px',
      full: '9999px'
    },
    shadows: {
      none: 'none',
      sm: '2px 2px 0px var(--color-fg)',
      md: '4px 4px 0px var(--color-fg)',
      lg: '8px 8px 0px var(--color-fg)',
      xl: '12px 12px 0px var(--color-fg)'
    },
    outlines: {
      none: 'none',
      thin: '2px solid var(--color-fg)',
      thick: '4px solid var(--color-fg)',
      dashed: '2px dashed var(--color-fg)',
      dotted: '3px dotted var(--color-fg)'
    },
    typography: {
      fontFamily: {
        sans: "'Noto Sans JP', system-ui, -apple-system, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif",
        mono: "'Roboto Mono', monospace"
      },
      fontSize: {
        xs: '0.75rem',
        sm: '0.875rem',
        base: '1rem',
        lg: '1.125rem',
        xl: '1.25rem',
        '2xl': '1.5rem',
        '3xl': '1.875rem',
        '4xl': '2.25rem',
        '5xl': '3rem',
        '6xl': '3.75rem'
      },
      fontWeight: {
        normal: '400',
        medium: '500',
        semibold: '600',
        bold: '700',
        black: '900'
      }
    }
  },

  // Routing Configuration
  routes: {
    home: '/',
    dashboard: '/dashboard',
    courses: '/courses',
    course: '/courses/:slug',
    lesson: '/courses/:courseSlug/lessons/:lessonSlug',
    studio: '/studio',
    progress: '/progress',
    pricing: '/pricing',
    auth: {
      login: '/auth/login',
      register: '/auth/register',
      logout: '/auth/logout'
    }
  },

  // Course Configuration
  courses: {
    dataPath: '/courses',
    maxLessonsPerChapter: 10,
    supportedLanguages: ['python', 'html', 'css', 'javascript'],
    executionTimeout: 30000, // 30 seconds
    maxCodeLength: 10000 // characters
  },

  // Studio Configuration
  studio: {
    maxSlides: 12, // User limit
    autosaveInterval: 30000, // 30 seconds
    previewDelay: 500, // milliseconds
    supportedContentTypes: ['slide', 'challenge', 'quiz'],
    exportFormats: ['json', 'html']
  },

  // Performance Configuration
  performance: {
    lazyLoadImages: true,
    enableServiceWorker: true,
    cacheStrategy: 'stale-while-revalidate',
    criticalCSSInline: true,
    fontDisplay: 'swap'
  },

  // Accessibility Configuration
  accessibility: {
    minContrastRatio: 4.5,
    focusVisibleOutline: '2px solid var(--color-accent)',
    focusVisibleOffset: '2px',
    reducedMotionRespect: true,
    skipLinkTarget: '#main'
  },

  // Analytics Configuration (placeholder)
  analytics: {
    enabled: false,
    trackingId: null,
    events: {
      lessonComplete: 'lesson_complete',
      courseStart: 'course_start',
      userLogin: 'user_login'
    }
  },

  // Feature Flags
  features: {
    videoGeneration: false, // User doesn't have access
    wideResearch: false,    // User doesn't have access
    maxSlides: 12,          // User limit
    socialLogin: false,     // Not implemented yet
    offlineMode: false,     // Future feature
    aiAssistant: false      // Future feature
  },

  // Development Configuration
  development: {
    enableDebugMode: true,
    showPerformanceMetrics: true,
    enableHotReload: true,
    mockApiDelay: 500
  }
};

// Export for different environments
if (typeof module !== 'undefined' && module.exports) {
  module.exports = ProgenConfig;
}

if (typeof window !== 'undefined') {
  window.ProgenConfig = ProgenConfig;
}


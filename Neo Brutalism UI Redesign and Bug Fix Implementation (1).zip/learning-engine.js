/**
 * PROGEN Learning Engine
 * Manages learning flow, progress tracking, and content delivery
 */

'use strict';

const LearningEngine = {
  // Configuration
  config: {
    storageKey: 'progen_progress',
    autoSaveInterval: 30000, // 30 seconds
    maxAttempts: 3,
    timeoutDuration: 30000, // 30 seconds for code execution
    supportedLanguages: ['python', 'html', 'css', 'javascript']
  },

  // State
  state: {
    isInitialized: false,
    currentCourse: null,
    currentSection: null,
    currentLesson: null,
    currentContentIndex: 0,
    userProgress: {},
    lessonState: {
      startTime: null,
      attempts: 0,
      hints: [],
      completed: false
    },
    codeWorker: null
  },

  /**
   * Initialize learning engine
   */
  async init() {
    if (this.state.isInitialized) return;

    try {
      await this.loadProgress();
      this.setupCodeWorker();
      this.setupEventListeners();
      this.setupAutoSave();
      
      this.state.isInitialized = true;
      this.dispatchEvent('learning-engine-initialized');
      console.log('🎓 Learning Engine initialized!');
    } catch (error) {
      console.error('Failed to initialize Learning Engine:', error);
      throw error;
    }
  },

  /**
   * Load user progress from storage
   */
  async loadProgress() {
    try {
      const stored = localStorage.getItem(this.config.storageKey);
      if (stored) {
        this.state.userProgress = JSON.parse(stored);
      } else {
        this.state.userProgress = {
          courses: {},
          achievements: [],
          totalTime: 0,
          lastActivity: null
        };
      }
    } catch (error) {
      console.error('Failed to load progress:', error);
      this.state.userProgress = {
        courses: {},
        achievements: [],
        totalTime: 0,
        lastActivity: null
      };
    }
  },

  /**
   * Setup Web Worker for code execution
   */
  setupCodeWorker() {
    // Create a simple worker for code execution
    const workerCode = `
      self.onmessage = function(e) {
        const { code, language, testCases, timeout } = e.data;
        
        try {
          let result;
          const startTime = Date.now();
          
          if (language === 'javascript') {
            // Execute JavaScript code
            result = executeJavaScript(code, testCases);
          } else if (language === 'python') {
            // For Python, we'd need a Python interpreter in JS (like Pyodide)
            // For now, simulate execution
            result = simulatePythonExecution(code, testCases);
          } else {
            result = { success: false, error: 'Unsupported language' };
          }
          
          const executionTime = Date.now() - startTime;
          
          self.postMessage({
            success: true,
            result: result,
            executionTime: executionTime
          });
        } catch (error) {
          self.postMessage({
            success: false,
            error: error.message
          });
        }
      };
      
      function executeJavaScript(code, testCases) {
        const results = [];
        
        for (const testCase of testCases) {
          try {
            // Create a safe execution context
            const func = new Function('input', code + '; return typeof result !== "undefined" ? result : null;');
            const output = func(testCase.input);
            
            results.push({
              testCase: testCase.id,
              passed: String(output) === String(testCase.expectedOutput),
              output: String(output),
              expected: String(testCase.expectedOutput)
            });
          } catch (error) {
            results.push({
              testCase: testCase.id,
              passed: false,
              output: error.message,
              expected: String(testCase.expectedOutput),
              error: true
            });
          }
        }
        
        return {
          success: true,
          results: results,
          passed: results.every(r => r.passed)
        };
      }
      
      function simulatePythonExecution(code, testCases) {
        // Simulate Python execution for demo purposes
        const results = testCases.map(testCase => ({
          testCase: testCase.id,
          passed: Math.random() > 0.3, // 70% pass rate for demo
          output: 'Simulated output',
          expected: String(testCase.expectedOutput)
        }));
        
        return {
          success: true,
          results: results,
          passed: results.every(r => r.passed)
        };
      }
    `;

    const blob = new Blob([workerCode], { type: 'application/javascript' });
    this.state.codeWorker = new Worker(URL.createObjectURL(blob));
  },

  /**
   * Setup event listeners
   */
  setupEventListeners() {
    // Handle code worker messages
    if (this.state.codeWorker) {
      this.state.codeWorker.onmessage = (e) => {
        this.handleCodeExecutionResult(e.data);
      };

      this.state.codeWorker.onerror = (error) => {
        console.error('Code worker error:', error);
        this.dispatchEvent('code-execution-error', { error });
      };
    }

    // Handle page unload
    window.addEventListener('beforeunload', () => {
      this.saveProgress();
    });

    // Handle visibility change
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) {
        this.saveProgress();
      }
    });
  },

  /**
   * Setup auto-save
   */
  setupAutoSave() {
    setInterval(() => {
      this.saveProgress();
    }, this.config.autoSaveInterval);
  },

  /**
   * Start a course
   */
  async startCourse(courseData) {
    this.state.currentCourse = courseData;
    this.state.currentSection = null;
    this.state.currentLesson = null;
    this.state.currentContentIndex = 0;

    // Initialize course progress if not exists
    if (!this.state.userProgress.courses[courseData.id]) {
      this.state.userProgress.courses[courseData.id] = {
        id: courseData.id,
        title: courseData.title,
        startedAt: new Date().toISOString(),
        completedAt: null,
        progress: 0,
        sections: {},
        totalTime: 0,
        lastAccessed: new Date().toISOString()
      };
    }

    this.dispatchEvent('course-started', { course: courseData });
    
    // Start first section if available
    if (courseData.sections && courseData.sections.length > 0) {
      await this.startSection(courseData.sections[0]);
    }
  },

  /**
   * Start a section
   */
  async startSection(sectionData) {
    this.state.currentSection = sectionData;
    this.state.currentLesson = null;
    this.state.currentContentIndex = 0;

    const courseId = this.state.currentCourse.id;
    
    // Initialize section progress if not exists
    if (!this.state.userProgress.courses[courseId].sections[sectionData.id]) {
      this.state.userProgress.courses[courseId].sections[sectionData.id] = {
        id: sectionData.id,
        title: sectionData.title,
        startedAt: new Date().toISOString(),
        completedAt: null,
        progress: 0,
        lessons: {},
        totalTime: 0
      };
    }

    this.dispatchEvent('section-started', { section: sectionData });
    
    // Start first lesson if available
    if (sectionData.lessons && sectionData.lessons.length > 0) {
      await this.startLesson(sectionData.lessons[0]);
    }
  },

  /**
   * Start a lesson
   */
  async startLesson(lessonData) {
    this.state.currentLesson = lessonData;
    this.state.currentContentIndex = 0;
    this.state.lessonState = {
      startTime: new Date(),
      attempts: 0,
      hints: [],
      completed: false
    };

    const courseId = this.state.currentCourse.id;
    const sectionId = this.state.currentSection.id;
    
    // Initialize lesson progress if not exists
    if (!this.state.userProgress.courses[courseId].sections[sectionId].lessons[lessonData.id]) {
      this.state.userProgress.courses[courseId].sections[sectionId].lessons[lessonData.id] = {
        id: lessonData.id,
        title: lessonData.title,
        startedAt: new Date().toISOString(),
        completedAt: null,
        progress: 0,
        attempts: 0,
        hintsUsed: 0,
        score: 0,
        timeSpent: 0
      };
    }

    this.dispatchEvent('lesson-started', { lesson: lessonData });
    
    // Show first content item
    if (lessonData.content && lessonData.content.length > 0) {
      this.showContent(0);
    }
  },

  /**
   * Show content at specific index
   */
  showContent(index) {
    const lesson = this.state.currentLesson;
    if (!lesson || !lesson.content || index >= lesson.content.length) {
      return;
    }

    this.state.currentContentIndex = index;
    const content = lesson.content[index];
    
    this.dispatchEvent('content-shown', { 
      content, 
      index, 
      total: lesson.content.length 
    });

    // Auto-advance for slides after a delay
    if (content.type === 'slide') {
      setTimeout(() => {
        this.nextContent();
      }, 5000); // 5 seconds
    }
  },

  /**
   * Navigate to next content
   */
  nextContent() {
    const lesson = this.state.currentLesson;
    if (!lesson || !lesson.content) return;

    const nextIndex = this.state.currentContentIndex + 1;
    
    if (nextIndex < lesson.content.length) {
      this.showContent(nextIndex);
    } else {
      this.completeLesson();
    }
  },

  /**
   * Navigate to previous content
   */
  previousContent() {
    const prevIndex = this.state.currentContentIndex - 1;
    
    if (prevIndex >= 0) {
      this.showContent(prevIndex);
    }
  },

  /**
   * Execute code for challenge
   */
  async executeCode(code, language, testCases) {
    if (!this.state.codeWorker) {
      throw new Error('Code worker not initialized');
    }

    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        reject(new Error('Code execution timeout'));
      }, this.config.timeoutDuration);

      const handleMessage = (e) => {
        clearTimeout(timeout);
        this.state.codeWorker.removeEventListener('message', handleMessage);
        
        if (e.data.success) {
          resolve(e.data.result);
        } else {
          reject(new Error(e.data.error));
        }
      };

      this.state.codeWorker.addEventListener('message', handleMessage);
      
      this.state.codeWorker.postMessage({
        code,
        language,
        testCases,
        timeout: this.config.timeoutDuration
      });
    });
  },

  /**
   * Handle code execution result
   */
  handleCodeExecutionResult(data) {
    this.dispatchEvent('code-execution-completed', data);
  },

  /**
   * Submit challenge answer
   */
  async submitChallenge(code, language) {
    const content = this.state.currentLesson.content[this.state.currentContentIndex];
    
    if (content.type !== 'challenge') {
      throw new Error('Current content is not a challenge');
    }

    this.state.lessonState.attempts++;
    
    try {
      const result = await this.executeCode(code, language, content.testCases);
      
      const courseId = this.state.currentCourse.id;
      const sectionId = this.state.currentSection.id;
      const lessonId = this.state.currentLesson.id;
      
      // Update progress
      const lessonProgress = this.state.userProgress.courses[courseId].sections[sectionId].lessons[lessonId];
      lessonProgress.attempts = this.state.lessonState.attempts;
      
      if (result.passed) {
        lessonProgress.score = Math.max(lessonProgress.score, this.calculateScore(result));
        this.dispatchEvent('challenge-passed', { result, code });
        
        // Auto-advance after success
        setTimeout(() => {
          this.nextContent();
        }, 2000);
      } else {
        this.dispatchEvent('challenge-failed', { result, code });
      }
      
      return result;
    } catch (error) {
      this.dispatchEvent('challenge-error', { error, code });
      throw error;
    }
  },

  /**
   * Submit quiz answer
   */
  submitQuizAnswer(questionId, answer) {
    const content = this.state.currentLesson.content[this.state.currentContentIndex];
    
    if (content.type !== 'quiz') {
      throw new Error('Current content is not a quiz');
    }

    const question = content.questions.find(q => q.id === questionId);
    if (!question) {
      throw new Error('Question not found');
    }

    const isCorrect = this.checkAnswer(question, answer);
    
    this.dispatchEvent('quiz-answer-submitted', {
      questionId,
      answer,
      correct: isCorrect,
      explanation: question.explanation
    });

    return isCorrect;
  },

  /**
   * Check quiz answer
   */
  checkAnswer(question, answer) {
    if (Array.isArray(question.correctAnswer)) {
      return question.correctAnswer.includes(answer);
    }
    return question.correctAnswer === answer;
  },

  /**
   * Get hint for current challenge
   */
  getHint() {
    const content = this.state.currentLesson.content[this.state.currentContentIndex];
    
    if (content.type !== 'challenge' || !content.hints) {
      return null;
    }

    const hintIndex = this.state.lessonState.hints.length;
    
    if (hintIndex < content.hints.length) {
      const hint = content.hints[hintIndex];
      this.state.lessonState.hints.push(hint);
      
      // Update progress
      const courseId = this.state.currentCourse.id;
      const sectionId = this.state.currentSection.id;
      const lessonId = this.state.currentLesson.id;
      
      this.state.userProgress.courses[courseId].sections[sectionId].lessons[lessonId].hintsUsed++;
      
      this.dispatchEvent('hint-used', { hint, index: hintIndex });
      
      return hint;
    }
    
    return null;
  },

  /**
   * Complete current lesson
   */
  completeLesson() {
    if (!this.state.currentLesson) return;

    const courseId = this.state.currentCourse.id;
    const sectionId = this.state.currentSection.id;
    const lessonId = this.state.currentLesson.id;
    
    const lessonProgress = this.state.userProgress.courses[courseId].sections[sectionId].lessons[lessonId];
    
    if (!lessonProgress.completedAt) {
      lessonProgress.completedAt = new Date().toISOString();
      lessonProgress.progress = 100;
      
      // Calculate time spent
      if (this.state.lessonState.startTime) {
        const timeSpent = Date.now() - this.state.lessonState.startTime.getTime();
        lessonProgress.timeSpent = timeSpent;
        this.state.userProgress.totalTime += timeSpent;
      }
    }

    this.state.lessonState.completed = true;
    this.dispatchEvent('lesson-completed', { lesson: this.state.currentLesson });
    
    // Check if section is complete
    this.checkSectionCompletion();
  },

  /**
   * Check if current section is complete
   */
  checkSectionCompletion() {
    const courseId = this.state.currentCourse.id;
    const sectionId = this.state.currentSection.id;
    const sectionProgress = this.state.userProgress.courses[courseId].sections[sectionId];
    
    const totalLessons = this.state.currentSection.lessons.length;
    const completedLessons = Object.values(sectionProgress.lessons).filter(l => l.completedAt).length;
    
    if (completedLessons === totalLessons && !sectionProgress.completedAt) {
      sectionProgress.completedAt = new Date().toISOString();
      sectionProgress.progress = 100;
      
      this.dispatchEvent('section-completed', { section: this.state.currentSection });
      
      // Check if course is complete
      this.checkCourseCompletion();
    }
  },

  /**
   * Check if current course is complete
   */
  checkCourseCompletion() {
    const courseId = this.state.currentCourse.id;
    const courseProgress = this.state.userProgress.courses[courseId];
    
    const totalSections = this.state.currentCourse.sections.length;
    const completedSections = Object.values(courseProgress.sections).filter(s => s.completedAt).length;
    
    if (completedSections === totalSections && !courseProgress.completedAt) {
      courseProgress.completedAt = new Date().toISOString();
      courseProgress.progress = 100;
      
      this.dispatchEvent('course-completed', { course: this.state.currentCourse });
    }
  },

  /**
   * Calculate score based on performance
   */
  calculateScore(result) {
    if (!result.results) return 0;
    
    const totalTests = result.results.length;
    const passedTests = result.results.filter(r => r.passed).length;
    const baseScore = (passedTests / totalTests) * 100;
    
    // Apply penalties
    let score = baseScore;
    
    // Penalty for attempts
    if (this.state.lessonState.attempts > 1) {
      score *= Math.max(0.5, 1 - (this.state.lessonState.attempts - 1) * 0.1);
    }
    
    // Penalty for hints
    if (this.state.lessonState.hints.length > 0) {
      score *= Math.max(0.7, 1 - this.state.lessonState.hints.length * 0.05);
    }
    
    return Math.round(score);
  },

  /**
   * Get user progress for course
   */
  getCourseProgress(courseId) {
    return this.state.userProgress.courses[courseId] || null;
  },

  /**
   * Get overall progress summary
   */
  getProgressSummary() {
    const courses = Object.values(this.state.userProgress.courses);
    const totalCourses = courses.length;
    const completedCourses = courses.filter(c => c.completedAt).length;
    
    let totalLessons = 0;
    let completedLessons = 0;
    
    courses.forEach(course => {
      Object.values(course.sections).forEach(section => {
        const lessons = Object.values(section.lessons);
        totalLessons += lessons.length;
        completedLessons += lessons.filter(l => l.completedAt).length;
      });
    });

    return {
      totalCourses,
      completedCourses,
      totalLessons,
      completedLessons,
      totalTime: this.state.userProgress.totalTime,
      lastActivity: this.state.userProgress.lastActivity,
      overallProgress: totalLessons > 0 ? (completedLessons / totalLessons) * 100 : 0
    };
  },

  /**
   * Save progress to storage
   */
  saveProgress() {
    try {
      this.state.userProgress.lastActivity = new Date().toISOString();
      const progressString = JSON.stringify(this.state.userProgress);
      localStorage.setItem(this.config.storageKey, progressString);
      this.dispatchEvent('progress-saved');
      return true;
    } catch (error) {
      console.error('Failed to save progress:', error);
      this.dispatchEvent('progress-save-failed', { error });
      return false;
    }
  },

  /**
   * Reset progress for course
   */
  resetCourseProgress(courseId) {
    if (this.state.userProgress.courses[courseId]) {
      delete this.state.userProgress.courses[courseId];
      this.saveProgress();
      this.dispatchEvent('course-progress-reset', { courseId });
    }
  },

  /**
   * Export progress data
   */
  exportProgress() {
    const blob = new Blob([JSON.stringify(this.state.userProgress, null, 2)], {
      type: 'application/json'
    });
    
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `progen-progress-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    this.dispatchEvent('progress-exported');
  },

  /**
   * Dispatch custom event
   */
  dispatchEvent(eventType, detail = {}) {
    const event = new CustomEvent(`learning-engine-${eventType}`, {
      detail,
      bubbles: true
    });
    document.dispatchEvent(event);
  },

  /**
   * Add event listener
   */
  addEventListener(eventType, callback) {
    document.addEventListener(`learning-engine-${eventType}`, callback);
  },

  /**
   * Remove event listener
   */
  removeEventListener(eventType, callback) {
    document.removeEventListener(`learning-engine-${eventType}`, callback);
  },

  /**
   * Get debug information
   */
  getDebugInfo() {
    return {
      isInitialized: this.state.isInitialized,
      currentCourse: this.state.currentCourse?.id || null,
      currentSection: this.state.currentSection?.id || null,
      currentLesson: this.state.currentLesson?.id || null,
      currentContentIndex: this.state.currentContentIndex,
      lessonState: this.state.lessonState,
      progressSummary: this.getProgressSummary(),
      config: this.config
    };
  }
};

// Auto-initialize when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    LearningEngine.init().catch(console.error);
  });
} else {
  LearningEngine.init().catch(console.error);
}

// Export for use in other modules
if (typeof window !== 'undefined') {
  window.LearningEngine = LearningEngine;
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = LearningEngine;
}


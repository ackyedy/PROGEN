/**
 * PROGEN Enhanced Authentication System
 * Integrates with UserService and provides UI components
 */

'use strict';

const ProgenAuth = {
  // Configuration
  config: {
    loginFormSelector: '#login-form',
    loginButtonSelector: '#login-btn',
    logoutButtonSelector: '#logout-btn',
    userDisplaySelector: '.user-display',
    modalSelector: '#auth-modal',
    overlaySelector: '#auth-overlay'
  },

  // State
  state: {
    isInitialized: false,
    isModalOpen: false,
    currentForm: 'login', // 'login' or 'register'
    isLoading: false
  },

  /**
   * Initialize the authentication system
   */
  init() {
    if (this.state.isInitialized) return;

    try {
      this.setupEventListeners();
      this.setupUserServiceListeners();
      this.updateUI();
      this.createAuthModal();
      
      this.state.isInitialized = true;
      console.log('Enhanced Authentication initialized! 🔐');
    } catch (error) {
      console.error('Failed to initialize authentication:', error);
    }
  },

  /**
   * Set up event listeners
   */
  setupEventListeners() {
    // Login button click
    document.addEventListener('click', (e) => {
      if (e.target.matches(this.config.loginButtonSelector)) {
        e.preventDefault();
        this.showLoginModal();
      }
    });

    // Logout button click
    document.addEventListener('click', (e) => {
      if (e.target.matches(this.config.logoutButtonSelector)) {
        e.preventDefault();
        this.handleLogout();
      }
    });

    // Modal overlay click
    document.addEventListener('click', (e) => {
      if (e.target.matches(this.config.overlaySelector)) {
        this.hideModal();
      }
    });

    // Escape key to close modal
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && this.state.isModalOpen) {
        this.hideModal();
      }
    });
  },

  /**
   * Set up UserService event listeners
   */
  setupUserServiceListeners() {
    // Listen for login events
    UserService.addEventListener('user-logged-in', (e) => {
      this.handleLoginSuccess(e.detail.user);
    });

    // Listen for logout events
    UserService.addEventListener('user-logged-out', () => {
      this.handleLogoutSuccess();
    });

    // Listen for service initialization
    UserService.addEventListener('user-service-initialized', (e) => {
      this.updateUI();
    });
  },

  /**
   * Create authentication modal
   */
  createAuthModal() {
    // Check if modal already exists
    if (document.querySelector(this.config.modalSelector)) return;

    const modalHTML = `
      <div id="auth-overlay" class="auth-overlay" style="display: none;">
        <div id="auth-modal" class="auth-modal glass-card">
          <div class="auth-modal-header">
            <h2 id="auth-modal-title">ログイン</h2>
            <button class="auth-modal-close" aria-label="閉じる">&times;</button>
          </div>
          
          <div class="auth-modal-body">
            <!-- Login Form -->
            <form id="login-form" class="auth-form">
              <div class="form-group">
                <label for="login-email">メールアドレス</label>
                <input 
                  type="email" 
                  id="login-email" 
                  name="email" 
                  class="input" 
                  required 
                  autocomplete="email"
                  placeholder="demo@progen.com"
                >
              </div>
              
              <div class="form-group">
                <label for="login-password">パスワード</label>
                <input 
                  type="password" 
                  id="login-password" 
                  name="password" 
                  class="input" 
                  required 
                  autocomplete="current-password"
                  placeholder="demo123"
                >
              </div>
              
              <div class="form-actions">
                <button type="submit" class="btn" id="login-submit">
                  <span class="btn-text">ログイン</span>
                  <span class="btn-loading" style="display: none;">
                    <span class="spinner"></span>
                    ログイン中...
                  </span>
                </button>
              </div>
              
              <div class="form-footer">
                <p>アカウントをお持ちでない方は <button type="button" class="link-btn" id="show-register">新規登録</button></p>
              </div>
            </form>

            <!-- Register Form -->
            <form id="register-form" class="auth-form" style="display: none;">
              <div class="form-group">
                <label for="register-name">お名前</label>
                <input 
                  type="text" 
                  id="register-name" 
                  name="name" 
                  class="input" 
                  required 
                  autocomplete="name"
                  placeholder="山田太郎"
                >
              </div>
              
              <div class="form-group">
                <label for="register-email">メールアドレス</label>
                <input 
                  type="email" 
                  id="register-email" 
                  name="email" 
                  class="input" 
                  required 
                  autocomplete="email"
                  placeholder="yamada@example.com"
                >
              </div>
              
              <div class="form-group">
                <label for="register-password">パスワード</label>
                <input 
                  type="password" 
                  id="register-password" 
                  name="password" 
                  class="input" 
                  required 
                  autocomplete="new-password"
                  placeholder="6文字以上"
                  minlength="6"
                >
              </div>
              
              <div class="form-actions">
                <button type="submit" class="btn" id="register-submit">
                  <span class="btn-text">新規登録</span>
                  <span class="btn-loading" style="display: none;">
                    <span class="spinner"></span>
                    登録中...
                  </span>
                </button>
              </div>
              
              <div class="form-footer">
                <p>既にアカウントをお持ちの方は <button type="button" class="link-btn" id="show-login">ログイン</button></p>
              </div>
            </form>

            <!-- Demo Accounts Info -->
            <div class="demo-accounts">
              <h3>デモアカウント</h3>
              <div class="demo-account-list">
                <div class="demo-account">
                  <strong>demo@progen.com</strong> / demo123
                  <span class="demo-role">学習者</span>
                </div>
                <div class="demo-account">
                  <strong>admin@progen.com</strong> / admin123
                  <span class="demo-role">管理者</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    `;

    document.body.insertAdjacentHTML('beforeend', modalHTML);
    this.setupModalEventListeners();
    this.addModalStyles();
  },

  /**
   * Set up modal event listeners
   */
  setupModalEventListeners() {
    // Close button
    document.querySelector('.auth-modal-close')?.addEventListener('click', () => {
      this.hideModal();
    });

    // Form switching
    document.getElementById('show-register')?.addEventListener('click', () => {
      this.switchForm('register');
    });

    document.getElementById('show-login')?.addEventListener('click', () => {
      this.switchForm('login');
    });

    // Form submissions
    document.getElementById('login-form')?.addEventListener('submit', (e) => {
      e.preventDefault();
      this.handleLoginSubmit(e);
    });

    document.getElementById('register-form')?.addEventListener('submit', (e) => {
      e.preventDefault();
      this.handleRegisterSubmit(e);
    });
  },

  /**
   * Add modal styles
   */
  addModalStyles() {
    const style = document.createElement('style');
    style.textContent = `
      .auth-overlay {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0, 0, 0, 0.5);
        backdrop-filter: blur(5px);
        z-index: 1000;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 20px;
        opacity: 0;
        transition: opacity 0.3s ease;
      }

      .auth-overlay.show {
        opacity: 1;
      }

      .auth-modal {
        background: var(--color-bg, #fcf8e8);
        border: 3px solid var(--color-fg, #1a1a1a);
        border-radius: 16px;
        box-shadow: 8px 8px 0px var(--color-fg, #1a1a1a);
        max-width: 500px;
        width: 100%;
        max-height: 90vh;
        overflow-y: auto;
        transform: scale(0.9) translateY(20px);
        transition: transform 0.3s cubic-bezier(0.68, -0.55, 0.265, 1.55);
      }

      .auth-overlay.show .auth-modal {
        transform: scale(1) translateY(0);
      }

      .auth-modal-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 24px 24px 0;
        border-bottom: 2px solid var(--color-fg, #1a1a1a);
        margin-bottom: 24px;
      }

      .auth-modal-header h2 {
        margin: 0;
        font-size: 24px;
        font-weight: 900;
        color: var(--color-fg, #1a1a1a);
      }

      .auth-modal-close {
        background: none;
        border: none;
        font-size: 24px;
        font-weight: bold;
        cursor: pointer;
        color: var(--color-fg, #1a1a1a);
        padding: 0;
        width: 32px;
        height: 32px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 50%;
        transition: background-color 0.2s ease;
      }

      .auth-modal-close:hover {
        background: var(--color-accent, #ff0000);
        color: white;
      }

      .auth-modal-close:focus {
        outline: 2px solid var(--color-accent, #ff0000);
        outline-offset: 2px;
      }

      .auth-modal-body {
        padding: 0 24px 24px;
      }

      .auth-form {
        margin-bottom: 24px;
      }

      .form-group {
        margin-bottom: 20px;
      }

      .form-group label {
        display: block;
        margin-bottom: 8px;
        font-weight: 700;
        color: var(--color-fg, #1a1a1a);
      }

      .form-group .input {
        width: 100%;
        padding: 12px 16px;
        border: 3px solid var(--color-fg, #1a1a1a);
        border-radius: 8px;
        font-size: 16px;
        background: var(--color-bg, #fcf8e8);
        color: var(--color-fg, #1a1a1a);
        box-shadow: inset 2px 2px 0px var(--color-muted, #555555);
        transition: all 0.2s ease;
      }

      .form-group .input:focus {
        outline: 2px solid var(--color-accent, #ff0000);
        outline-offset: 2px;
        box-shadow: inset 2px 2px 0px var(--color-accent, #ff0000);
      }

      .form-group .input::placeholder {
        color: var(--color-muted, #555555);
      }

      .form-actions {
        margin: 24px 0;
      }

      .form-actions .btn {
        width: 100%;
        padding: 16px;
        font-size: 16px;
        font-weight: 700;
        position: relative;
      }

      .btn-loading {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
      }

      .spinner {
        width: 16px;
        height: 16px;
        border: 2px solid transparent;
        border-top: 2px solid currentColor;
        border-radius: 50%;
        animation: spin 1s linear infinite;
      }

      @keyframes spin {
        to { transform: rotate(360deg); }
      }

      .form-footer {
        text-align: center;
        color: var(--color-muted, #555555);
        font-size: 14px;
      }

      .link-btn {
        background: none;
        border: none;
        color: var(--color-accent, #ff0000);
        text-decoration: underline;
        cursor: pointer;
        font-size: inherit;
        padding: 0;
      }

      .link-btn:hover {
        color: var(--color-primary, #ffcc00);
      }

      .link-btn:focus {
        outline: 2px solid var(--color-accent, #ff0000);
        outline-offset: 2px;
      }

      .demo-accounts {
        background: var(--color-glass-bg, rgba(255, 255, 255, 0.8));
        border: 2px solid var(--color-fg, #1a1a1a);
        border-radius: 12px;
        padding: 16px;
        margin-top: 24px;
      }

      .demo-accounts h3 {
        margin: 0 0 12px;
        font-size: 16px;
        font-weight: 700;
        color: var(--color-fg, #1a1a1a);
      }

      .demo-account {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 8px 0;
        border-bottom: 1px solid var(--color-muted, #555555);
        font-size: 14px;
      }

      .demo-account:last-child {
        border-bottom: none;
      }

      .demo-role {
        background: var(--color-primary, #ffcc00);
        color: var(--color-fg, #1a1a1a);
        padding: 2px 8px;
        border-radius: 12px;
        font-size: 12px;
        font-weight: 700;
        border: 1px solid var(--color-fg, #1a1a1a);
      }

      .error-message {
        background: var(--color-error, #dc3545);
        color: white;
        padding: 12px 16px;
        border-radius: 8px;
        margin-bottom: 16px;
        font-size: 14px;
        border: 2px solid var(--color-fg, #1a1a1a);
        box-shadow: 2px 2px 0px var(--color-fg, #1a1a1a);
      }

      /* Dark theme adjustments */
      html[data-theme="dark"] .auth-modal {
        background: var(--color-bg, #1a1a1a);
        border-color: var(--color-primary, #ffcc00);
        box-shadow: 8px 8px 0px var(--color-primary, #ffcc00);
      }

      html[data-theme="dark"] .auth-modal-header {
        border-color: var(--color-primary, #ffcc00);
      }

      html[data-theme="dark"] .form-group .input {
        background: var(--color-bg, #1a1a1a);
        border-color: var(--color-primary, #ffcc00);
      }

      html[data-theme="dark"] .demo-accounts {
        background: var(--color-glass-bg, rgba(0, 0, 0, 0.8));
        border-color: var(--color-primary, #ffcc00);
      }

      /* Responsive design */
      @media (max-width: 480px) {
        .auth-overlay {
          padding: 10px;
        }

        .auth-modal {
          max-height: 95vh;
        }

        .auth-modal-header,
        .auth-modal-body {
          padding-left: 16px;
          padding-right: 16px;
        }
      }
    `;
    document.head.appendChild(style);
  },

  /**
   * Show login modal
   */
  showLoginModal() {
    const overlay = document.querySelector(this.config.overlaySelector);
    if (!overlay) return;

    this.state.isModalOpen = true;
    this.switchForm('login');
    
    overlay.style.display = 'flex';
    requestAnimationFrame(() => {
      overlay.classList.add('show');
    });

    // Focus on email input
    setTimeout(() => {
      document.getElementById('login-email')?.focus();
    }, 300);
  },

  /**
   * Hide modal
   */
  hideModal() {
    const overlay = document.querySelector(this.config.overlaySelector);
    if (!overlay) return;

    this.state.isModalOpen = false;
    overlay.classList.remove('show');
    
    setTimeout(() => {
      overlay.style.display = 'none';
      this.clearForms();
      this.clearErrors();
    }, 300);
  },

  /**
   * Switch between login and register forms
   */
  switchForm(formType) {
    this.state.currentForm = formType;
    
    const loginForm = document.getElementById('login-form');
    const registerForm = document.getElementById('register-form');
    const title = document.getElementById('auth-modal-title');

    if (formType === 'login') {
      loginForm.style.display = 'block';
      registerForm.style.display = 'none';
      title.textContent = 'ログイン';
    } else {
      loginForm.style.display = 'none';
      registerForm.style.display = 'block';
      title.textContent = '新規登録';
    }

    this.clearErrors();
  },

  /**
   * Handle login form submission
   */
  async handleLoginSubmit(e) {
    const form = e.target;
    const formData = new FormData(form);
    const email = formData.get('email');
    const password = formData.get('password');

    this.setLoading(true);
    this.clearErrors();

    try {
      const result = await UserService.signIn(email, password);
      
      if (result.success) {
        // Success is handled by the user service event listener
        this.hideModal();
      } else {
        this.showError(result.error);
      }
    } catch (error) {
      console.error('Login error:', error);
      this.showError('ログイン処理中にエラーが発生しました');
    } finally {
      this.setLoading(false);
    }
  },

  /**
   * Handle register form submission
   */
  async handleRegisterSubmit(e) {
    const form = e.target;
    const formData = new FormData(form);
    const name = formData.get('name');
    const email = formData.get('email');
    const password = formData.get('password');

    this.setLoading(true, 'register');
    this.clearErrors();

    try {
      // For demo purposes, show that registration is not implemented
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      this.showError('新規登録機能は現在開発中です。デモアカウントをご利用ください。');
      
    } catch (error) {
      console.error('Register error:', error);
      this.showError('登録処理中にエラーが発生しました');
    } finally {
      this.setLoading(false, 'register');
    }
  },

  /**
   * Handle logout
   */
  async handleLogout() {
    try {
      const result = await UserService.signOut();
      
      if (result.success) {
        // Success is handled by the user service event listener
      } else {
        ToastNotifications.error('ログアウトに失敗しました');
      }
    } catch (error) {
      console.error('Logout error:', error);
      ToastNotifications.error('ログアウト処理中にエラーが発生しました');
    }
  },

  /**
   * Handle successful login
   */
  handleLoginSuccess(user) {
    this.updateUI();
    ToastNotifications.success(`${user.name}さん、おかえりなさい！`);
  },

  /**
   * Handle successful logout
   */
  handleLogoutSuccess() {
    this.updateUI();
    ToastNotifications.info('ログアウトしました');
  },

  /**
   * Update UI based on authentication state
   */
  updateUI() {
    const isLoggedIn = UserService.isLoggedIn();
    const currentUser = UserService.currentUser();

    // Update login/logout buttons
    const loginBtn = document.querySelector(this.config.loginButtonSelector);
    const logoutBtn = document.querySelector(this.config.logoutButtonSelector);

    if (loginBtn) {
      if (isLoggedIn) {
        loginBtn.textContent = currentUser?.name || 'ユーザー';
        loginBtn.classList.add('logged-in');
      } else {
        loginBtn.textContent = 'ログイン';
        loginBtn.classList.remove('logged-in');
      }
    }

    // Show/hide logout button
    if (logoutBtn) {
      logoutBtn.style.display = isLoggedIn ? 'inline-flex' : 'none';
    }

    // Update user display areas
    const userDisplays = document.querySelectorAll(this.config.userDisplaySelector);
    userDisplays.forEach(display => {
      if (isLoggedIn && currentUser) {
        display.innerHTML = `
          <div class="user-info">
            <span class="user-name">${currentUser.name}</span>
            <span class="user-level">Lv.${currentUser.level}</span>
          </div>
        `;
        display.style.display = 'block';
      } else {
        display.style.display = 'none';
      }
    });
  },

  /**
   * Set loading state
   */
  setLoading(loading, formType = 'login') {
    this.state.isLoading = loading;
    
    const submitBtn = document.getElementById(`${formType}-submit`);
    const btnText = submitBtn?.querySelector('.btn-text');
    const btnLoading = submitBtn?.querySelector('.btn-loading');

    if (submitBtn) {
      submitBtn.disabled = loading;
      
      if (btnText && btnLoading) {
        btnText.style.display = loading ? 'none' : 'inline';
        btnLoading.style.display = loading ? 'flex' : 'none';
      }
    }
  },

  /**
   * Show error message
   */
  showError(message) {
    this.clearErrors();
    
    const activeForm = this.state.currentForm === 'login' 
      ? document.getElementById('login-form')
      : document.getElementById('register-form');

    if (activeForm) {
      const errorDiv = document.createElement('div');
      errorDiv.className = 'error-message';
      errorDiv.textContent = message;
      activeForm.insertBefore(errorDiv, activeForm.firstChild);
    }
  },

  /**
   * Clear error messages
   */
  clearErrors() {
    const errorMessages = document.querySelectorAll('.error-message');
    errorMessages.forEach(error => error.remove());
  },

  /**
   * Clear form data
   */
  clearForms() {
    const forms = document.querySelectorAll('.auth-form');
    forms.forEach(form => form.reset());
  },

  /**
   * Get debug information
   */
  getDebugInfo() {
    return {
      isInitialized: this.state.isInitialized,
      isModalOpen: this.state.isModalOpen,
      currentForm: this.state.currentForm,
      isLoading: this.state.isLoading,
      userServiceStatus: UserService.getDebugInfo()
    };
  }
};

// Auto-initialize when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    ProgenAuth.init();
  });
} else {
  ProgenAuth.init();
}

// Export for use in other modules
if (typeof window !== 'undefined') {
  window.ProgenAuth = ProgenAuth;
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = ProgenAuth;
}


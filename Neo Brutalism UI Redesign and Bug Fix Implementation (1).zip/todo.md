### Phase 1: プロジェクト分析と環境構築
- [x] 1.1: 既存コードベースの再分析と新要件とのギャップ特定
- [x] 1.2: `index.html` と `index-enhanced.html` の二重化解消
- [x] 1.3: 旧 `styles.css` / `auth.js` の読み込み廃止
- [x] 1.4: `styles-neo-brutalism.css` 先頭のグローバル `!important` の廃止と、必要なコンポーネントへの限定適用
- [x] 1.5: 配色が可視領域やスクロールで変わる不具合（`mix-blend-mode` / `filter` / `hue-rotate` / `IntersectionObserver` 由来）の根本修正方針の策定
- [x] 1.6: Web Worker の実体 (`/workers/runner.js`) の作成
- [x] 1.7: Studio の CRUD 画面の完全実装方針の策定
- [x] 1.8: `users.json` の擬似DB直読みの対処方針の策定
- [x] 1.9: レッスン配信を単一パッケージ（.progen）方式へ刷新する方針の策定

### Phase 2: デザインシステムとテーママネージャーの根本修正と強化
- [x] 2.1: サイト全体のUIを「Neo Brutalism」寄り（太めのアウトライン、はっきりした配色、フラットな面、わざとらしいドロップシャドウや“ステッカー”風アクセント）で統一
- [x] 2.2: 既存のCSSが視覚領域に入った瞬間に別配色へ置き換わる不具合（スクロール時や要素可視化時にmix-blend-mode/グラデーションオーバーレイ/セクション別テーマが上書きしている、またはCSSの優先度競合・JSのクラス付け替え）を根本修正
- [x] 2.3: 配色をデザイントークン（`--color-bg`, `--color-fg`, `--color-accent`, `--radius`, `--shadow`, `--outline` 等）に集約
- [x] 2.4: `data-theme="light|dark"` と時間帯（12h/24h指定可）+OSの`prefers-color-scheme`の両方を考慮するテーママネージャーを実装
- [x] 2.5: 手動トグル（ローカルストレージ永続化）と自動切替の両立、トグルはヘッダー右上に常設
- [x] 2.6: ボタンが“変な縁取り”になる問題は、`:focus`と`:focus-visible`のスタイルをアクセシブルなアウトライン（2–3pxのソリッド/ドット）に統一し、`outline-offset`を適切化、同時に`box-shadow`の多重適用や`border`/`outline`の競合を排除

### Phase 3: 認証システムとユーザー管理の改善
- [x] 3.1: `auth.js` の直書きを廃止し、`/data/users.json`（開発用の擬似DB）または将来APIに差し替え可能な `UserService`（`getUserByEmail`／`signIn`／`signOut`／`currentUser`／`hasRole`）へ置換
- [x] 3.2: パスワードは平文保存禁止・簡易ハッシュ比較
- [x] 3.3: ロール（`student`／`teacher`／`admin`）でルートガード
- [x] 3.4: トースト通知、セッション永続化、レートリミット、アクセシブルなエラーメッセージを実装
- [x] 3.5: デモアカウント `demo@progen.com` / `demo123`（student）と `admin@progen.com` / `admin123`（admin）を同梱

### Phase 4: ナビゲーションとUIコンポーネントの再設計
- [x] 4.1: ナビゲーション（「体験」「講座」「進捗」「料金」「FAQ」）は視認性と情報設計を再設計し、コントラスト比を4.5:1以上、ホバー／フォーカス／アクティブの3状態、現在地ハイライト（下線またはピル背景）、スムーススクロール＋オフセット補正、モバイルはハンバーガー化にしてください。
- [x] 4.2: ヒーローの「PROGEN」は初回ロード時のみ約0.8秒のタイポアニメ（スケールイン＋軽いYモーション＋太いアウトライン出現）を再生し、`prefers-reduced-motion`に対応、再訪時は短縮または無効化します。

### Phase 5: レッスン配信システムの設計と実装（ProgenPackageLoader）
- [x] 5.1: 拡張子 `.progen`（中身はZIP、MIME: `application/x-progen+zip`）で Studio からエクスポートし、`manifest.json`（`schemaVersion`, `buildId`, `createdAt`, `engineMinVersion`, `signature`）／`course.json`／`lessons/{lessonId}/lesson.json`・`slides.md`・`challenge.json`・`tests/.json`・`assets/`・`thumbnail.png` を内包する単一パッケージ方式へ刷新
- [x] 5.2: 署名（HMAC または Ed25519）を付与
- [x] 5.3: CDN（例: `/courses/{slug}/{version}/{lessonId}.progen`）に原子的に配置
- [x] 5.4: `index.json` で最新版を解決
- [x] 5.5: 学習側は `ProgenPackageLoader` で `fetch`→ストリーム解凍→検証→IndexedDB キャッシュ（`ETag`／`buildId` で再検証）→ `learning-engine` へ供給

### Phase 6: 学習プラットフォームとエディタの改善（JSON駆動、Web Worker）
- [x] 6.1: 学習側ページはこのJSONを読み取り、①導入スライド→②コードエディタ課題→③採点（テストケース/正規表現/スナップショット）→④フィードバック→⑤進捗保存、のフローを自動生成
- [x] 6.2: エディタは既存のものを活かしつつ、入出力パネルのレイアウトをネオ・ブルータル調に刷新
- [x] 6.3: 実行と採点はWeb Worker (`/workers/runner.js`) で分離、クラッシュ耐性とタイムアウト、結果のバッジ表示
- [x] 6.4: 進捗は`localStorage`（将来はAPI）に保存し、ナビの「進捗」に完了率リングと直近レッスンのリジュームボタンを表示

### Phase 7: コンテンツ管理システム（Studio）のGUI実装とパッケージエクスポート
- [x] 7.1: Studio（管理UI）は `progen_studio/` 配下に実体画面を実装し、CRUD、ドラッグ&ドロップ並べ替え、ライブプレビュー、バリデーション、公開／下書き切替、`/data/courses/{slug}.json` 出力までGUIで完結できるようにする
- [x] 7.2: パッケージエクスポート機能の実装（`.progen` ファイル生成）
- [x] 7.3: 署名機能の実装（HMAC または Ed25519）

### Phase 8: アクセシビリティとパフォーマンス最適化の最終調整
- [x] 8.1: すべての新旧ページでテーマとコンポーネントが一貫するようにスタイルの依存関係を整理し、不要なグローバルセレクタや`!important`を撤廃、BEMまたはユーティリティクラス方針に統一
- [x] 8.2: アクセシビリティ（フォーカス可視化、キーボード操作、ラベル/aria属性）、日本語フォントの読み込み最適化（可変フォント＋`font-display: swap`）、画像の`loading="lazy"`、クリティカルCSS抽出、CLS低減、ライトハウス80点台後半以上を目標

### Phase 9: 統合テストとデプロイ準備、成果物の作成
- [x] 9.1: 全機能の統合テストと受け入れ条件の確認
- [x] 9.2: 環境変数とルーティング/パスを`config.ts`（または`config.js`）で一元管理し、ハードコードを排除
- [x] 9.3: 動作可能な圧縮ファイル（ZIP）として納品物を準備
- [x] 9.4: 最上位に `README.md`（起動／ビルド／設定手順）、`config.js`、`progen_home/`（強化済みUI・ヒーローアニメ・ナビ改善・テーマトグル）、`progen_learn/`（`ProgenPackageLoader`・`learning-engine`・UI）、`progen_studio/`（GUI一式・パッケージエクスポート・署名）、`shared/`（`design-system.css`・`ui-components.js`・`toast-notifications.js`・`theme-manager.js`・`route-guard.js`・`performance-optimizer.js`・`accessibility.js`・`UserService.js`・`ContentService.js`）、`workers/runner.js`、`data/index.json` とサンプル `.progen`（例：`/courses/sample/1.0.0/intro.progen`）、`tests/test-results.md`、`scripts/`（ローカル署名キー生成・開発用サーバスクリプト）を含める
- [x] 9.5: デモアカウント `demo@progen.com` / `demo123`（student）と `admin@progen.com` / `admin123`（admin）を同梱
- [x] 9.6: 最終確認とユーザーへの報告


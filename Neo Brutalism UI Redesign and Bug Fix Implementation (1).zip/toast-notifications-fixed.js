/**
 * PROGEN Platform - Toast Notifications System (Fixed)
 * 
 * This system provides:
 * 1. Accessible toast notifications with ARIA support
 * 2. Multiple notification types (success, error, warning, info)
 * 3. Auto-dismiss and manual dismiss options
 * 4. Queue management for multiple notifications
 * 5. Neo Brutalism styling integration
 */

class ToastNotifications {
  constructor() {
    this.container = null;
    this.notifications = new Map();
    this.queue = [];
    this.maxVisible = 5;
    this.defaultDuration = 4000;
    
    this.init();
  }

  init() {
    this.createContainer();
    this.setupStyles();
  }

  /**
   * Create toast container
   */
  createContainer() {
    this.container = document.createElement('div');
    this.container.id = 'toast-container';
    this.container.className = 'toast-container';
    this.container.setAttribute('aria-live', 'polite');
    this.container.setAttribute('aria-label', '通知');
    
    document.body.appendChild(this.container);
  }

  /**
   * Setup toast styles
   */
  setupStyles() {
    if (document.getElementById('toast-styles')) return;
    
    const styles = document.createElement('style');
    styles.id = 'toast-styles';
    styles.textContent = `
      .toast-container {
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 10000;
        display: flex;
        flex-direction: column;
        gap: var(--space-sm, 0.5rem);
        max-width: 400px;
        pointer-events: none;
      }
      
      .toast {
        background-color: var(--color-surface, #ffffff);
        border: var(--outline, 3px solid var(--color-fg, #1a1a1a));
        border-radius: var(--radius, 8px);
        box-shadow: var(--shadow, 4px 4px 0px var(--color-fg, #1a1a1a));
        padding: var(--space-md, 1rem);
        min-width: 300px;
        max-width: 400px;
        pointer-events: auto;
        position: relative;
        transform: translateX(100%);
        opacity: 0;
        transition: all var(--duration-normal, 0.3s) var(--ease-out, ease-out);
        font-family: var(--font-sans, sans-serif);
        color: var(--color-fg, #1a1a1a);
      }
      
      .toast.show {
        transform: translateX(0);
        opacity: 1;
      }
      
      .toast.hide {
        transform: translateX(100%);
        opacity: 0;
      }
      
      .toast-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: var(--space-sm, 0.5rem);
      }
      
      .toast-title {
        font-weight: 700;
        font-size: 1rem;
        margin: 0;
        display: flex;
        align-items: center;
        gap: var(--space-sm, 0.5rem);
      }
      
      .toast-close {
        background: none;
        border: none;
        font-size: 1.5rem;
        cursor: pointer;
        padding: 0;
        width: 24px;
        height: 24px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: var(--color-fg, #1a1a1a);
        border-radius: var(--radius-sm, 4px);
        transition: all var(--duration-fast, 0.15s) var(--ease-out, ease-out);
      }
      
      .toast-close:hover {
        background-color: var(--color-surface-alt, #e5e5e5);
      }
      
      .toast-close:focus-visible {
        outline: 2px solid var(--color-focus, #0088ff);
        outline-offset: 2px;
      }
      
      .toast-message {
        margin: 0;
        line-height: 1.4;
      }
      
      .toast-progress {
        position: absolute;
        bottom: 0;
        left: 0;
        height: 3px;
        background-color: var(--toast-accent-color, var(--color-primary, #ffcc00));
        border-radius: 0 0 var(--radius, 8px) var(--radius, 8px);
        transition: width linear;
      }
      
      /* Toast type variants */
      .toast.success {
        --toast-accent-color: var(--color-success, #00cc44);
        border-left: 6px solid var(--color-success, #00cc44);
      }
      
      .toast.error {
        --toast-accent-color: var(--color-error, #ff0044);
        border-left: 6px solid var(--color-error, #ff0044);
      }
      
      .toast.warning {
        --toast-accent-color: var(--color-warning, #ff8800);
        border-left: 6px solid var(--color-warning, #ff8800);
      }
      
      .toast.info {
        --toast-accent-color: var(--color-info, #0088ff);
        border-left: 6px solid var(--color-info, #0088ff);
      }
      
      /* Icons */
      .toast-icon {
        font-size: 1.2rem;
        flex-shrink: 0;
      }
      
      .toast.success .toast-icon::before { content: '✓'; }
      .toast.error .toast-icon::before { content: '✕'; }
      .toast.warning .toast-icon::before { content: '⚠'; }
      .toast.info .toast-icon::before { content: 'ℹ'; }
      
      /* Responsive design */
      @media (max-width: 480px) {
        .toast-container {
          top: 10px;
          right: 10px;
          left: 10px;
          max-width: none;
        }
        
        .toast {
          min-width: auto;
          max-width: none;
        }
      }
      
      /* Reduced motion support */
      @media (prefers-reduced-motion: reduce) {
        .toast {
          transition: opacity var(--duration-fast, 0.15s) ease-out;
        }
        
        .toast.show {
          transform: none;
        }
        
        .toast.hide {
          transform: none;
        }
      }
    `;
    
    document.head.appendChild(styles);
  }

  /**
   * Show a toast notification
   */
  show(options) {
    const config = {
      type: 'info',
      title: '',
      message: '',
      duration: this.defaultDuration,
      persistent: false,
      actions: [],
      ...options
    };

    // Validate type
    if (!['success', 'error', 'warning', 'info'].includes(config.type)) {
      config.type = 'info';
    }

    // Create notification
    const notification = this.createNotification(config);
    
    // Add to queue if too many visible
    if (this.notifications.size >= this.maxVisible) {
      this.queue.push(notification);
      return notification.id;
    }

    // Show notification
    this.displayNotification(notification);
    
    return notification.id;
  }

  /**
   * Create notification object
   */
  createNotification(config) {
    const id = this.generateId();
    
    return {
      id,
      config,
      element: null,
      timer: null,
      progressTimer: null
    };
  }

  /**
   * Display notification
   */
  displayNotification(notification) {
    const { config } = notification;
    
    // Create DOM element
    const element = this.createToastElement(notification);
    notification.element = element;
    
    // Add to container
    this.container.appendChild(element);
    
    // Add to active notifications
    this.notifications.set(notification.id, notification);
    
    // Trigger show animation
    requestAnimationFrame(() => {
      element.classList.add('show');
    });
    
    // Set up auto-dismiss
    if (!config.persistent && config.duration > 0) {
      this.setupAutoDismiss(notification);
    }
    
    // Announce to screen readers
    this.announceToScreenReader(config);
  }

  /**
   * Create toast DOM element
   */
  createToastElement(notification) {
    const { config } = notification;
    
    const toast = document.createElement('div');
    toast.className = `toast ${config.type}`;
    toast.setAttribute('role', 'alert');
    toast.setAttribute('aria-live', config.type === 'error' ? 'assertive' : 'polite');
    
    const header = document.createElement('div');
    header.className = 'toast-header';
    
    const title = document.createElement('h3');
    title.className = 'toast-title';
    
    if (config.title) {
      const icon = document.createElement('span');
      icon.className = 'toast-icon';
      icon.setAttribute('aria-hidden', 'true');
      
      title.appendChild(icon);
      title.appendChild(document.createTextNode(config.title));
    }
    
    const closeButton = document.createElement('button');
    closeButton.className = 'toast-close';
    closeButton.setAttribute('aria-label', '通知を閉じる');
    closeButton.innerHTML = '×';
    closeButton.addEventListener('click', () => {
      this.dismiss(notification.id);
    });
    
    header.appendChild(title);
    header.appendChild(closeButton);
    
    const message = document.createElement('p');
    message.className = 'toast-message';
    message.textContent = config.message;
    
    toast.appendChild(header);
    toast.appendChild(message);
    
    // Add progress bar for auto-dismiss
    if (!config.persistent && config.duration > 0) {
      const progress = document.createElement('div');
      progress.className = 'toast-progress';
      progress.style.width = '100%';
      toast.appendChild(progress);
    }
    
    // Add action buttons if provided
    if (config.actions && config.actions.length > 0) {
      const actions = document.createElement('div');
      actions.className = 'toast-actions';
      actions.style.marginTop = 'var(--space-sm, 0.5rem)';
      actions.style.display = 'flex';
      actions.style.gap = 'var(--space-sm, 0.5rem)';
      
      config.actions.forEach(action => {
        const button = document.createElement('button');
        button.className = 'btn btn-sm';
        button.textContent = action.label;
        button.addEventListener('click', () => {
          if (action.handler) action.handler();
          this.dismiss(notification.id);
        });
        actions.appendChild(button);
      });
      
      toast.appendChild(actions);
    }
    
    return toast;
  }

  /**
   * Set up auto-dismiss timer
   */
  setupAutoDismiss(notification) {
    const { config } = notification;
    
    // Main dismiss timer
    notification.timer = setTimeout(() => {
      this.dismiss(notification.id);
    }, config.duration);
    
    // Progress bar animation
    const progressBar = notification.element.querySelector('.toast-progress');
    if (progressBar) {
      progressBar.style.transition = `width ${config.duration}ms linear`;
      requestAnimationFrame(() => {
        progressBar.style.width = '0%';
      });
    }
    
    // Pause on hover
    notification.element.addEventListener('mouseenter', () => {
      this.pauseAutoDismiss(notification);
    });
    
    notification.element.addEventListener('mouseleave', () => {
      this.resumeAutoDismiss(notification);
    });
  }

  /**
   * Pause auto-dismiss
   */
  pauseAutoDismiss(notification) {
    if (notification.timer) {
      clearTimeout(notification.timer);
      notification.timer = null;
    }
    
    const progressBar = notification.element.querySelector('.toast-progress');
    if (progressBar) {
      progressBar.style.animationPlayState = 'paused';
    }
  }

  /**
   * Resume auto-dismiss
   */
  resumeAutoDismiss(notification) {
    const { config } = notification;
    
    if (!config.persistent && config.duration > 0) {
      notification.timer = setTimeout(() => {
        this.dismiss(notification.id);
      }, config.duration);
    }
    
    const progressBar = notification.element.querySelector('.toast-progress');
    if (progressBar) {
      progressBar.style.animationPlayState = 'running';
    }
  }

  /**
   * Dismiss notification
   */
  dismiss(id) {
    const notification = this.notifications.get(id);
    if (!notification) return;
    
    // Clear timers
    if (notification.timer) {
      clearTimeout(notification.timer);
    }
    
    // Hide animation
    notification.element.classList.add('hide');
    
    // Remove after animation
    setTimeout(() => {
      if (notification.element.parentNode) {
        notification.element.parentNode.removeChild(notification.element);
      }
      this.notifications.delete(id);
      
      // Show next in queue
      this.processQueue();
    }, 300);
  }

  /**
   * Process notification queue
   */
  processQueue() {
    if (this.queue.length > 0 && this.notifications.size < this.maxVisible) {
      const next = this.queue.shift();
      this.displayNotification(next);
    }
  }

  /**
   * Dismiss all notifications
   */
  dismissAll() {
    const ids = Array.from(this.notifications.keys());
    ids.forEach(id => this.dismiss(id));
    this.queue = [];
  }

  /**
   * Announce to screen readers
   */
  announceToScreenReader(config) {
    const announcement = `${config.title ? config.title + ': ' : ''}${config.message}`;
    
    // Create temporary element for screen reader announcement
    const announcer = document.createElement('div');
    announcer.setAttribute('aria-live', config.type === 'error' ? 'assertive' : 'polite');
    announcer.setAttribute('aria-atomic', 'true');
    announcer.className = 'sr-only';
    announcer.textContent = announcement;
    
    document.body.appendChild(announcer);
    
    // Remove after announcement
    setTimeout(() => {
      document.body.removeChild(announcer);
    }, 1000);
  }

  /**
   * Generate unique ID
   */
  generateId() {
    return `toast-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * Convenience methods
   */
  success(title, message, options = {}) {
    return this.show({ type: 'success', title, message, ...options });
  }

  error(title, message, options = {}) {
    return this.show({ type: 'error', title, message, ...options });
  }

  warning(title, message, options = {}) {
    return this.show({ type: 'warning', title, message, ...options });
  }

  info(title, message, options = {}) {
    return this.show({ type: 'info', title, message, ...options });
  }
}

// Initialize ToastNotifications when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    window.toastNotifications = new ToastNotifications();
  });
} else {
  window.toastNotifications = new ToastNotifications();
}

// Export for module systems
if (typeof module !== 'undefined' && module.exports) {
  module.exports = ToastNotifications;
}


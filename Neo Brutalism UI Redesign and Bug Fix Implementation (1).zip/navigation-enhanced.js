/**
 * PROGEN Enhanced Navigation System
 * Neo-Brutalism design with improved accessibility and mobile support
 */

'use strict';

const NavigationEnhanced = {
  // Configuration
  config: {
    navSelector: '.nav',
    hamburgerSelector: '.hamburger-menu',
    mobileNavSelector: '.mobile-nav',
    headerSelector: 'header',
    scrollThreshold: 100,
    stickyClass: 'sticky-scrolled',
    activeClass: 'active',
    mobileBreakpoint: 768
  },

  // State
  state: {
    isInitialized: false,
    isMobileNavOpen: false,
    currentSection: null,
    scrollPosition: 0,
    isSticky: false,
    sections: [],
    navItems: []
  },

  /**
   * Initialize the enhanced navigation
   */
  init() {
    if (this.state.isInitialized) return;

    try {
      this.setupNavigation();
      this.setupMobileNavigation();
      this.setupStickyHeader();
      this.setupSmoothScrolling();
      this.setupSectionTracking();
      this.setupKeyboardNavigation();
      this.addNavigationStyles();
      
      this.state.isInitialized = true;
      console.log('Enhanced Navigation initialized! 🧭');
    } catch (error) {
      console.error('Failed to initialize enhanced navigation:', error);
    }
  },

  /**
   * Set up main navigation
   */
  setupNavigation() {
    const nav = document.querySelector(this.config.navSelector);
    if (!nav) return;

    // Get all navigation items
    this.state.navItems = Array.from(nav.querySelectorAll('a[href^="#"]'));
    
    // Add icons to navigation items
    this.addNavigationIcons();
    
    // Set up click handlers
    this.state.navItems.forEach(item => {
      item.addEventListener('click', (e) => {
        this.handleNavClick(e);
      });
    });

    // Set up hover effects
    this.setupHoverEffects();
  },

  /**
   * Add icons to navigation items
   */
  addNavigationIcons() {
    const iconMap = {
      'トップ': '🏠',
      '体験': '🎮',
      '講座': '📚',
      '進捗': '📊',
      '料金': '💰',
      'FAQ': '❓'
    };

    this.state.navItems.forEach(item => {
      const text = item.textContent.trim();
      const icon = iconMap[text];
      
      if (icon) {
        item.innerHTML = `
          <span class="nav-icon" aria-hidden="true">${icon}</span>
          <span class="nav-text">${text}</span>
        `;
      }
    });
  },

  /**
   * Set up hover effects
   */
  setupHoverEffects() {
    this.state.navItems.forEach(item => {
      item.addEventListener('mouseenter', () => {
        this.animateNavItem(item, 'enter');
      });
      
      item.addEventListener('mouseleave', () => {
        this.animateNavItem(item, 'leave');
      });
    });
  },

  /**
   * Animate navigation item
   */
  animateNavItem(item, type) {
    const icon = item.querySelector('.nav-icon');
    const text = item.querySelector('.nav-text');
    
    if (type === 'enter') {
      if (icon) icon.style.transform = 'scale(1.2) rotate(5deg)';
      if (text) text.style.transform = 'translateY(-2px)';
    } else {
      if (icon) icon.style.transform = 'scale(1) rotate(0deg)';
      if (text) text.style.transform = 'translateY(0)';
    }
  },

  /**
   * Set up mobile navigation
   */
  setupMobileNavigation() {
    this.createMobileNav();
    this.setupHamburgerMenu();
  },

  /**
   * Create mobile navigation
   */
  createMobileNav() {
    // Check if mobile nav already exists
    if (document.querySelector(this.config.mobileNavSelector)) return;

    const mobileNav = document.createElement('nav');
    mobileNav.className = 'mobile-nav';
    mobileNav.setAttribute('aria-label', 'モバイルナビゲーション');
    mobileNav.style.display = 'none';

    // Copy navigation items
    const mainNav = document.querySelector(this.config.navSelector);
    if (mainNav) {
      const navItems = mainNav.cloneNode(true);
      navItems.className = 'mobile-nav-list';
      mobileNav.appendChild(navItems);
    }

    // Add user info section for mobile
    const userSection = document.createElement('div');
    userSection.className = 'mobile-user-section';
    userSection.innerHTML = `
      <div class="mobile-user-info" style="display: none;">
        <div class="user-avatar">👤</div>
        <div class="user-details">
          <div class="user-name"></div>
          <div class="user-level"></div>
        </div>
      </div>
      <div class="mobile-auth-buttons">
        <button class="btn mobile-login-btn" id="mobile-login-btn">ログイン</button>
        <button class="btn secondary mobile-logout-btn" id="mobile-logout-btn" style="display: none;">ログアウト</button>
      </div>
    `;
    mobileNav.appendChild(userSection);

    document.body.appendChild(mobileNav);
  },

  /**
   * Set up hamburger menu
   */
  setupHamburgerMenu() {
    const hamburger = document.querySelector(this.config.hamburgerSelector + ' input');
    if (!hamburger) return;

    hamburger.addEventListener('change', (e) => {
      this.toggleMobileNav(e.target.checked);
    });

    // Close mobile nav when clicking on links
    const mobileNav = document.querySelector(this.config.mobileNavSelector);
    if (mobileNav) {
      mobileNav.addEventListener('click', (e) => {
        if (e.target.matches('a[href^="#"]')) {
          this.closeMobileNav();
        }
      });
    }
  },

  /**
   * Toggle mobile navigation
   */
  toggleMobileNav(open) {
    const mobileNav = document.querySelector(this.config.mobileNavSelector);
    const hamburger = document.querySelector(this.config.hamburgerSelector + ' input');
    
    if (!mobileNav) return;

    this.state.isMobileNavOpen = open;

    if (open) {
      mobileNav.style.display = 'block';
      requestAnimationFrame(() => {
        mobileNav.classList.add('open');
      });
      document.body.style.overflow = 'hidden';
    } else {
      mobileNav.classList.remove('open');
      setTimeout(() => {
        mobileNav.style.display = 'none';
        document.body.style.overflow = '';
      }, 300);
    }

    // Update hamburger state
    if (hamburger) {
      hamburger.checked = open;
    }
  },

  /**
   * Close mobile navigation
   */
  closeMobileNav() {
    this.toggleMobileNav(false);
  },

  /**
   * Set up sticky header
   */
  setupStickyHeader() {
    let ticking = false;

    const handleScroll = () => {
      this.state.scrollPosition = window.pageYOffset;
      
      const header = document.querySelector(this.config.headerSelector);
      if (!header) return;

      const shouldBeSticky = this.state.scrollPosition > this.config.scrollThreshold;
      
      if (shouldBeSticky !== this.state.isSticky) {
        this.state.isSticky = shouldBeSticky;
        
        if (shouldBeSticky) {
          header.classList.add(this.config.stickyClass);
          this.animateHeaderShrink();
        } else {
          header.classList.remove(this.config.stickyClass);
          this.animateHeaderExpand();
        }
      }
    };

    const scrollHandler = () => {
      if (!ticking) {
        requestAnimationFrame(() => {
          handleScroll();
          ticking = false;
        });
        ticking = true;
      }
    };

    window.addEventListener('scroll', scrollHandler, { passive: true });
  },

  /**
   * Animate header shrink
   */
  animateHeaderShrink() {
    const header = document.querySelector(this.config.headerSelector);
    const brand = header?.querySelector('.brand');
    const navItems = header?.querySelectorAll('.nav a');

    if (brand) {
      brand.style.fontSize = 'clamp(0.9rem, 2vw, 1rem)';
    }

    navItems?.forEach(item => {
      item.style.fontSize = 'clamp(0.8rem, 1.5vw, 0.85rem)';
      item.style.padding = '0.4rem 0.6rem';
    });
  },

  /**
   * Animate header expand
   */
  animateHeaderExpand() {
    const header = document.querySelector(this.config.headerSelector);
    const brand = header?.querySelector('.brand');
    const navItems = header?.querySelectorAll('.nav a');

    if (brand) {
      brand.style.fontSize = 'clamp(1rem, 2.5vw, 1.2rem)';
    }

    navItems?.forEach(item => {
      item.style.fontSize = 'clamp(0.85rem, 1.8vw, 0.95rem)';
      item.style.padding = '0.55rem 0.8rem';
    });
  },

  /**
   * Set up smooth scrolling
   */
  setupSmoothScrolling() {
    // Handle navigation clicks
    document.addEventListener('click', (e) => {
      const link = e.target.closest('a[href^="#"]');
      if (!link) return;

      e.preventDefault();
      const targetId = link.getAttribute('href');
      this.scrollToSection(targetId);
    });
  },

  /**
   * Scroll to section with offset
   */
  scrollToSection(targetId) {
    const target = document.querySelector(targetId);
    if (!target) return;

    const header = document.querySelector(this.config.headerSelector);
    const headerHeight = header ? header.offsetHeight : 0;
    const offset = headerHeight + 20; // Extra padding

    const targetPosition = target.offsetTop - offset;

    window.scrollTo({
      top: targetPosition,
      behavior: 'smooth'
    });

    // Update active state
    this.updateActiveNavItem(targetId);
  },

  /**
   * Set up section tracking
   */
  setupSectionTracking() {
    // Get all sections
    this.state.sections = Array.from(document.querySelectorAll('section[id]'));
    
    if (this.state.sections.length === 0) return;

    // Set up intersection observer
    const observerOptions = {
      threshold: [0.1, 0.5, 0.9],
      rootMargin: '-80px 0px -50% 0px'
    };

    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting && entry.intersectionRatio > 0.1) {
          this.updateActiveNavItem(`#${entry.target.id}`);
        }
      });
    }, observerOptions);

    this.state.sections.forEach(section => {
      observer.observe(section);
    });
  },

  /**
   * Update active navigation item
   */
  updateActiveNavItem(targetId) {
    // Remove active class from all items
    this.state.navItems.forEach(item => {
      item.classList.remove(this.config.activeClass);
      item.removeAttribute('aria-current');
    });

    // Add active class to current item
    const activeItem = this.state.navItems.find(item => 
      item.getAttribute('href') === targetId
    );

    if (activeItem) {
      activeItem.classList.add(this.config.activeClass);
      activeItem.setAttribute('aria-current', 'page');
      this.state.currentSection = targetId;
    }
  },

  /**
   * Set up keyboard navigation
   */
  setupKeyboardNavigation() {
    document.addEventListener('keydown', (e) => {
      // Escape key closes mobile nav
      if (e.key === 'Escape' && this.state.isMobileNavOpen) {
        this.closeMobileNav();
      }

      // Arrow keys for navigation (when focused on nav)
      if (e.target.closest(this.config.navSelector)) {
        this.handleKeyboardNavigation(e);
      }
    });
  },

  /**
   * Handle keyboard navigation
   */
  handleKeyboardNavigation(e) {
    const currentIndex = this.state.navItems.indexOf(e.target);
    if (currentIndex === -1) return;

    let nextIndex;
    
    switch (e.key) {
      case 'ArrowLeft':
      case 'ArrowUp':
        e.preventDefault();
        nextIndex = currentIndex > 0 ? currentIndex - 1 : this.state.navItems.length - 1;
        break;
        
      case 'ArrowRight':
      case 'ArrowDown':
        e.preventDefault();
        nextIndex = currentIndex < this.state.navItems.length - 1 ? currentIndex + 1 : 0;
        break;
        
      case 'Home':
        e.preventDefault();
        nextIndex = 0;
        break;
        
      case 'End':
        e.preventDefault();
        nextIndex = this.state.navItems.length - 1;
        break;
        
      default:
        return;
    }

    this.state.navItems[nextIndex].focus();
  },

  /**
   * Handle navigation click
   */
  handleNavClick(e) {
    const link = e.target.closest('a');
    const href = link.getAttribute('href');
    
    // Close mobile nav if open
    if (this.state.isMobileNavOpen) {
      this.closeMobileNav();
    }

    // Let the smooth scrolling handler take care of the rest
  },

  /**
   * Add navigation styles
   */
  addNavigationStyles() {
    const style = document.createElement('style');
    style.textContent = `
      /* Enhanced Navigation Styles */
      .nav a {
        display: flex;
        align-items: center;
        gap: 0.5rem;
        transition: all var(--duration-normal, 0.3s) var(--ease-out, ease);
        position: relative;
      }

      .nav-icon {
        font-size: 1.1em;
        transition: transform var(--duration-normal, 0.3s) var(--ease-brutal, cubic-bezier(0.68, -0.55, 0.265, 1.55));
      }

      .nav-text {
        transition: transform var(--duration-normal, 0.3s) var(--ease-out, ease);
      }

      .nav a.active {
        background: var(--color-accent, #ff0000);
        color: var(--color-bg, #fcf8e8);
        border-radius: var(--radius, 12px);
        box-shadow: 2px 2px 0px var(--color-fg, #1a1a1a);
        transform: translateY(-2px);
      }

      .nav a:focus-visible {
        outline: 2px solid var(--color-accent, #ff0000);
        outline-offset: 2px;
      }

      /* Sticky Header Styles */
      header.sticky-scrolled {
        background: var(--color-primary, #ffcc00);
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        transition: all var(--duration-normal, 0.3s) var(--ease-out, ease);
      }

      header.sticky-scrolled .bar {
        padding: 8px 20px;
      }

      /* Mobile Navigation Styles */
      .mobile-nav {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: var(--color-bg, #fcf8e8);
        z-index: 999;
        transform: translateX(-100%);
        transition: transform var(--duration-normal, 0.3s) var(--ease-out, ease);
        overflow-y: auto;
        border-right: 4px solid var(--color-fg, #1a1a1a);
      }

      .mobile-nav.open {
        transform: translateX(0);
      }

      .mobile-nav-list {
        display: flex;
        flex-direction: column;
        gap: 0;
        list-style: none;
        margin: 0;
        padding: 80px 20px 20px;
      }

      .mobile-nav-list a {
        display: flex;
        align-items: center;
        gap: 1rem;
        padding: 1rem;
        border-bottom: 2px solid var(--color-fg, #1a1a1a);
        text-decoration: none;
        color: var(--color-fg, #1a1a1a);
        font-size: 1.2rem;
        font-weight: 700;
        transition: all var(--duration-normal, 0.3s) var(--ease-out, ease);
      }

      .mobile-nav-list a:hover,
      .mobile-nav-list a:focus {
        background: var(--color-primary, #ffcc00);
        transform: translateX(10px);
      }

      .mobile-nav-list a.active {
        background: var(--color-accent, #ff0000);
        color: var(--color-bg, #fcf8e8);
      }

      .mobile-user-section {
        padding: 20px;
        border-top: 3px solid var(--color-fg, #1a1a1a);
        margin-top: auto;
      }

      .mobile-user-info {
        display: flex;
        align-items: center;
        gap: 1rem;
        padding: 1rem;
        background: var(--color-glass-bg, rgba(255, 255, 255, 0.8));
        border: 2px solid var(--color-fg, #1a1a1a);
        border-radius: 12px;
        margin-bottom: 1rem;
      }

      .user-avatar {
        width: 48px;
        height: 48px;
        background: var(--color-primary, #ffcc00);
        border: 2px solid var(--color-fg, #1a1a1a);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.5rem;
      }

      .user-details {
        flex: 1;
      }

      .user-name {
        font-weight: 700;
        font-size: 1.1rem;
        color: var(--color-fg, #1a1a1a);
      }

      .user-level {
        font-size: 0.9rem;
        color: var(--color-muted, #555555);
      }

      .mobile-auth-buttons {
        display: flex;
        flex-direction: column;
        gap: 0.5rem;
      }

      .mobile-auth-buttons .btn {
        width: 100%;
        padding: 1rem;
        font-size: 1.1rem;
      }

      /* Hamburger Menu Enhancements */
      .hamburger-menu {
        display: none;
      }

      @media (max-width: 768px) {
        .nav {
          display: none;
        }

        .hamburger-menu {
          display: block;
        }

        .mobile-nav {
          display: block;
        }
      }

      /* Dark Theme Adjustments */
      html[data-theme="dark"] .mobile-nav {
        background: var(--color-bg, #1a1a1a);
        border-right-color: var(--color-primary, #ffcc00);
      }

      html[data-theme="dark"] .mobile-nav-list a {
        color: var(--color-fg, #fcf8e8);
        border-bottom-color: var(--color-primary, #ffcc00);
      }

      html[data-theme="dark"] .mobile-nav-list a:hover,
      html[data-theme="dark"] .mobile-nav-list a:focus {
        background: var(--color-primary, #ffcc00);
        color: var(--color-bg, #1a1a1a);
      }

      html[data-theme="dark"] .mobile-user-section {
        border-top-color: var(--color-primary, #ffcc00);
      }

      html[data-theme="dark"] .mobile-user-info {
        background: var(--color-glass-bg, rgba(0, 0, 0, 0.8));
        border-color: var(--color-primary, #ffcc00);
      }

      html[data-theme="dark"] .user-avatar {
        border-color: var(--color-primary, #ffcc00);
      }

      /* Reduced Motion Support */
      @media (prefers-reduced-motion: reduce) {
        .nav a,
        .nav-icon,
        .nav-text,
        .mobile-nav,
        .mobile-nav-list a {
          transition: none;
        }
      }
    `;
    document.head.appendChild(style);
  },

  /**
   * Update mobile navigation user info
   */
  updateMobileUserInfo(user) {
    const userInfo = document.querySelector('.mobile-user-info');
    const userName = document.querySelector('.mobile-user-info .user-name');
    const userLevel = document.querySelector('.mobile-user-info .user-level');
    const loginBtn = document.querySelector('#mobile-login-btn');
    const logoutBtn = document.querySelector('#mobile-logout-btn');

    if (user) {
      if (userInfo) userInfo.style.display = 'flex';
      if (userName) userName.textContent = user.name;
      if (userLevel) userLevel.textContent = `レベル ${user.level}`;
      if (loginBtn) loginBtn.style.display = 'none';
      if (logoutBtn) logoutBtn.style.display = 'block';
    } else {
      if (userInfo) userInfo.style.display = 'none';
      if (loginBtn) loginBtn.style.display = 'block';
      if (logoutBtn) logoutBtn.style.display = 'none';
    }
  },

  /**
   * Get debug information
   */
  getDebugInfo() {
    return {
      isInitialized: this.state.isInitialized,
      isMobileNavOpen: this.state.isMobileNavOpen,
      currentSection: this.state.currentSection,
      scrollPosition: this.state.scrollPosition,
      isSticky: this.state.isSticky,
      sectionsCount: this.state.sections.length,
      navItemsCount: this.state.navItems.length
    };
  }
};

// Auto-initialize when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    NavigationEnhanced.init();
  });
} else {
  NavigationEnhanced.init();
}

// Listen for user service events to update mobile nav
if (typeof window !== 'undefined') {
  window.NavigationEnhanced = NavigationEnhanced;
  
  // Update mobile nav when user logs in/out
  document.addEventListener('progen-user-logged-in', (e) => {
    NavigationEnhanced.updateMobileUserInfo(e.detail.user);
  });
  
  document.addEventListener('progen-user-logged-out', () => {
    NavigationEnhanced.updateMobileUserInfo(null);
  });
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = NavigationEnhanced;
}


/**
 * PROGEN UI Components
 * Reusable Neo-Brutalism styled components
 */

'use strict';

const UIComponents = {
  // Configuration
  config: {
    animationDuration: 300,
    debounceDelay: 150
  },

  // State
  state: {
    isInitialized: false,
    activeModals: [],
    activeTooltips: []
  },

  /**
   * Initialize UI components
   */
  init() {
    if (this.state.isInitialized) return;

    try {
      this.addComponentStyles();
      this.setupEventListeners();
      this.initializeComponents();
      
      this.state.isInitialized = true;
      console.log('UI Components initialized! 🎨');
    } catch (error) {
      console.error('Failed to initialize UI components:', error);
    }
  },

  /**
   * Add component styles
   */
  addComponentStyles() {
    const style = document.createElement('style');
    style.textContent = `
      /* Button Components */
      .btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 0.5rem;
        padding: 0.75rem 1.5rem;
        font-family: var(--font-sans, 'Noto Sans JP', sans-serif);
        font-size: 0.95rem;
        font-weight: 700;
        text-decoration: none;
        border: var(--outline, 3px solid var(--color-fg, #1a1a1a));
        border-radius: var(--radius, 12px);
        background: var(--color-primary, #ffcc00);
        color: var(--color-fg, #1a1a1a);
        box-shadow: var(--shadow, 4px 4px 0px var(--color-fg, #1a1a1a));
        cursor: pointer;
        transition: all var(--duration-fast, 0.15s) var(--ease-out, ease);
        position: relative;
        overflow: hidden;
        user-select: none;
        white-space: nowrap;
      }

      .btn:hover {
        transform: translate(-2px, -2px);
        box-shadow: 6px 6px 0px var(--color-fg, #1a1a1a);
      }

      .btn:active {
        transform: translate(2px, 2px);
        box-shadow: 2px 2px 0px var(--color-fg, #1a1a1a);
      }

      .btn:focus-visible {
        outline: 2px solid var(--color-accent, #ff0000);
        outline-offset: 2px;
      }

      .btn:disabled {
        opacity: 0.6;
        cursor: not-allowed;
        transform: none;
        box-shadow: var(--shadow, 4px 4px 0px var(--color-fg, #1a1a1a));
      }

      .btn:disabled:hover {
        transform: none;
        box-shadow: var(--shadow, 4px 4px 0px var(--color-fg, #1a1a1a));
      }

      /* Button Variants */
      .btn.secondary {
        background: var(--color-bg, #fcf8e8);
        color: var(--color-fg, #1a1a1a);
      }

      .btn.accent {
        background: var(--color-accent, #ff0000);
        color: var(--color-bg, #fcf8e8);
      }

      .btn.success {
        background: var(--color-success, #28a745);
        color: white;
      }

      .btn.warning {
        background: var(--color-warning, #ffc107);
        color: var(--color-fg, #1a1a1a);
      }

      .btn.error {
        background: var(--color-error, #dc3545);
        color: white;
      }

      .btn.ghost {
        background: transparent;
        color: var(--color-fg, #1a1a1a);
        box-shadow: none;
        border: 2px solid var(--color-fg, #1a1a1a);
      }

      .btn.ghost:hover {
        background: var(--color-fg, #1a1a1a);
        color: var(--color-bg, #fcf8e8);
        transform: translate(-1px, -1px);
        box-shadow: 2px 2px 0px var(--color-fg, #1a1a1a);
      }

      /* Button Sizes */
      .btn.small {
        padding: 0.5rem 1rem;
        font-size: 0.85rem;
      }

      .btn.large {
        padding: 1rem 2rem;
        font-size: 1.1rem;
      }

      /* Input Components */
      .input {
        display: block;
        width: 100%;
        padding: 0.75rem 1rem;
        font-family: var(--font-sans, 'Noto Sans JP', sans-serif);
        font-size: 1rem;
        border: var(--outline, 3px solid var(--color-fg, #1a1a1a));
        border-radius: var(--radius, 12px);
        background: var(--color-bg, #fcf8e8);
        color: var(--color-fg, #1a1a1a);
        box-shadow: inset 2px 2px 0px var(--color-muted, #555555);
        transition: all var(--duration-fast, 0.15s) var(--ease-out, ease);
      }

      .input:focus {
        outline: 2px solid var(--color-accent, #ff0000);
        outline-offset: 2px;
        box-shadow: inset 2px 2px 0px var(--color-accent, #ff0000);
      }

      .input::placeholder {
        color: var(--color-muted, #555555);
      }

      .input:invalid {
        border-color: var(--color-error, #dc3545);
        box-shadow: inset 2px 2px 0px var(--color-error, #dc3545);
      }

      /* Card Components */
      .card {
        background: var(--color-bg, #fcf8e8);
        border: var(--outline, 3px solid var(--color-fg, #1a1a1a));
        border-radius: var(--radius, 12px);
        box-shadow: var(--shadow, 4px 4px 0px var(--color-fg, #1a1a1a));
        padding: 1.5rem;
        transition: all var(--duration-normal, 0.3s) var(--ease-out, ease);
      }

      .card:hover {
        transform: translate(-2px, -2px);
        box-shadow: 6px 6px 0px var(--color-fg, #1a1a1a);
      }

      .card.interactive {
        cursor: pointer;
      }

      .card.interactive:active {
        transform: translate(1px, 1px);
        box-shadow: 3px 3px 0px var(--color-fg, #1a1a1a);
      }

      /* Glass Card Variant */
      .glass-card {
        background: var(--color-glass-bg, rgba(252, 248, 232, 0.9));
        backdrop-filter: blur(10px);
        border: var(--outline, 3px solid var(--color-fg, #1a1a1a));
        border-radius: var(--radius, 12px);
        box-shadow: var(--shadow, 4px 4px 0px var(--color-fg, #1a1a1a));
        padding: 1.5rem;
        transition: all var(--duration-normal, 0.3s) var(--ease-out, ease);
      }

      .glass-card:hover {
        transform: translate(-2px, -2px);
        box-shadow: 6px 6px 0px var(--color-fg, #1a1a1a);
      }

      /* Badge Components */
      .badge {
        display: inline-flex;
        align-items: center;
        gap: 0.25rem;
        padding: 0.25rem 0.75rem;
        font-size: 0.8rem;
        font-weight: 700;
        border: 2px solid var(--color-fg, #1a1a1a);
        border-radius: 20px;
        background: var(--color-primary, #ffcc00);
        color: var(--color-fg, #1a1a1a);
        white-space: nowrap;
      }

      .badge.success {
        background: var(--color-success, #28a745);
        color: white;
      }

      .badge.warning {
        background: var(--color-warning, #ffc107);
        color: var(--color-fg, #1a1a1a);
      }

      .badge.error {
        background: var(--color-error, #dc3545);
        color: white;
      }

      .badge.info {
        background: var(--color-info, #007bff);
        color: white;
      }

      .badge.secondary {
        background: var(--color-muted, #555555);
        color: white;
      }

      /* Progress Components */
      .progress {
        width: 100%;
        height: 12px;
        background: var(--color-muted, #555555);
        border: 2px solid var(--color-fg, #1a1a1a);
        border-radius: 8px;
        overflow: hidden;
        position: relative;
      }

      .progress-bar {
        height: 100%;
        background: var(--color-primary, #ffcc00);
        transition: width var(--duration-normal, 0.3s) var(--ease-out, ease);
        position: relative;
      }

      .progress-bar.success {
        background: var(--color-success, #28a745);
      }

      .progress-bar.warning {
        background: var(--color-warning, #ffc107);
      }

      .progress-bar.error {
        background: var(--color-error, #dc3545);
      }

      /* Tooltip Components */
      .tooltip {
        position: relative;
        display: inline-block;
      }

      .tooltip-content {
        position: absolute;
        bottom: 125%;
        left: 50%;
        transform: translateX(-50%);
        background: var(--color-fg, #1a1a1a);
        color: var(--color-bg, #fcf8e8);
        padding: 0.5rem 0.75rem;
        border-radius: 8px;
        font-size: 0.8rem;
        white-space: nowrap;
        opacity: 0;
        visibility: hidden;
        transition: all var(--duration-fast, 0.15s) var(--ease-out, ease);
        z-index: 1000;
        pointer-events: none;
      }

      .tooltip-content::after {
        content: '';
        position: absolute;
        top: 100%;
        left: 50%;
        transform: translateX(-50%);
        border: 5px solid transparent;
        border-top-color: var(--color-fg, #1a1a1a);
      }

      .tooltip:hover .tooltip-content,
      .tooltip:focus .tooltip-content {
        opacity: 1;
        visibility: visible;
      }

      /* Modal Components */
      .modal-overlay {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0, 0, 0, 0.5);
        backdrop-filter: blur(5px);
        z-index: 1000;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 1rem;
        opacity: 0;
        visibility: hidden;
        transition: all var(--duration-normal, 0.3s) var(--ease-out, ease);
      }

      .modal-overlay.show {
        opacity: 1;
        visibility: visible;
      }

      .modal {
        background: var(--color-bg, #fcf8e8);
        border: var(--outline, 3px solid var(--color-fg, #1a1a1a));
        border-radius: var(--radius, 12px);
        box-shadow: var(--shadow-large, 8px 8px 0px var(--color-fg, #1a1a1a));
        max-width: 500px;
        width: 100%;
        max-height: 90vh;
        overflow-y: auto;
        transform: scale(0.9) translateY(20px);
        transition: transform var(--duration-normal, 0.3s) var(--ease-brutal, cubic-bezier(0.68, -0.55, 0.265, 1.55));
      }

      .modal-overlay.show .modal {
        transform: scale(1) translateY(0);
      }

      .modal-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 1.5rem 1.5rem 0;
        border-bottom: 2px solid var(--color-fg, #1a1a1a);
        margin-bottom: 1.5rem;
      }

      .modal-title {
        margin: 0;
        font-size: 1.5rem;
        font-weight: 900;
        color: var(--color-fg, #1a1a1a);
      }

      .modal-close {
        background: none;
        border: none;
        font-size: 1.5rem;
        font-weight: bold;
        cursor: pointer;
        color: var(--color-fg, #1a1a1a);
        padding: 0;
        width: 32px;
        height: 32px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 50%;
        transition: all var(--duration-fast, 0.15s) var(--ease-out, ease);
      }

      .modal-close:hover {
        background: var(--color-accent, #ff0000);
        color: white;
      }

      .modal-close:focus-visible {
        outline: 2px solid var(--color-accent, #ff0000);
        outline-offset: 2px;
      }

      .modal-body {
        padding: 0 1.5rem 1.5rem;
      }

      /* Alert Components */
      .alert {
        padding: 1rem 1.5rem;
        border: var(--outline, 3px solid var(--color-fg, #1a1a1a));
        border-radius: var(--radius, 12px);
        margin-bottom: 1rem;
        display: flex;
        align-items: flex-start;
        gap: 0.75rem;
      }

      .alert.success {
        background: var(--color-success, #28a745);
        color: white;
      }

      .alert.warning {
        background: var(--color-warning, #ffc107);
        color: var(--color-fg, #1a1a1a);
      }

      .alert.error {
        background: var(--color-error, #dc3545);
        color: white;
      }

      .alert.info {
        background: var(--color-info, #007bff);
        color: white;
      }

      .alert-icon {
        font-size: 1.2rem;
        flex-shrink: 0;
        margin-top: 0.1rem;
      }

      .alert-content {
        flex: 1;
      }

      .alert-title {
        font-weight: 700;
        margin: 0 0 0.5rem;
      }

      .alert-message {
        margin: 0;
        line-height: 1.5;
      }

      /* Loading Components */
      .spinner {
        width: 24px;
        height: 24px;
        border: 3px solid var(--color-muted, #555555);
        border-top: 3px solid var(--color-primary, #ffcc00);
        border-radius: 50%;
        animation: spin 1s linear infinite;
      }

      @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
      }

      .loading-overlay {
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(252, 248, 232, 0.9);
        display: flex;
        align-items: center;
        justify-content: center;
        flex-direction: column;
        gap: 1rem;
        z-index: 10;
      }

      .loading-text {
        font-weight: 600;
        color: var(--color-fg, #1a1a1a);
      }

      /* Dark Theme Adjustments */
      html[data-theme="dark"] .btn {
        background: var(--color-primary, #ffcc00);
        color: var(--color-bg, #1a1a1a);
        border-color: var(--color-primary, #ffcc00);
        box-shadow: 4px 4px 0px var(--color-primary, #ffcc00);
      }

      html[data-theme="dark"] .btn:hover {
        box-shadow: 6px 6px 0px var(--color-primary, #ffcc00);
      }

      html[data-theme="dark"] .btn:active {
        box-shadow: 2px 2px 0px var(--color-primary, #ffcc00);
      }

      html[data-theme="dark"] .btn.secondary {
        background: var(--color-bg, #1a1a1a);
        color: var(--color-fg, #fcf8e8);
        border-color: var(--color-primary, #ffcc00);
        box-shadow: 4px 4px 0px var(--color-primary, #ffcc00);
      }

      html[data-theme="dark"] .input {
        background: var(--color-bg, #1a1a1a);
        color: var(--color-fg, #fcf8e8);
        border-color: var(--color-primary, #ffcc00);
        box-shadow: inset 2px 2px 0px var(--color-primary, #ffcc00);
      }

      html[data-theme="dark"] .card,
      html[data-theme="dark"] .glass-card {
        background: var(--color-glass-bg, rgba(26, 26, 26, 0.9));
        border-color: var(--color-primary, #ffcc00);
        box-shadow: 4px 4px 0px var(--color-primary, #ffcc00);
      }

      html[data-theme="dark"] .card:hover,
      html[data-theme="dark"] .glass-card:hover {
        box-shadow: 6px 6px 0px var(--color-primary, #ffcc00);
      }

      html[data-theme="dark"] .modal {
        background: var(--color-bg, #1a1a1a);
        border-color: var(--color-primary, #ffcc00);
        box-shadow: 8px 8px 0px var(--color-primary, #ffcc00);
      }

      html[data-theme="dark"] .modal-header {
        border-color: var(--color-primary, #ffcc00);
      }

      /* Responsive Design */
      @media (max-width: 768px) {
        .btn {
          padding: 0.6rem 1.2rem;
          font-size: 0.9rem;
        }

        .btn.large {
          padding: 0.8rem 1.6rem;
          font-size: 1rem;
        }

        .modal {
          margin: 1rem;
          max-width: calc(100% - 2rem);
        }

        .modal-header,
        .modal-body {
          padding-left: 1rem;
          padding-right: 1rem;
        }
      }

      /* Reduced Motion Support */
      @media (prefers-reduced-motion: reduce) {
        .btn,
        .card,
        .glass-card,
        .modal,
        .modal-overlay,
        .tooltip-content,
        .progress-bar,
        .spinner {
          transition: none;
          animation: none;
        }
      }

      /* High Contrast Support */
      @media (prefers-contrast: high) {
        .btn,
        .input,
        .card,
        .glass-card,
        .badge,
        .progress,
        .modal {
          border-width: 4px;
        }
      }
    `;
    document.head.appendChild(style);
  },

  /**
   * Set up event listeners
   */
  setupEventListeners() {
    // Modal close on overlay click
    document.addEventListener('click', (e) => {
      if (e.target.classList.contains('modal-overlay')) {
        this.closeModal(e.target);
      }
    });

    // Modal close on escape key
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && this.state.activeModals.length > 0) {
        const topModal = this.state.activeModals[this.state.activeModals.length - 1];
        this.closeModal(topModal);
      }
    });

    // Close button clicks
    document.addEventListener('click', (e) => {
      if (e.target.classList.contains('modal-close')) {
        const modal = e.target.closest('.modal-overlay');
        if (modal) this.closeModal(modal);
      }
    });
  },

  /**
   * Initialize existing components
   */
  initializeComponents() {
    // Initialize tooltips
    this.initTooltips();
    
    // Initialize progress bars
    this.initProgressBars();
    
    // Initialize interactive cards
    this.initInteractiveCards();
  },

  /**
   * Initialize tooltips
   */
  initTooltips() {
    const tooltips = document.querySelectorAll('[data-tooltip]');
    tooltips.forEach(element => {
      this.createTooltip(element, element.dataset.tooltip);
    });
  },

  /**
   * Create tooltip
   */
  createTooltip(element, text) {
    if (element.querySelector('.tooltip-content')) return;

    element.classList.add('tooltip');
    
    const tooltipContent = document.createElement('div');
    tooltipContent.className = 'tooltip-content';
    tooltipContent.textContent = text;
    tooltipContent.setAttribute('role', 'tooltip');
    
    element.appendChild(tooltipContent);
  },

  /**
   * Initialize progress bars
   */
  initProgressBars() {
    const progressBars = document.querySelectorAll('.progress-bar[data-progress]');
    progressBars.forEach(bar => {
      const progress = parseInt(bar.dataset.progress, 10);
      setTimeout(() => {
        bar.style.width = `${Math.min(100, Math.max(0, progress))}%`;
      }, 100);
    });
  },

  /**
   * Initialize interactive cards
   */
  initInteractiveCards() {
    const cards = document.querySelectorAll('.card[data-action], .glass-card[data-action]');
    cards.forEach(card => {
      card.classList.add('interactive');
      card.setAttribute('tabindex', '0');
      card.setAttribute('role', 'button');
      
      const handleAction = () => {
        const action = card.dataset.action;
        this.handleCardAction(action, card);
      };
      
      card.addEventListener('click', handleAction);
      card.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          handleAction();
        }
      });
    });
  },

  /**
   * Handle card action
   */
  handleCardAction(action, card) {
    switch (action) {
      case 'modal':
        const modalId = card.dataset.modal;
        if (modalId) this.openModal(modalId);
        break;
        
      case 'navigate':
        const url = card.dataset.url;
        if (url) window.location.href = url;
        break;
        
      case 'toggle':
        card.classList.toggle('active');
        break;
        
      default:
        // Dispatch custom event
        this.dispatchComponentEvent('card-action', {
          action,
          card,
          data: card.dataset
        });
    }
  },

  /**
   * Create modal
   */
  createModal(id, options = {}) {
    const {
      title = 'Modal',
      content = '',
      size = 'medium',
      closable = true
    } = options;

    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay';
    overlay.id = id;
    overlay.setAttribute('role', 'dialog');
    overlay.setAttribute('aria-modal', 'true');
    overlay.setAttribute('aria-labelledby', `${id}-title`);

    overlay.innerHTML = `
      <div class="modal ${size}">
        <div class="modal-header">
          <h2 class="modal-title" id="${id}-title">${title}</h2>
          ${closable ? '<button class="modal-close" aria-label="閉じる">&times;</button>' : ''}
        </div>
        <div class="modal-body">
          ${content}
        </div>
      </div>
    `;

    document.body.appendChild(overlay);
    return overlay;
  },

  /**
   * Open modal
   */
  openModal(id) {
    const modal = document.getElementById(id);
    if (!modal) return;

    modal.style.display = 'flex';
    requestAnimationFrame(() => {
      modal.classList.add('show');
    });

    // Add to active modals
    this.state.activeModals.push(modal);

    // Focus management
    const firstFocusable = modal.querySelector('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])');
    if (firstFocusable) {
      setTimeout(() => firstFocusable.focus(), 100);
    }

    // Prevent body scroll
    document.body.style.overflow = 'hidden';

    this.dispatchComponentEvent('modal-opened', { modal, id });
  },

  /**
   * Close modal
   */
  closeModal(modal) {
    if (!modal) return;

    modal.classList.remove('show');
    
    setTimeout(() => {
      modal.style.display = 'none';
      
      // Remove from active modals
      const index = this.state.activeModals.indexOf(modal);
      if (index > -1) {
        this.state.activeModals.splice(index, 1);
      }
      
      // Restore body scroll if no modals are open
      if (this.state.activeModals.length === 0) {
        document.body.style.overflow = '';
      }
    }, this.config.animationDuration);

    this.dispatchComponentEvent('modal-closed', { modal });
  },

  /**
   * Create alert
   */
  createAlert(type, title, message, options = {}) {
    const {
      dismissible = true,
      duration = 0,
      container = document.body
    } = options;

    const alert = document.createElement('div');
    alert.className = `alert ${type}`;
    alert.setAttribute('role', 'alert');

    const icons = {
      success: '✅',
      warning: '⚠️',
      error: '❌',
      info: 'ℹ️'
    };

    alert.innerHTML = `
      <div class="alert-icon">${icons[type] || 'ℹ️'}</div>
      <div class="alert-content">
        ${title ? `<div class="alert-title">${title}</div>` : ''}
        <div class="alert-message">${message}</div>
      </div>
      ${dismissible ? '<button class="modal-close" aria-label="閉じる">&times;</button>' : ''}
    `;

    // Add dismiss functionality
    if (dismissible) {
      const closeBtn = alert.querySelector('.modal-close');
      closeBtn.addEventListener('click', () => {
        this.removeAlert(alert);
      });
    }

    // Auto-dismiss
    if (duration > 0) {
      setTimeout(() => {
        this.removeAlert(alert);
      }, duration);
    }

    container.appendChild(alert);
    return alert;
  },

  /**
   * Remove alert
   */
  removeAlert(alert) {
    alert.style.opacity = '0';
    alert.style.transform = 'translateX(100%)';
    
    setTimeout(() => {
      if (alert.parentNode) {
        alert.parentNode.removeChild(alert);
      }
    }, this.config.animationDuration);
  },

  /**
   * Create loading overlay
   */
  createLoadingOverlay(container, text = '読み込み中...') {
    const overlay = document.createElement('div');
    overlay.className = 'loading-overlay';
    overlay.innerHTML = `
      <div class="spinner"></div>
      <div class="loading-text">${text}</div>
    `;

    container.style.position = 'relative';
    container.appendChild(overlay);
    return overlay;
  },

  /**
   * Remove loading overlay
   */
  removeLoadingOverlay(overlay) {
    if (overlay && overlay.parentNode) {
      overlay.style.opacity = '0';
      setTimeout(() => {
        if (overlay.parentNode) {
          overlay.parentNode.removeChild(overlay);
        }
      }, this.config.animationDuration);
    }
  },

  /**
   * Update progress bar
   */
  updateProgressBar(progressBar, value, animated = true) {
    const clampedValue = Math.min(100, Math.max(0, value));
    
    if (animated) {
      progressBar.style.transition = `width ${this.config.animationDuration}ms ease`;
    } else {
      progressBar.style.transition = 'none';
    }
    
    progressBar.style.width = `${clampedValue}%`;
    progressBar.setAttribute('aria-valuenow', clampedValue);
  },

  /**
   * Dispatch component event
   */
  dispatchComponentEvent(eventType, detail) {
    const event = new CustomEvent(`progen-ui-${eventType}`, {
      detail,
      bubbles: true
    });
    document.dispatchEvent(event);
  },

  /**
   * Add event listener for component events
   */
  addEventListener(eventType, callback) {
    document.addEventListener(`progen-ui-${eventType}`, callback);
  },

  /**
   * Remove event listener for component events
   */
  removeEventListener(eventType, callback) {
    document.removeEventListener(`progen-ui-${eventType}`, callback);
  },

  /**
   * Get debug information
   */
  getDebugInfo() {
    return {
      isInitialized: this.state.isInitialized,
      activeModals: this.state.activeModals.length,
      activeTooltips: this.state.activeTooltips.length,
      config: this.config
    };
  }
};

// Auto-initialize when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    UIComponents.init();
  });
} else {
  UIComponents.init();
}

// Export for use in other modules
if (typeof window !== 'undefined') {
  window.UIComponents = UIComponents;
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = UIComponents;
}


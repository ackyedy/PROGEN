/**
 * PROGEN Authentication Library
 * 
 * Enhanced authentication system with improved security and session management
 * Supports staged authentication implementation plan
 */

const ProgenAuth = {
  // Storage keys with versioning for future compatibility
  STORAGE_KEYS: {
    USER: 'progen_user_v2',
    TOKEN: 'progen_token_v2',
    THEME: 'progen_theme_v2',
    SESSION: 'progen_session_v2',
    REFRESH_TOKEN: 'progen_refresh_v2'
  },

  // Authentication configuration
  CONFIG: {
    SESSION_TIMEOUT: 24 * 60 * 60 * 1000, // 24 hours
    REFRESH_THRESHOLD: 2 * 60 * 60 * 1000, // 2 hours before expiry
    MAX_LOGIN_ATTEMPTS: 5,
    LOCKOUT_DURATION: 15 * 60 * 1000, // 15 minutes
    TOKEN_PREFIX: 'progen_',
    API_VERSION: 'v1'
  },

  // Valid credentials for demo (Phase 1: Test accounts)
  VALID_CREDENTIALS: [
    { 
      id: 'demo_001',
      email: 'demo@progen.com', 
      password: 'demo123',
      name: 'デモユーザー',
      level: 3,
      xp: 75,
      nextLevelXp: 100,
      completedLessons: 12,
      streak: 7,
      badges: 5,
      avatar: null,
      role: 'student',
      preferences: {
        theme: 'light',
        notifications: true,
        language: 'ja'
      }
    },
    { 
      id: 'test_001',
      email: 'test@example.com', 
      password: 'password123',
      name: 'テストユーザー',
      level: 5,
      xp: 120,
      nextLevelXp: 150,
      completedLessons: 25,
      streak: 14,
      badges: 8,
      avatar: null,
      role: 'student',
      preferences: {
        theme: 'dark',
        notifications: true,
        language: 'ja'
      }
    },
    { 
      id: 'user_001',
      email: 'user@progen.jp', 
      password: 'progen2025',
      name: '学習者',
      level: 2,
      xp: 45,
      nextLevelXp: 75,
      completedLessons: 8,
      streak: 3,
      badges: 2,
      avatar: null,
      role: 'student',
      preferences: {
        theme: 'light',
        notifications: false,
        language: 'ja'
      }
    },
    { 
      id: 'student_001',
      email: 'student@learning.com', 
      password: 'study123',
      name: '生徒',
      level: 4,
      xp: 95,
      nextLevelXp: 125,
      completedLessons: 18,
      streak: 10,
      badges: 6,
      avatar: null,
      role: 'student',
      preferences: {
        theme: 'light',
        notifications: true,
        language: 'ja'
      }
    }
  ],

  // Login attempt tracking
  loginAttempts: new Map(),

  /**
   * Initialize authentication system
   */
  init() {
    try {
      // Clean up old storage versions
      this.cleanupOldStorage();
      
      // Check for expired sessions
      this.checkSessionExpiry();
      
      // Initialize theme from user preferences
      this.initializeTheme();
      
      console.log('ProgenAuth initialized successfully');
    } catch (error) {
      console.error('Failed to initialize ProgenAuth:', error);
    }
  },

  /**
   * Clean up old storage versions
   */
  cleanupOldStorage() {
    const oldKeys = [
      'progen_user', 'progen_token', 'progen_theme', 'progen_session'
    ];
    
    oldKeys.forEach(key => {
      if (localStorage.getItem(key)) {
        localStorage.removeItem(key);
      }
    });
  },

  /**
   * Initialize theme from user preferences
   */
  initializeTheme() {
    if (window.ProgenThemeManager) {
      const user = this.getCurrentUser();
      const savedTheme = user?.preferences?.theme || 
                        localStorage.getItem(this.STORAGE_KEYS.THEME) || 
                        'light';
      
      ProgenThemeManager.setTheme(savedTheme);
    }
  },

  /**
   * Check if user is logged in with enhanced validation
   */
  isLoggedIn() {
    try {
      const user = this.getStorageItem(this.STORAGE_KEYS.USER);
      const token = this.getStorageItem(this.STORAGE_KEYS.TOKEN);
      const session = this.getStorageItem(this.STORAGE_KEYS.SESSION);
      
      if (!user || !token || !session) {
        return false;
      }

      // Validate token format
      if (!this.validateToken(token)) {
        this.logout();
        return false;
      }

      // Check session expiry
      const now = Date.now();
      if (now > session.expiresAt) {
        this.logout();
        return false;
      }

      // Check if session needs refresh
      if (now > session.expiresAt - this.CONFIG.REFRESH_THRESHOLD) {
        this.refreshSession();
      }

      return true;
    } catch (error) {
      console.warn('Failed to check login status:', error);
      this.logout(); // Clear corrupted data
      return false;
    }
  },

  /**
   * Get current user data with validation
   */
  getCurrentUser() {
    try {
      if (!this.isLoggedIn()) {
        return null;
      }

      const userData = this.getStorageItem(this.STORAGE_KEYS.USER);
      return userData || null;
    } catch (error) {
      console.warn('Failed to get user data:', error);
      return null;
    }
  },

  /**
   * Enhanced login with rate limiting and validation
   */
  async login(email, password) {
    try {
      // Input validation
      if (!this.validateEmail(email)) {
        return { success: false, error: '有効なメールアドレスを入力してください' };
      }

      if (!password || password.length < 6) {
        return { success: false, error: 'パスワードは6文字以上で入力してください' };
      }

      // Check rate limiting
      const rateLimitResult = this.checkRateLimit(email);
      if (!rateLimitResult.allowed) {
        return { 
          success: false, 
          error: `ログイン試行回数が上限に達しました。${Math.ceil(rateLimitResult.waitTime / 60000)}分後に再試行してください` 
        };
      }

      // Simulate network delay for realistic UX
      await this.delay(500 + Math.random() * 1000);

      // Find matching credentials
      const user = this.VALID_CREDENTIALS.find(
        cred => cred.email.toLowerCase() === email.toLowerCase() && cred.password === password
      );

      if (!user) {
        this.recordFailedAttempt(email);
        return { success: false, error: 'メールアドレスまたはパスワードが正しくありません' };
      }

      // Clear failed attempts on successful login
      this.clearFailedAttempts(email);

      // Create session
      const sessionData = this.createSession(user);
      
      // Store user data and session
      this.setStorageItem(this.STORAGE_KEYS.USER, user);
      this.setStorageItem(this.STORAGE_KEYS.TOKEN, sessionData.token);
      this.setStorageItem(this.STORAGE_KEYS.SESSION, sessionData.session);
      this.setStorageItem(this.STORAGE_KEYS.REFRESH_TOKEN, sessionData.refreshToken);

      // Apply user theme preference
      if (user.preferences?.theme && window.ProgenThemeManager) {
        ProgenThemeManager.setTheme(user.preferences.theme);
      }

      console.log('Login successful for user:', user.name);
      return { success: true, user };

    } catch (error) {
      console.error('Login error:', error);
      return { success: false, error: 'ログイン処理中にエラーが発生しました' };
    }
  },

  /**
   * Enhanced logout with cleanup
   */
  async logout() {
    try {
      // Clear all authentication data
      Object.values(this.STORAGE_KEYS).forEach(key => {
        localStorage.removeItem(key);
      });

      // Clear login attempts
      this.loginAttempts.clear();

      console.log('Logout successful');
      return { success: true };

    } catch (error) {
      console.error('Logout error:', error);
      return { success: false, error: 'ログアウト処理中にエラーが発生しました' };
    }
  },

  /**
   * Refresh session token
   */
  refreshSession() {
    try {
      const user = this.getCurrentUser();
      if (!user) return false;

      const sessionData = this.createSession(user);
      
      this.setStorageItem(this.STORAGE_KEYS.TOKEN, sessionData.token);
      this.setStorageItem(this.STORAGE_KEYS.SESSION, sessionData.session);
      this.setStorageItem(this.STORAGE_KEYS.REFRESH_TOKEN, sessionData.refreshToken);

      console.log('Session refreshed successfully');
      return true;
    } catch (error) {
      console.error('Failed to refresh session:', error);
      return false;
    }
  },

  /**
   * Create session data with enhanced security
   */
  createSession(user) {
    const now = Date.now();
    const expiresAt = now + this.CONFIG.SESSION_TIMEOUT;
    
    // Generate secure tokens
    const token = this.generateToken(user.id, now);
    const refreshToken = this.generateToken(user.id + '_refresh', now);
    
    return {
      token,
      refreshToken,
      session: {
        userId: user.id,
        createdAt: now,
        expiresAt,
        lastActivity: now,
        userAgent: navigator.userAgent.substring(0, 100) // Truncate for storage
      }
    };
  },

  /**
   * Generate secure token
   */
  generateToken(identifier, timestamp) {
    const randomBytes = new Uint8Array(16);
    crypto.getRandomValues(randomBytes);
    const randomString = Array.from(randomBytes, byte => byte.toString(16).padStart(2, '0')).join('');
    
    return `${this.CONFIG.TOKEN_PREFIX}${btoa(identifier + '_' + timestamp + '_' + randomString)}`;
  },

  /**
   * Validate token format
   */
  validateToken(token) {
    if (!token || typeof token !== 'string') return false;
    if (!token.startsWith(this.CONFIG.TOKEN_PREFIX)) return false;
    
    try {
      const decoded = atob(token.substring(this.CONFIG.TOKEN_PREFIX.length));
      return decoded.includes('_') && decoded.length > 20;
    } catch {
      return false;
    }
  },

  /**
   * Check rate limiting for login attempts
   */
  checkRateLimit(email) {
    const now = Date.now();
    const attempts = this.loginAttempts.get(email) || { count: 0, lastAttempt: 0, lockedUntil: 0 };
    
    // Check if still locked out
    if (attempts.lockedUntil > now) {
      return { 
        allowed: false, 
        waitTime: attempts.lockedUntil - now 
      };
    }
    
    // Reset if lockout period has passed
    if (attempts.lockedUntil > 0 && attempts.lockedUntil <= now) {
      attempts.count = 0;
      attempts.lockedUntil = 0;
    }
    
    return { allowed: true };
  },

  /**
   * Record failed login attempt
   */
  recordFailedAttempt(email) {
    const now = Date.now();
    const attempts = this.loginAttempts.get(email) || { count: 0, lastAttempt: 0, lockedUntil: 0 };
    
    attempts.count++;
    attempts.lastAttempt = now;
    
    // Lock account if max attempts reached
    if (attempts.count >= this.CONFIG.MAX_LOGIN_ATTEMPTS) {
      attempts.lockedUntil = now + this.CONFIG.LOCKOUT_DURATION;
    }
    
    this.loginAttempts.set(email, attempts);
  },

  /**
   * Clear failed attempts on successful login
   */
  clearFailedAttempts(email) {
    this.loginAttempts.delete(email);
  },

  /**
   * Check session expiry and cleanup
   */
  checkSessionExpiry() {
    try {
      const session = this.getStorageItem(this.STORAGE_KEYS.SESSION);
      if (session && Date.now() > session.expiresAt) {
        this.logout();
      }
    } catch (error) {
      console.warn('Failed to check session expiry:', error);
    }
  },

  /**
   * Validate email format
   */
  validateEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  },

  /**
   * Safe storage operations with error handling
   */
  setStorageItem(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
      return true;
    } catch (error) {
      console.error('Failed to set storage item:', error);
      return false;
    }
  },

  getStorageItem(key) {
    try {
      const item = localStorage.getItem(key);
      return item ? JSON.parse(item) : null;
    } catch (error) {
      console.error('Failed to get storage item:', error);
      return null;
    }
  },

  /**
   * Utility: Create delay for UX
   */
  delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  },

  /**
   * Future extension points for staged authentication
   */
  
  // Phase 2: Magic Link Authentication (placeholder)
  async sendMagicLink(email) {
    // TODO: Implement magic link authentication
    console.log('Magic link authentication not yet implemented');
    return { success: false, error: 'Magic link認証は開発中です' };
  },

  // Phase 3: OAuth Authentication (placeholder)
  async authenticateWithOAuth(provider) {
    // TODO: Implement OAuth authentication
    console.log(`OAuth authentication with ${provider} not yet implemented`);
    return { success: false, error: `${provider}認証は開発中です` };
  },

  // Phase 4: Two-Factor Authentication (placeholder)
  async enableTwoFactor() {
    // TODO: Implement 2FA
    console.log('Two-factor authentication not yet implemented');
    return { success: false, error: '二要素認証は開発中です' };
  }
};

// Initialize authentication system when loaded
if (document.readyState === 'loading') {

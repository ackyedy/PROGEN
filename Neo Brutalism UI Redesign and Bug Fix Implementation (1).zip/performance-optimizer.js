/**
 * PROGEN Performance Optimizer
 * Provides performance monitoring and optimization features
 */

'use strict';

const PerformanceOptimizer = {
  // Configuration
  config: {
    lazyLoadOffset: 100,
    debounceDelay: 150,
    throttleDelay: 16,
    criticalResourceTimeout: 3000,
    performanceMetricsEnabled: true,
    imageOptimizationEnabled: true,
    fontOptimizationEnabled: true
  },

  // State
  state: {
    isInitialized: false,
    metrics: {
      loadTime: 0,
      firstContentfulPaint: 0,
      largestContentfulPaint: 0,
      cumulativeLayoutShift: 0,
      firstInputDelay: 0
    },
    observers: {
      intersection: null,
      performance: null,
      mutation: null
    },
    optimizations: {
      imagesLazyLoaded: 0,
      fontsPreloaded: 0,
      scriptsDeferred: 0
    }
  },

  /**
   * Initialize performance optimizer
   */
  init() {
    if (this.state.isInitialized) return;

    try {
      this.measureInitialMetrics();
      this.setupLazyLoading();
      this.optimizeImages();
      this.optimizeFonts();
      this.setupCriticalResourceLoading();
      this.setupPerformanceMonitoring();
      this.optimizeScrollPerformance();
      this.setupResourceHints();
      
      this.state.isInitialized = true;
      console.log('⚡ Performance Optimizer initialized!');
      
      // Report initial metrics after a delay
      setTimeout(() => {
        this.reportMetrics();
      }, 2000);
    } catch (error) {
      console.error('Failed to initialize Performance Optimizer:', error);
    }
  },

  /**
   * Measure initial performance metrics
   */
  measureInitialMetrics() {
    if (!this.config.performanceMetricsEnabled) return;

    // Measure page load time
    window.addEventListener('load', () => {
      const navigation = performance.getEntriesByType('navigation')[0];
      if (navigation) {
        this.state.metrics.loadTime = navigation.loadEventEnd - navigation.fetchStart;
      }
    });

    // Measure Core Web Vitals
    if ('PerformanceObserver' in window) {
      // First Contentful Paint
      new PerformanceObserver((list) => {
        const entries = list.getEntries();
        entries.forEach(entry => {
          if (entry.name === 'first-contentful-paint') {
            this.state.metrics.firstContentfulPaint = entry.startTime;
          }
        });
      }).observe({ entryTypes: ['paint'] });

      // Largest Contentful Paint
      new PerformanceObserver((list) => {
        const entries = list.getEntries();
        const lastEntry = entries[entries.length - 1];
        this.state.metrics.largestContentfulPaint = lastEntry.startTime;
      }).observe({ entryTypes: ['largest-contentful-paint'] });

      // Cumulative Layout Shift
      new PerformanceObserver((list) => {
        let clsValue = 0;
        for (const entry of list.getEntries()) {
          if (!entry.hadRecentInput) {
            clsValue += entry.value;
          }
        }
        this.state.metrics.cumulativeLayoutShift = clsValue;
      }).observe({ entryTypes: ['layout-shift'] });

      // First Input Delay
      new PerformanceObserver((list) => {
        const entries = list.getEntries();
        entries.forEach(entry => {
          this.state.metrics.firstInputDelay = entry.processingStart - entry.startTime;
        });
      }).observe({ entryTypes: ['first-input'] });
    }
  },

  /**
   * Setup lazy loading for images and other resources
   */
  setupLazyLoading() {
    if (!('IntersectionObserver' in window)) {
      // Fallback for browsers without IntersectionObserver
      this.loadAllImages();
      return;
    }

    this.state.observers.intersection = new IntersectionObserver(
      (entries) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            this.loadResource(entry.target);
            this.state.observers.intersection.unobserve(entry.target);
          }
        });
      },
      {
        rootMargin: `${this.config.lazyLoadOffset}px`
      }
    );

    // Observe images with loading="lazy" or data-src
    const lazyImages = document.querySelectorAll('img[loading="lazy"], img[data-src]');
    lazyImages.forEach(img => {
      this.state.observers.intersection.observe(img);
    });

    // Observe other lazy-loadable elements
    const lazyElements = document.querySelectorAll('[data-lazy]');
    lazyElements.forEach(element => {
      this.state.observers.intersection.observe(element);
    });
  },

  /**
   * Load resource when it becomes visible
   */
  loadResource(element) {
    if (element.tagName === 'IMG') {
      this.loadImage(element);
    } else if (element.hasAttribute('data-lazy')) {
      this.loadLazyElement(element);
    }
  },

  /**
   * Load image with optimization
   */
  loadImage(img) {
    const src = img.dataset.src || img.src;
    if (!src) return;

    // Create a new image to preload
    const newImg = new Image();
    
    newImg.onload = () => {
      img.src = src;
      img.classList.add('loaded');
      this.state.optimizations.imagesLazyLoaded++;
      
      // Remove data-src to prevent reloading
      if (img.dataset.src) {
        delete img.dataset.src;
      }
    };

    newImg.onerror = () => {
      img.classList.add('error');
      console.warn('Failed to load image:', src);
    };

    newImg.src = src;
  },

  /**
   * Load lazy element
   */
  loadLazyElement(element) {
    const content = element.dataset.lazy;
    if (content) {
      element.innerHTML = content;
      element.classList.add('loaded');
      delete element.dataset.lazy;
    }
  },

  /**
   * Load all images (fallback)
   */
  loadAllImages() {
    const images = document.querySelectorAll('img[data-src]');
    images.forEach(img => {
      this.loadImage(img);
    });
  },

  /**
   * Optimize images
   */
  optimizeImages() {
    if (!this.config.imageOptimizationEnabled) return;

    const images = document.querySelectorAll('img');
    images.forEach(img => {
      // Add loading="lazy" if not present
      if (!img.hasAttribute('loading') && !img.dataset.src) {
        img.setAttribute('loading', 'lazy');
      }

      // Add decoding="async" for better performance
      if (!img.hasAttribute('decoding')) {
        img.setAttribute('decoding', 'async');
      }

      // Ensure alt attribute exists
      if (!img.hasAttribute('alt')) {
        img.setAttribute('alt', '');
        console.warn('Image missing alt attribute:', img.src);
      }

      // Add size hints if missing
      if (!img.hasAttribute('width') && !img.hasAttribute('height')) {
        this.addImageSizeHints(img);
      }
    });
  },

  /**
   * Add image size hints to prevent layout shift
   */
  addImageSizeHints(img) {
    // Use natural dimensions if available
    if (img.naturalWidth && img.naturalHeight) {
      img.setAttribute('width', img.naturalWidth);
      img.setAttribute('height', img.naturalHeight);
      return;
    }

    // Use computed dimensions
    const computedStyle = window.getComputedStyle(img);
    const width = parseInt(computedStyle.width);
    const height = parseInt(computedStyle.height);

    if (width && height) {
      img.setAttribute('width', width);
      img.setAttribute('height', height);
    }
  },

  /**
   * Optimize fonts
   */
  optimizeFonts() {
    if (!this.config.fontOptimizationEnabled) return;

    // Add font-display: swap to existing font faces
    const styleSheets = Array.from(document.styleSheets);
    styleSheets.forEach(sheet => {
      try {
        const rules = Array.from(sheet.cssRules || sheet.rules || []);
        rules.forEach(rule => {
          if (rule.type === CSSRule.FONT_FACE_RULE) {
            if (!rule.style.fontDisplay) {
              rule.style.fontDisplay = 'swap';
            }
          }
        });
      } catch (e) {
        // Cross-origin stylesheets may throw errors
      }
    });

    // Preload critical fonts
    this.preloadCriticalFonts();
  },

  /**
   * Preload critical fonts
   */
  preloadCriticalFonts() {
    const criticalFonts = [
      'https://fonts.googleapis.com/css2?family=Noto+Sans+JP:wght@400;700;900&display=swap',
      'https://fonts.googleapis.com/css2?family=Roboto+Mono:wght@400;700&display=swap'
    ];

    criticalFonts.forEach(fontUrl => {
      const link = document.createElement('link');
      link.rel = 'preload';
      link.as = 'style';
      link.href = fontUrl;
      link.onload = () => {
        link.rel = 'stylesheet';
        this.state.optimizations.fontsPreloaded++;
      };
      document.head.appendChild(link);
    });
  },

  /**
   * Setup critical resource loading
   */
  setupCriticalResourceLoading() {
    // Preload critical CSS
    const criticalCSS = document.querySelector('link[rel="stylesheet"][href*="design-system"]');
    if (criticalCSS) {
      criticalCSS.setAttribute('rel', 'preload');
      criticalCSS.setAttribute('as', 'style');
      criticalCSS.onload = () => {
        criticalCSS.rel = 'stylesheet';
      };
    }

    // Defer non-critical scripts
    const scripts = document.querySelectorAll('script[src]:not([async]):not([defer])');
    scripts.forEach(script => {
      if (!this.isCriticalScript(script.src)) {
        script.setAttribute('defer', '');
        this.state.optimizations.scriptsDeferred++;
      }
    });
  },

  /**
   * Check if script is critical
   */
  isCriticalScript(src) {
    const criticalScripts = [
      'config.js',
      'theme-manager',
      'design-system'
    ];

    return criticalScripts.some(critical => src.includes(critical));
  },

  /**
   * Setup performance monitoring
   */
  setupPerformanceMonitoring() {
    if (!this.config.performanceMetricsEnabled) return;

    // Monitor long tasks
    if ('PerformanceObserver' in window) {
      new PerformanceObserver((list) => {
        const entries = list.getEntries();
        entries.forEach(entry => {
          if (entry.duration > 50) {
            console.warn('Long task detected:', entry.duration + 'ms');
          }
        });
      }).observe({ entryTypes: ['longtask'] });
    }

    // Monitor resource loading
    window.addEventListener('load', () => {
      const resources = performance.getEntriesByType('resource');
      const slowResources = resources.filter(resource => resource.duration > 1000);
      
      if (slowResources.length > 0) {
        console.warn('Slow resources detected:', slowResources);
      }
    });
  },

  /**
   * Optimize scroll performance
   */
  optimizeScrollPerformance() {
    let ticking = false;

    const optimizedScrollHandler = () => {
      if (!ticking) {
        requestAnimationFrame(() => {
          this.handleScroll();
          ticking = false;
        });
        ticking = true;
      }
    };

    window.addEventListener('scroll', optimizedScrollHandler, { passive: true });
  },

  /**
   * Handle scroll events efficiently
   */
  handleScroll() {
    // Update scroll-dependent elements
    const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
    
    // Update navigation state
    const header = document.querySelector('.learning-header, .studio-header');
    if (header) {
      if (scrollTop > 100) {
        header.classList.add('scrolled');
      } else {
        header.classList.remove('scrolled');
      }
    }

    // Update progress indicators
    const progressBars = document.querySelectorAll('.progress-bar-fill');
    progressBars.forEach(bar => {
      const container = bar.closest('.progress-bar-container');
      if (container && this.isElementInViewport(container)) {
        this.animateProgressBar(bar);
      }
    });
  },

  /**
   * Setup resource hints
   */
  setupResourceHints() {
    // DNS prefetch for external domains
    const externalDomains = [
      'fonts.googleapis.com',
      'fonts.gstatic.com',
      'cdnjs.cloudflare.com'
    ];

    externalDomains.forEach(domain => {
      const link = document.createElement('link');
      link.rel = 'dns-prefetch';
      link.href = `//${domain}`;
      document.head.appendChild(link);
    });

    // Preconnect to critical external resources
    const criticalDomains = [
      'fonts.googleapis.com',
      'fonts.gstatic.com'
    ];

    criticalDomains.forEach(domain => {
      const link = document.createElement('link');
      link.rel = 'preconnect';
      link.href = `https://${domain}`;
      link.crossOrigin = 'anonymous';
      document.head.appendChild(link);
    });
  },

  /**
   * Check if element is in viewport
   */
  isElementInViewport(element) {
    const rect = element.getBoundingClientRect();
    return (
      rect.top >= 0 &&
      rect.left >= 0 &&
      rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
      rect.right <= (window.innerWidth || document.documentElement.clientWidth)
    );
  },

  /**
   * Animate progress bar
   */
  animateProgressBar(bar) {
    if (bar.dataset.animated) return;
    
    const targetWidth = bar.style.width || bar.dataset.progress + '%';
    bar.style.width = '0%';
    
    requestAnimationFrame(() => {
      bar.style.transition = 'width 1s ease-out';
      bar.style.width = targetWidth;
      bar.dataset.animated = 'true';
    });
  },

  /**
   * Debounce function
   */
  debounce(func, wait = this.config.debounceDelay) {
    let timeout;
    return function executedFunction(...args) {
      const later = () => {
        clearTimeout(timeout);
        func(...args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    };
  },

  /**
   * Throttle function
   */
  throttle(func, limit = this.config.throttleDelay) {
    let inThrottle;
    return function() {
      const args = arguments;
      const context = this;
      if (!inThrottle) {
        func.apply(context, args);
        inThrottle = true;
        setTimeout(() => inThrottle = false, limit);
      }
    };
  },

  /**
   * Optimize DOM operations
   */
  optimizeDOMOperations(operations) {
    // Batch DOM operations to minimize reflows
    const fragment = document.createDocumentFragment();
    
    operations.forEach(operation => {
      if (typeof operation === 'function') {
        operation(fragment);
      }
    });
    
    return fragment;
  },

  /**
   * Preload next page resources
   */
  preloadNextPage(url) {
    const link = document.createElement('link');
    link.rel = 'prefetch';
    link.href = url;
    document.head.appendChild(link);
  },

  /**
   * Report performance metrics
   */
  reportMetrics() {
    if (!this.config.performanceMetricsEnabled) return;

    const metrics = {
      ...this.state.metrics,
      optimizations: this.state.optimizations,
      timestamp: Date.now()
    };

    console.group('🚀 Performance Metrics');
    console.log('Load Time:', metrics.loadTime.toFixed(2) + 'ms');
    console.log('First Contentful Paint:', metrics.firstContentfulPaint.toFixed(2) + 'ms');
    console.log('Largest Contentful Paint:', metrics.largestContentfulPaint.toFixed(2) + 'ms');
    console.log('Cumulative Layout Shift:', metrics.cumulativeLayoutShift.toFixed(4));
    console.log('First Input Delay:', metrics.firstInputDelay.toFixed(2) + 'ms');
    console.log('Optimizations:', metrics.optimizations);
    console.groupEnd();

    // Send metrics to analytics (if available)
    if (typeof gtag !== 'undefined') {
      gtag('event', 'performance_metrics', {
        load_time: metrics.loadTime,
        fcp: metrics.firstContentfulPaint,
        lcp: metrics.largestContentfulPaint,
        cls: metrics.cumulativeLayoutShift,
        fid: metrics.firstInputDelay
      });
    }

    return metrics;
  },

  /**
   * Get performance score
   */
  getPerformanceScore() {
    const metrics = this.state.metrics;
    let score = 100;

    // Deduct points for poor metrics
    if (metrics.loadTime > 3000) score -= 20;
    if (metrics.firstContentfulPaint > 1800) score -= 15;
    if (metrics.largestContentfulPaint > 2500) score -= 25;
    if (metrics.cumulativeLayoutShift > 0.1) score -= 25;
    if (metrics.firstInputDelay > 100) score -= 15;

    return Math.max(0, score);
  },

  /**
   * Optimize critical rendering path
   */
  optimizeCriticalRenderingPath() {
    // Inline critical CSS
    const criticalCSS = this.extractCriticalCSS();
    if (criticalCSS) {
      const style = document.createElement('style');
      style.textContent = criticalCSS;
      document.head.insertBefore(style, document.head.firstChild);
    }

    // Defer non-critical CSS
    const nonCriticalCSS = document.querySelectorAll('link[rel="stylesheet"]:not([data-critical])');
    nonCriticalCSS.forEach(link => {
      link.media = 'print';
      link.onload = () => {
        link.media = 'all';
      };
    });
  },

  /**
   * Extract critical CSS (simplified)
   */
  extractCriticalCSS() {
    // This is a simplified version - in production, use tools like Critical or Penthouse
    return `
      /* Critical CSS for above-the-fold content */
      body { margin: 0; font-family: var(--font-sans, 'Noto Sans JP', sans-serif); }
      .learning-header, .studio-header { background: var(--color-primary); }
      .btn { padding: 0.75rem 1.5rem; border: var(--outline); }
    `;
  },

  /**
   * Monitor and fix layout shifts
   */
  monitorLayoutShifts() {
    if (!('PerformanceObserver' in window)) return;

    new PerformanceObserver((list) => {
      for (const entry of list.getEntries()) {
        if (!entry.hadRecentInput && entry.value > 0.1) {
          console.warn('Large layout shift detected:', {
            value: entry.value,
            sources: entry.sources
          });
          
          // Attempt to fix common causes
          this.fixLayoutShifts(entry.sources);
        }
      }
    }).observe({ entryTypes: ['layout-shift'] });
  },

  /**
   * Fix common layout shift causes
   */
  fixLayoutShifts(sources) {
    sources.forEach(source => {
      const element = source.node;
      
      // Add dimensions to images without them
      if (element.tagName === 'IMG' && !element.hasAttribute('width')) {
        this.addImageSizeHints(element);
      }
      
      // Reserve space for dynamic content
      if (element.classList.contains('dynamic-content')) {
        element.style.minHeight = element.style.minHeight || '100px';
      }
    });
  },

  /**
   * Get debug information
   */
  getDebugInfo() {
    return {
      isInitialized: this.state.isInitialized,
      metrics: this.state.metrics,
      optimizations: this.state.optimizations,
      performanceScore: this.getPerformanceScore(),
      config: this.config
    };
  }
};

// Auto-initialize when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    PerformanceOptimizer.init();
  });
} else {
  PerformanceOptimizer.init();
}

// Export for use in other modules
if (typeof window !== 'undefined') {
  window.PerformanceOptimizer = PerformanceOptimizer;
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = PerformanceOptimizer;
}

